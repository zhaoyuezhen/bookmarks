package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.DailyStockFilecreat;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatCsv;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatReports;
import jp.co.groundinc.convertor.mapper.DailyStockFilecreatMapper;

@Service
@EnableAutoConfiguration
public class DailyStockFilecreatService {
	@Autowired
	DailyStockFilecreatMapper dailyStockFilecreatMapper;
	
	@Autowired
	CommonUtility commonUtility;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<DailyStockFilecreatReports> findDailyStockFilecreatReports(String sku) {
		logger.info("--- DailyStockFilecreatService.findDailyStockFilecreatReports() start ---");
		
		List<DailyStockFilecreatReports> dailyStockFilecreatReportsList = 
				dailyStockFilecreatMapper.selectDailyStockFilecreatReports(sku);
		
		return dailyStockFilecreatReportsList;
	}
	
	public List<DailyStockFilecreatCsv> findDailyStockFilecreatCsv() {
		logger.info("--- DailyStockFilecreatService.findDailyStockFilecreatCsv() start ---");
		
		List<DailyStockFilecreatCsv> dailyStockFilecreatCsvList = 
				dailyStockFilecreatMapper.selectDailyStockFilecreatCsv();
		
		return dailyStockFilecreatCsvList;
	}
	
	public void updateDate(DailyStockFilecreat dailyStockFilecreat) {
		dailyStockFilecreatMapper.updateDate(dailyStockFilecreat);
		
	}

	public void updateTime(DailyStockFilecreat dailyStockFilecreat1) {
		dailyStockFilecreatMapper.updateTime(dailyStockFilecreat1);
		
	}
	
	public int selectCount() {
		logger.info("--- DailyStockFilecreatService.selectCount() start ---");
		int skuCount = dailyStockFilecreatMapper.selectCount();
		return skuCount;
    }
	
	public int insertStockDailyLog(DailyStockFilecreat dailyStockFilecreat1) {
		logger.info("--- DailyStockFilecreatService.insertStockDailyLog() start ---");
		 int count  = dailyStockFilecreatMapper.insertStockDailyLog(dailyStockFilecreat1);
		 return count;
	}
}

package jp.co.groundinc.convertor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.domain.WcsReportFormat;

@Service
@EnableAutoConfiguration
public class WcsStockfileService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private OAuth2RestTemplate restTemplate;

	@Autowired
	CommonConstant commonConstant;

	@Value("${webapi.butler-inventories-api.url}")
	private String apiUrl;

	public boolean outputStockFile() {
		boolean result = true;

		try {
			String url = apiUrl + "/get_inventory_report";
			logger.info("--- WcsStockfileService.outputStockFile() Call webapi start ---");

			WcsReportFormat wcsReportFormat = new WcsReportFormat();
			wcsReportFormat.setDelimiter(",");
			wcsReportFormat.addFiled("product_sku", "SKU");
			wcsReportFormat.addFiled("location", "Location");
			wcsReportFormat.addFiled("actual_quantity", "Quantity");
			restTemplate.postForObject(url, wcsReportFormat, String.class);
			
			logger.info("--- WcsStockfileService.outputStockFile() Call webapi end ---");
		} catch (RestClientException e) {
			logger.error("--- WcsStockfileService.outputStockFile()" + e.getMessage());
			result = false;
		}
		return result;
	}
}

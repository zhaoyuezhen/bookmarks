package jp.co.groundinc.convertor.web.form;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserMasterForm implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Size(max = 13)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{Common.Pattern.AlphaNumeric.message}")
	private String userCode;
	
	@Size(max = 50)
	private String userName;
	
	
	private String authoritykind;
	
	
	private String passwordChangeDate;
	
	
	private String tbUserCode;
	
	public String getTbUserCode() {
		return tbUserCode;
	}
	public void setTbUserCode(String tbUserCode) {
		this.tbUserCode = tbUserCode;
	}
	
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAuthoritykind() {
		return authoritykind;
	}
	public void setAuthoritykind(String authoritykind) {
		this.authoritykind = authoritykind;
	}
	public String getPasswordChangeDate() {
		return passwordChangeDate;
	}
	public void setPasswordChangeDate(String passwordChangeDate) {
		this.passwordChangeDate = passwordChangeDate;
	}
}

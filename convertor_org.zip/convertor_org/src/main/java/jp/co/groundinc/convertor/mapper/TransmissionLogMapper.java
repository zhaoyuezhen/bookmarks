package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.TransmissionLog;
import jp.co.groundinc.convertor.domain.TransmissionLogCsv;
import jp.co.groundinc.convertor.domain.TransmissionLogMapperDetail;

@Mapper
public interface TransmissionLogMapper {	
     List<TransmissionLog> findcommunicationMonitor(TransmissionLog communicationMonitor);
     int selectCountt(TransmissionLog communicationMonitor);
     TransmissionLog findcommunicationMonitorIdInfo(String transmissionid);
     List<TransmissionLogMapperDetail> selectErrorInfo(String transmissionid);
     List<TransmissionLogCsv> selectTransmissionLogCsv(
    		@Param("startDate") String startDate,
    		@Param("endDate") String endDate,
 			@Param("transmissionType") String transmissionType,
 			@Param("transMissionTypeDetail") String transMissionTypeDetail,
 			@Param("sendrecvKind") String sendrecvKind,
 			@Param("processingStatus") String processingStatus);
}

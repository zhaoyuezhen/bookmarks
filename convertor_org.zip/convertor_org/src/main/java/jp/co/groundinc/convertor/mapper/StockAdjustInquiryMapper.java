package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.StockAdjustInquiry;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetail;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetailCsv;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryReports;
@Mapper
public interface StockAdjustInquiryMapper {
	List<StockAdjustInquiry> selectStockAdjustInquiry(StockAdjustInquiry stockAdjustInquiry);
	int selectCountt(StockAdjustInquiry stockAdjustInquiry);
	StockAdjustInquiry selectStockAdjustInquiryInfo(String auditNo);
	List<StockAdjustInquiryDetail> selectStockAdjustInquiryDetail(String auditNo);
	List<StockAdjustInquiryDetailCsv> selectStockAdjustInquiryDetailCsv(List<String> orderIdList);
	
	List<StockAdjustInquiryReports> selectStockAdjustInquiryReport(String auditNo);
	
	String selectPrintLogSeqence();
	void insertPrintLog(StockAdjustInquiry stockAdjustInquiry);
	void insertAuditExpectationDetail(StockAdjustInquiryDetail stockAdjustInquiryDetail);
	
}

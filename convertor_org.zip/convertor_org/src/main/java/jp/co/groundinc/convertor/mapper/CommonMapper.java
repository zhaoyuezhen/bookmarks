package jp.co.groundinc.convertor.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.ConvUser;
import jp.co.groundinc.convertor.domain.Translate;

@Mapper
public interface CommonMapper {
	ConvUser selectUserByUserCd(String userCd);
	List<Translate> selectTranslateByTranslateKind(String translateKind);
	String selectOperationDate();
	String selectStockSendDate();
	String selectStockSendTime();
	List<Translate> selectTranslateByTranslateKindDetail(String translateKind);
	String  selectTableUpperlimit();
	String  selectTableUpperCSVlimit();
	String getReprintOutputPdfPath(Translate translate);
	List<String> selectAllAuthorityKinds();
	String selectSkuNameByCode(String skuCode);
	String selectUserNameByCode(String userCode);
	
}

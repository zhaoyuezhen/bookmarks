package jp.co.groundinc.convertor.domain;

import javax.validation.constraints.NotNull;

public class DailyStockFileInquiry {
    
	private String createKind;
	
	private String createKindName;
	
	private String processedDate;
	
	private String processedTime;
	
	@NotNull(message = "{DailyStockFileInquiry.search.processedDateStart.empty.message}")
	private String processedDateStart;
	
	private String processedDateEnd;
	
	private String processedDateTime;
	
	private int totalCount;
	
	private String fileUrl;
	
	public String getProcessedDateTime() {
		return processedDateTime;
	}
	public void setProcessedDateTime(String processedDateTime) {
		this.processedDateTime = processedDateTime;
	}
	public String getProcessedDateStart() {
		return processedDateStart;
	}
	public void setProcessedDateStart(String processedDateStart) {
		this.processedDateStart = processedDateStart;
	}
	public String getProcessedDateEnd() {
		return processedDateEnd;
	}
	public void setProcessedDateEnd(String processedDateEnd) {
		this.processedDateEnd = processedDateEnd;
	}
	public String getCreateKind() {
		return createKind;
	}
	public void setCreateKind(String createKind) {
		this.createKind = createKind;
	}
	public String getCreateKindName() {
		return createKindName;
	}
	public void setCreateKindName(String createKindName) {
		this.createKindName = createKindName;
	}
	public String getProcessedDate() {
		return processedDate;
	}
	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}
	public String getProcessedTime() {
		return processedTime;
	}
	public void setProcessedTime(String processedTime) {
		this.processedTime = processedTime;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public String getFileUrl() {
		return fileUrl;
	}
	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}
  
}

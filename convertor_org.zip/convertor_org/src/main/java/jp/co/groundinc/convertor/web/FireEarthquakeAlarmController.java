package jp.co.groundinc.convertor.web;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jp.co.groundinc.convertor.service.FireEarthquakeAlarmService;
import jp.co.groundinc.convertor.web.form.AlarmForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class FireEarthquakeAlarmController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	FireEarthquakeAlarmService fireEarthquakeAlarmService;

	@ModelAttribute("alarmForm")
	public AlarmForm alarmForm() {
		logger.info("--- FireEarthquakeAlarmController.alarmForm() start ---");
		return new AlarmForm();
	}

	@RequestMapping("/fire_earthquake_alarm")
	public ModelAndView fireEarthquakeAlarm(ModelAndView modelView) {
		logger.info("--- FireEarthquakeAlarmController.fireEarthquakeAlarm() start ---");
		return modelView;
	}
	
	@RequestMapping(value = "/fire_earthquake_alarm", params = "action=Fire")
	public ModelAndView alarmFire(ModelAndView modelView) {
		modelView.setViewName("/fire_earthquake_alarm");
		
		String message = "";
		if (fireEarthquakeAlarmService.alert()) {
			message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
		} else {
			message = messageSource.getMessage("fireEarthquakeAlarm.alert.fail.message", null, Locale.JAPAN);
		}
		modelView.addObject("validationMessage", message);
		
		return modelView;
	}
	
}

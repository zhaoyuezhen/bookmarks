package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class Translate  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	/** 変換区分 */
	private String translateKind;
	
	/** 変換コード */
	private String translate_code;
	
	/** 変換値 */
	private String translate_value;
	
	/** ソートキー */
	private String sort_key;
	
	/** 使用フラグ */
	private String inuse_flag;
	
	/** ノート */
	private String note;
	
	public String getTranslateKind() {
		return translateKind;
	}
	public void setTranslateKind(String translateKind) {
		this.translateKind = translateKind;
	}
	public String getTranslate_code() {
		return translate_code;
	}
	public void setTranslate_code(String translate_code) {
		this.translate_code = translate_code;
	}
	public String getTranslate_value() {
		return translate_value;
	}
	public void setTranslate_value(String translate_value) {
		this.translate_value = translate_value;
	}
	public String getSort_key() {
		return sort_key;
	}
	public void setSort_key(String sort_key) {
		this.sort_key = sort_key;
	}
	public String getInuse_flag() {
		return inuse_flag;
	}
	public void setInuse_flag(String inuse_flag) {
		this.inuse_flag = inuse_flag;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
}

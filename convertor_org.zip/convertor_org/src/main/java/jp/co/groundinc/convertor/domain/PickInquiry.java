package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class PickInquiry implements Serializable {
	private static final long serialVersionUID = 1L;
	private String datareceiveddateStart;
	private String datareceiveddateEnd;
	private String expecteddateStart;
	private String expecteddateEnd;
	private String operateddateStart;
	private String operateddateEnd;

	private String operatedTimeStart;
	private String operatedTimeEnd;
	
	private String ppsbinid;
	private String datareceiveddate;
	private String expecteddate;
	private String orderid;
	private String orderlineid;
	private String sku;
	private String skuname;
	private String expectedqty;
	private String resultqty;
	private String missingqty;
	private String butlerStatus;
	private String butlerStatusDetail;
	private String errorMessage;
	private String operateddate;
	private String operatedtime;
	private String irregularKindName;
	private String irregularKind;
	private String irregularKinds;
	private String workingstatus;
	private String ppsid;
	private String ppsbinName;
	private String yjk;
	private String operatedDateTime;
	private String orderKindName;
	private String orderKind;
	private String allMissingFlag;
	private String createTime;
	private String dataReceivedDateTime;
	
	/**予定開始日 */
	private String datareceivedtimeStart;
	/**予定終了日   */
	private String datareceivedtimeEnd;	
	
	public String getDataReceivedDateTime() {
		return dataReceivedDateTime;
	}

	public void setDataReceivedDateTime(String dataReceivedDateTime) {
		this.dataReceivedDateTime = dataReceivedDateTime;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getDatareceivedtimeStart() {
		return datareceivedtimeStart;
	}

	public void setDatareceivedtimeStart(String datareceivedtimeStart) {
		this.datareceivedtimeStart = datareceivedtimeStart;
	}

	public String getDatareceivedtimeEnd() {
		return datareceivedtimeEnd;
	}

	public void setDatareceivedtimeEnd(String datareceivedtimeEnd) {
		this.datareceivedtimeEnd = datareceivedtimeEnd;
	}

	public String getAllMissingFlag() {
		return allMissingFlag;
	}

	public void setAllMissingFlag(String allMissingFlag) {
		this.allMissingFlag = allMissingFlag;
	}

	public String getPpsbinName() {
		return ppsbinName;
	}

	public void setPpsbinName(String ppsbinName) {
		this.ppsbinName = ppsbinName;
	}

	public String getButlerStatus() {
		return butlerStatus;
	}

	public void setButlerStatus(String butlerStatus) {
		this.butlerStatus = butlerStatus;
	}

	public String getButlerStatusDetail() {
		return butlerStatusDetail;
	}

	public void setButlerStatusDetail(String butlerStatusDetail) {
		this.butlerStatusDetail = butlerStatusDetail;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOrderKindName() {
		return orderKindName;
	}

	public void setOrderKindName(String orderKindName) {
		this.orderKindName = orderKindName;
	}

	public String getOrderKind() {
		return orderKind;
	}

	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}

	public String getYjk() {
		return yjk;
	}

	public String getOperatedDateTime() {
		return operatedDateTime;
	}

	public void setOperatedDateTime(String operatedDateTime) {
		this.operatedDateTime = operatedDateTime;
	}

	public void setYjk(String yjk) {
		this.yjk = yjk;
	}

	public String getExpecteddate() {
		return expecteddate;
	}

	public void setExpecteddate(String expecteddate) {
		this.expecteddate = expecteddate;
	}

	public String getOrderlineid() {
		return orderlineid;
	}

	public void setOrderlineid(String orderlineid) {
		this.orderlineid = orderlineid;
	}

	public String getPpsbinid() {
		return ppsbinid;
	}

	public void setPpsbinid(String ppsbinid) {
		this.ppsbinid = ppsbinid;
	}

	public String getDatareceiveddateStart() {
		return datareceiveddateStart;
	}

	public String getWorkingstatus() {
		return workingstatus;
	}

	public void setWorkingstatus(String workingstatus) {
		this.workingstatus = workingstatus;
	}

	public void setDatareceiveddateStart(String datareceiveddateStart) {
		this.datareceiveddateStart = datareceiveddateStart;
	}

	public String getDatareceiveddateEnd() {
		return datareceiveddateEnd;
	}

	public void setDatareceiveddateEnd(String datareceiveddateEnd) {
		this.datareceiveddateEnd = datareceiveddateEnd;
	}

	public String getExpecteddateStart() {
		return expecteddateStart;
	}

	public void setExpecteddateStart(String expecteddateStart) {
		this.expecteddateStart = expecteddateStart;
	}

	public String getExpecteddateEnd() {
		return expecteddateEnd;
	}

	public void setExpecteddateEnd(String expecteddateEnd) {
		this.expecteddateEnd = expecteddateEnd;
	}

	public String getOperateddateStart() {
		return operateddateStart;
	}

	public void setOperateddateStart(String operateddateStart) {
		this.operateddateStart = operateddateStart;
	}

	public String getOperateddateEnd() {
		return operateddateEnd;
	}

	public void setOperateddateEnd(String operateddateEnd) {
		this.operateddateEnd = operateddateEnd;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDatareceiveddate() {
		return datareceiveddate;
	}

	public void setDatareceiveddate(String datareceiveddate) {
		this.datareceiveddate = datareceiveddate;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuname() {
		return skuname;
	}

	public void setSkuname(String skuname) {
		this.skuname = skuname;
	}

	public String getExpectedqty() {
		return expectedqty;
	}

	public void setExpectedqty(String expectedqty) {
		this.expectedqty = expectedqty;
	}

	public String getResultqty() {
		return resultqty;
	}

	public void setResultqty(String resultqty) {
		this.resultqty = resultqty;
	}

	public String getMissingqty() {
		return missingqty;
	}

	public void setMissingqty(String missingqty) {
		this.missingqty = missingqty;
	}

	public String getOperateddate() {
		return operateddate;
	}

	public void setOperateddate(String operateddate) {
		this.operateddate = operateddate;
	}

	public String getOperatedtime() {
		return operatedtime;
	}

	public void setOperatedtime(String operatedtime) {
		this.operatedtime = operatedtime;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	
	public String getIrregularKinds() {
		return irregularKinds;
	}

	public void setIrregularKinds(String irregularKinds) {
		this.irregularKinds = irregularKinds;
	}

	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}

	public String getPpsid() {
		return ppsid;
	}

	public void setPpsid(String ppsid) {
		this.ppsid = ppsid;
	}
	
	public String getOperatedTimeStart() {
		return operatedTimeStart;
	}

	public void setOperatedTimeStart(String operatedTimeStart) {
		this.operatedTimeStart = operatedTimeStart;
	}

	public String getOperatedTimeEnd() {
		return operatedTimeEnd;
	}

	public void setOperatedTimeEnd(String operatedTimeEnd) {
		this.operatedTimeEnd = operatedTimeEnd;
	}

	/** 予定開始日 */
	public void setDataReceivedtimeStart(String datareceivedtimeStart) {
		this.datareceivedtimeStart = datareceivedtimeStart;
	}
	public String getDataReceivedtimeStart() {
		return datareceivedtimeStart;
	}	

	/**予定終了日   */
	public void setDataReceivedtimeEnd(String datareceivedtimeEnd) {
		this.datareceivedtimeEnd = datareceivedtimeEnd;
	}
	public String getDataReceivedtimeEnd() {
		return datareceivedtimeEnd;
	}

}

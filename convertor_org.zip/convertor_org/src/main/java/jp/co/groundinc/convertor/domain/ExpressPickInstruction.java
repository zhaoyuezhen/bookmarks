package jp.co.groundinc.convertor.domain;

import java.math.BigDecimal;

public class ExpressPickInstruction {
	
	private static final long serialVersionUID = 1L;

	private String expectedDate;
	private String dataRecievedDate;
	private String dataRecievedTime;
	private String dataReceivedDateTime;
	private String dataReceivedDateTimeStart;
	private String dataReceivedDateTimeEnd;
	private String picklistKind;
	private String picklistKindName;
	private String orderId;
	private String shortenedOrderId;
	private int orderLineCount;
	private String totalExpectedCount;
	private String pickDate;
	private String pickDateStart;
	private String pickTimeStart;
	private String pickDateEnd;
	private String pickTimeEnd;
	private String workingStatus;
	private String creatUser;
	private String creatDate;
	private String creatTime;
	private String upateUser;
	private String upadateDate;
	private String upadateTime;
	private String bintags;
	private String largeAreaCode;
	private String pageTitle;
	private String pickBarcode;
	private String packingBarcode;
	private String flightName;
	private String homeNo;
	private String shippingAddress;
	private String shippingAddressName;
	private String area;
	private String location;
	private int unitPrice;
	private int totalAmount;
	private int packingSize;
	private BigDecimal cbm;
	private int loadingSourceCode;
	private int picklistPageNo;
	private int totalPickSequence;
	private String orderLineId;
	private int printOrder;
	private int orderlargeAreaLine;
	private int priority;
	private int expectedQty;
	private String ordererName;
	private String orderDate;
	private String orderKind;
	private String deliveryDate;
	private String shippingSourceName;
	private String checkMark;
	private String orderAreaKind;
	private String fragileFlag;
	private String orderFragileFlag;
	private String printFlag;
	private String sendStatus;
	private String sortLocation;
	private String sku;
	private String skuName;
	private String skuKind;
	private String processSequenceNo;
	

	public String getDataRecievedDate() {
		return dataRecievedDate;
	}

	public void setDataRecievedDate(String dataRecievedDate) {
		this.dataRecievedDate = dataRecievedDate;
	}

	public String getDataRecievedTime() {
		return dataRecievedTime;
	}

	public void setDataRecievedTime(String dataRecievedTime) {
		this.dataRecievedTime = dataRecievedTime;
	}

	public String getLargeAreaCode() {
		return largeAreaCode;
	}

	public void setLargeAreaCode(String largeAreaCode) {
		this.largeAreaCode = largeAreaCode;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPickBarcode() {
		return pickBarcode;
	}

	public void setPickBarcode(String pickBarcode) {
		this.pickBarcode = pickBarcode;
	}

	public String getPackingBarcode() {
		return packingBarcode;
	}

	public void setPackingBarcode(String packingBarcode) {
		this.packingBarcode = packingBarcode;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getHomeNo() {
		return homeNo;
	}

	public void setHomeNo(String homeNo) {
		this.homeNo = homeNo;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getShippingAddressName() {
		return shippingAddressName;
	}

	public void setShippingAddressName(String shippingAddressName) {
		this.shippingAddressName = shippingAddressName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public int getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}


	public int getPackingSize() {
		return packingSize;
	}

	public void setPackingSize(int packingSize) {
		this.packingSize = packingSize;
	}

	public String getOrdererName() {
		return ordererName;
	}

	public void setOrdererName(String ordererName) {
		this.ordererName = ordererName;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderKind() {
		return orderKind;
	}

	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getShippingSourceName() {
		return shippingSourceName;
	}

	public void setShippingSourceName(String shippingSourceName) {
		this.shippingSourceName = shippingSourceName;
	}

	public String getCheckMark() {
		return checkMark;
	}

	public void setCheckMark(String checkMark) {
		this.checkMark = checkMark;
	}

	

	public String getOrderAreaKind() {
		return orderAreaKind;
	}

	public void setOrderAreaKind(String orderAreaKind) {
		this.orderAreaKind = orderAreaKind;
	}

	public String getFragileFlag() {
		return fragileFlag;
	}

	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}

	public String getOrderFragileFlag() {
		return orderFragileFlag;
	}

	public void setOrderFragileFlag(String orderFragileFlag) {
		this.orderFragileFlag = orderFragileFlag;
	}

	public BigDecimal getCbm() {
		return cbm;
	}

	public void setCbm(BigDecimal cbm) {
		this.cbm = cbm;
	}

	public int getLoadingSourceCode() {
		return loadingSourceCode;
	}

	public void setLoadingSourceCode(int loadingSourceCode) {
		this.loadingSourceCode = loadingSourceCode;
	}

	public int getPicklistPageNo() {
		return picklistPageNo;
	}

	public void setPicklistPageNo(int picklistPageNo) {
		this.picklistPageNo = picklistPageNo;
	}

	public int getTotalPickSequence() {
		return totalPickSequence;
	}

	public void setTotalPickSequence(int totalPickSequence) {
		this.totalPickSequence = totalPickSequence;
	}

	public String getOrderLineId() {
		return orderLineId;
	}

	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}

	public int getPrintOrder() {
		return printOrder;
	}

	public void setPrintOrder(int printOrder) {
		this.printOrder = printOrder;
	}

	public int getOrderlargeAreaLine() {
		return orderlargeAreaLine;
	}

	public void setOrderlargeAreaLine(int orderlargeAreaLine) {
		this.orderlargeAreaLine = orderlargeAreaLine;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}

	public String getPrintFlag() {
		return printFlag;
	}

	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getSortLocation() {
		return sortLocation;
	}

	public void setSortLocation(String sortLocation) {
		this.sortLocation = sortLocation;
	}


	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getSkuKind() {
		return skuKind;
	}

	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}

	public int getPriority() {
		return priority;
	}

	public int getExpectedQty() {
		return expectedQty;
	}

	public String getProcessSequenceNo() {
		return processSequenceNo;
	}

	public void setProcessSequenceNo(String processSequenceNo) {
		this.processSequenceNo = processSequenceNo;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}

	public String getCreatUser() {
		return creatUser;
	}

	public void setCreatUser(String creatUser) {
		this.creatUser = creatUser;
	}

	public String getCreatDate() {
		return creatDate;
	}

	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}

	public String getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(String creatTime) {
		this.creatTime = creatTime;
	}

	public String getUpateUser() {
		return upateUser;
	}

	public void setUpateUser(String upateUser) {
		this.upateUser = upateUser;
	}

	public String getUpadateDate() {
		return upadateDate;
	}

	public void setUpadateDate(String upadateDate) {
		this.upadateDate = upadateDate;
	}

	public String getUpadateTime() {
		return upadateTime;
	}

	public void setUpadateTime(String upadateTime) {
		this.upadateTime = upadateTime;
	}

	public String getBintags() {
		return bintags;
	}

	public void setBintags(String bintags) {
		this.bintags = bintags;
	}

	public String getExpectedDate() {
		return expectedDate;
	}

	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}

	public String getPicklistKind() {
		return picklistKind;
	}

	public void setPicklistKind(String picklistKind) {
		this.picklistKind = picklistKind;
	}

	public String getPicklistKindName() {
		return picklistKindName;
	}

	public void setPicklistKindName(String picklistKindName) {
		this.picklistKindName = picklistKindName;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getShortenedOrderId() {
		return shortenedOrderId;
	}

	public void setShortenedOrderId(String shortenedOrderId) {
		this.shortenedOrderId = shortenedOrderId;
	}

	
	public int getOrderLineCount() {
		return orderLineCount;
	}

	public void setOrderLineCount(int orderLineCount) {
		this.orderLineCount = orderLineCount;
	}

	public String getTotalExpectedCount() {
		return totalExpectedCount;
	}

	public void setTotalExpectedCount(String totalExpectedCount) {
		this.totalExpectedCount = totalExpectedCount;
	}

	public String getPickDate() {
		return pickDate;
	}

	public void setPickDate(String pickDate) {
		this.pickDate = pickDate;
	}

	public String getPickDateStart() {
		return pickDateStart;
	}

	public void setPickDateStart(String pickDateStart) {
		this.pickDateStart = pickDateStart;
	}

	public String getPickDateEnd() {
		return pickDateEnd;
	}

	public void setPickDateEnd(String pickDateEnd) {
		this.pickDateEnd = pickDateEnd;
	}
	public String getPickTimeStart() {
		return pickTimeStart;
	}

	public void setPickTimeStart(String pickTimeStart) {
		this.pickTimeStart = pickTimeStart;
	}

	public String getPickTimeEnd() {
		return pickTimeEnd;
	}

	public void setPickTimeEnd(String pickTimeEnd) {
		this.pickTimeEnd = pickTimeEnd;
	}
	public String getDataReceivedDateTimeStart() {
		return dataReceivedDateTimeStart;
	}

	public void setDataReceivedDateTimeStart(String dataReceivedDateTimeStart) {
		this.dataReceivedDateTimeStart = dataReceivedDateTimeStart;
	}

	public String getDataReceivedDateTimeEnd() {
		return dataReceivedDateTimeEnd;
	}

	public void setDataReceivedDateTimeEnd(String dataReceivedDateTimeEnd) {
		this.dataReceivedDateTimeEnd = dataReceivedDateTimeEnd;
	}
	public String getDataReceivedDateTime() {
		return dataReceivedDateTime;
	}

	public void setDataReceivedDateTime(String dataReceivedDateTime) {
		this.dataReceivedDateTime = dataReceivedDateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.TransmissionLog;
import jp.co.groundinc.convertor.domain.TransmissionLogCsv;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.TransmissionLogService;
import jp.co.groundinc.convertor.web.form.TransmissionLogForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "transmissionLogForm" })
public class TransmissionLogController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	TransmissionLogService transmissionLogService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("transmissionLogForm")
	public TransmissionLogForm transmissionLogForm() {
		logger.info("--- TransmissionLogController.transmissionLogForm() start ---");
		return new TransmissionLogForm();
	}
	@ModelAttribute("startDate")
	public String startDate() throws ParseException {
        logger.info("--- TransmissionLogController.startDate() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("endDate")
	public String endDate() throws ParseException {
		logger.info("--- TransmissionLogController.auditProgress() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("communicationType")
	public List<Translate> communicationTypes() {
		logger.info("--- TransmissionLogController.communicationTypes() start ---");
		return commonService.getTranslateList("CommunicationType");
	}

	@ModelAttribute("communicationTypeDetail")
	public List<Translate> communicationTypeDetails() {
		logger.info("--- TransmissionLogController.communicationTypeDetails() start ---");
		return commonService.getTranslateList("CommunicationTypeDetail");
	}

	@ModelAttribute("sendRecvKind")
	public List<Translate> sendRecvKinds() {
		logger.info("--- TransmissionLogController.sendRecvKinds() start ---");
		return commonService.getTranslateList("SendRecvKind");
	}

	@ModelAttribute("processingStatus")
	public List<Translate> processStatuss() {
		logger.info("--- TransmissionLogController.processStatuss() start ---");

		return commonService.getTranslateList("ProcessingStatus");
	}

	@RequestMapping("/monitor")
	public String viewMonitor(Model model, HttpServletRequest request) {
		logger.info("--- TransmissionLogController.viewMonitor() start ---");
		TransmissionLogForm form = new TransmissionLogForm();
		model.addAttribute("transmissionLogForm", form);
		return "transmission_log";
	}

	@RequestMapping(value = "/monitor", params = "action=clear")
	public String communicationMonitorClear(HttpServletRequest request, Model model, SessionStatus status)
			throws ParseException {
		logger.info("--- communicationMonitorClear() start ---");
		TransmissionLogForm form = new TransmissionLogForm();
		model.addAttribute("transmissionLogForm", form);
		status.setComplete();
		return "transmission_log";
	}

	@RequestMapping(value = "/monitor", params = "action=back")
	public String communicationMonitorBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- communicationMonitorBack() start ---");
		status.setComplete();
		return "manage_menu";
	}

	@RequestMapping(value = "/monitor", params = "action=search")
	public ModelAndView selectCommunicationMonitorInfo(
			@Validated @ModelAttribute("transmissionLogForm") TransmissionLogForm transmissionLogForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {

		logger.info("--- selectCommunicationMonitorInfo() start ---");
		modelView.setViewName("/transmission_log");
		modelView.addObject("startDate", transmissionLogForm.getStartDate());
		modelView.addObject("endDate", transmissionLogForm.getEndDate());
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String tusinddate = messageSource.getMessage("transmissionLog.StartDate.empty.message",
					null, Locale.JAPAN);
			modelView.addObject("tusinddate", tusinddate);
			return modelView;
		}
		String startDate = transmissionLogForm.getStartDate();
		String endDate = transmissionLogForm.getEndDate();
		if (!StringUtils.isEmpty(startDate) && !StringUtils.isEmpty(endDate)) {
			if (CommonUtility.comparedateStartafterEnd(startDate, endDate)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String tusinddate1 = messageSource.getMessage("transmissionLog.tusinddate.message",
						null, Locale.JAPAN);
				modelView.addObject("tusinddate1", tusinddate1);
				return modelView;
			}
		}
		
		if (!StringUtils.isEmpty(startDate) && StringUtils.isEmpty(endDate)) {
			endDate = startDate;
		}
		String transmissiontype = transmissionLogForm.getTransMissionType();
		String transmissiontypedetail = transmissionLogForm.getTransMissionTypeDetail();
		String sendrecvkind = transmissionLogForm.getSendrecvKind();
		String processingstatus = transmissionLogForm.getProcessingStatus();
		
		TransmissionLog transmissionLog = new TransmissionLog();
		transmissionLog.setStartDate(CommonUtility.dateFomat(startDate));
		transmissionLog.setEndDate(CommonUtility.dateFomat(endDate));
		transmissionLog.setTransmissionType(transmissiontype);
		transmissionLog.setTransmissionTypeDetail(transmissiontypedetail);
		transmissionLog.setSendrecvKind(sendrecvkind);
		transmissionLog.setProcessingStatus(processingstatus);
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=transmissionLogService.selectCountt(transmissionLog);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<TransmissionLog> communicationMonitorlist = transmissionLogService
				.findCommunicationMonitor(transmissionLog);
		if (CollectionUtils.isEmpty(communicationMonitorlist)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;

		}
		for(int i=0;i<communicationMonitorlist.size();i++){
			String prossedDatetime = communicationMonitorlist.get(i).getProcessedDate() + communicationMonitorlist.get(i).getProcessedTime();
			String newstr = CommonUtility.getDateTime(prossedDatetime);
			communicationMonitorlist.get(i).setProcessedDateTime(newstr);
			
		}
		
		modelView.addObject("communicationMonitorlist", communicationMonitorlist);
		return modelView;
	}
	
	@RequestMapping(value = "/monitor", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("transmissionLogForm") TransmissionLogForm transmissionLogForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- TransmissionLogController.download() start ---");
		modelView.setViewName("/transmission_log");
		
		String startDate = transmissionLogForm.getStartDate();
		String endDate = transmissionLogForm.getEndDate();
		if (!StringUtils.isEmpty(startDate) && !StringUtils.isEmpty(endDate)) {
			if (CommonUtility.comparedateStartafterEnd(startDate, endDate)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String tusinddate1 = messageSource.getMessage("transmissionLog.tusinddate.message",
						null, Locale.JAPAN);
				modelView.addObject("tusinddate1", tusinddate1);
				return modelView;
			}
		}
		
		if (!StringUtils.isEmpty(startDate) && StringUtils.isEmpty(endDate)) {
			endDate = startDate;
		}
		String transmissionType = transmissionLogForm.getTransMissionType();
		String transMissionTypeDetail = transmissionLogForm.getTransMissionTypeDetail();
		String sendrecvKind = transmissionLogForm.getSendrecvKind();
		String processingStatus = transmissionLogForm.getProcessingStatus();
		
		TransmissionLog transmissionLog = new TransmissionLog();
		transmissionLog.setStartDate(CommonUtility.dateFomat(startDate));
		transmissionLog.setEndDate(CommonUtility.dateFomat(endDate));
		transmissionLog.setTransmissionType(transmissionType);
		transmissionLog.setTransmissionTypeDetail(transMissionTypeDetail);
		transmissionLog.setSendrecvKind(sendrecvKind);
		transmissionLog.setProcessingStatus(processingStatus);
		
		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual=transmissionLogService.selectCountt(transmissionLog);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<TransmissionLogCsv> transmissionLogCsvList = 
				transmissionLogService.findTransmissionLogCsv(
						startDate,endDate,transmissionType, transMissionTypeDetail, sendrecvKind, processingStatus);
		
		if (CollectionUtils.isEmpty(transmissionLogCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/transmission_log");
			return modelView;
		}
		
		modelView.addObject("transmissionLogCsvList", transmissionLogCsvList);
		modelView.setViewName("TransmissionLogCsvView");
		return modelView;
	}
	
	@RequestMapping("/getTransmissionetail")
	@ResponseBody
	public List <Translate> communicationTypeDetailst(HttpServletRequest request, HttpServletResponse httpServletResponse,
			ModelAndView modelView) {

		String transMissionValue1 = request.getParameter("transMissionValue");
		
       logger.info("--- TransmissionLogController.communicationTypeDetails() start ---");
       if("".equals(transMissionValue1)){
    	   return commonService.getTranslateList("CommunicationTypeDetail");
       }
       else{
           return commonService.getTranslateListDetail(transMissionValue1);
       }
	}
}

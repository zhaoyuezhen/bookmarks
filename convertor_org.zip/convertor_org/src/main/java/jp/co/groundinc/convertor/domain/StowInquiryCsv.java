package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class StowInquiryCsv implements Serializable {
	private static final long serialVersionUID = 1L;
	/** 入庫予定番号  */
	private String expectedPutId;
	/** コンテナID  */
	private String containerId;
	/** 行番号  */
	private String expectedPutLineId;
	/** 商品コード  */
	private String sku;
	/** 商品名  */
	private String skuName;
	/** 商品区分  */
	private String skuKind;
	/** 商品区分名 */
	private String skuKindName;
	/** 作業状態  */
	private String workingStatus;
	
	private String workingStatusName;
	/** 予定数  */
	private String expectedQty;
	/** 実績数  */
	private String resultQty;
	/** 不良数  */
	private String damagedQty;
	/** 過剰数  */
	private String extraQty;
	/** 欠品数  */
	private String missingQty;
	/** 作業日  */
	private String operatedDate;
	/** 作業時間  */
	private String operatedTime;
	/** ステーション  */
	private String ppsId;
	
	private String ppsName;
	
	private String ppsBinId;
	
	private String ppsBinName;
	/** 予実差異  */
	private String irregularKindName;
	
	private String irregularKind;
	
	private String dataReceivedDate;
	
	private String putKind;
	
	private String putKindName;
	
	private String userName;

	private String userCode;
	
	private String csvExportDate;
	
	private String csvExportTime;
	/** 受信予定日（時刻）  */
	private String dataReceivedTime;

	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	
	public String getPutKind() {
		return putKind;
	}

	public void setPutKind(String putKind) {
		this.putKind = putKind;
	}

	public String getPutKindName() {
		return putKindName;
	}

	public void setPutKindName(String putKindName) {
		this.putKindName = putKindName;
	}
	
	public String getWorkingStatusName() {
		return workingStatusName;
	}
	public void setWorkingStatusName(String workingStatusName) {
		this.workingStatusName = workingStatusName;
	}
	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}
	
	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getExpectedPutId() {
		return expectedPutId;
	}

	public void setExpectedPutId(String expectedPutId) {
		this.expectedPutId = expectedPutId;
	}

	public String getExpectedPutLineId() {
		return expectedPutLineId;
	}

	public void setExpectedPutLineId(String expectedPutLineId) {
		this.expectedPutLineId = expectedPutLineId;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getSkuKind() {
		return skuKind;
	}

	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}

	public String getExpectedQty() {
		return expectedQty;
	}

	public void setExpectedQty(String expectedQty) {
		this.expectedQty = expectedQty;
	}

	public String getResultQty() {
		return resultQty;
	}

	public void setResultQty(String resultQty) {
		this.resultQty = resultQty;
	}

	public String getDamagedQty() {
		return damagedQty;
	}

	public void setDamagedQty(String damagedQty) {
		this.damagedQty = damagedQty;
	}

	public String getExtraQty() {
		return extraQty;
	}

	public void setExtraQty(String extraQty) {
		this.extraQty = extraQty;
	}

	public String getMissingQty() {
		return missingQty;
	}

	public void setMissingQty(String missingQty) {
		this.missingQty = missingQty;
	}

	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

	public String getDataReceivedDate() {
		return dataReceivedDate;
	}

	public void setDataReceivedDate(String dataReceivedDate) {
		this.dataReceivedDate = dataReceivedDate;
	}
	public String getSkuKindName() {
		return skuKindName;
	}
	public void setSkuKindName(String skuKindName) {
		this.skuKindName = skuKindName;
	}
	public String getPpsName() {
		return ppsName;
	}
	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}
	public String getPpsBinId() {
		return ppsBinId;
	}
	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}
	public String getPpsBinName() {
		return ppsBinName;
	}
	public void setPpsBinName(String ppsBinName) {
		this.ppsBinName = ppsBinName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	/** 受信予定日（時刻）    */
	public void setDataReceivedTime(String dataReceivedTime) {
		this.dataReceivedTime = dataReceivedTime;
	}
	public String getDataReceivedTime() {
		return dataReceivedTime;
	}	

}

package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.PickProgress;

@Mapper
public interface PickProgressMapper {
	List<PickProgress> findPickProgressA(PickProgress pick);
	List<PickProgress> findPickProgressB(PickProgress pick);
	List<PickProgress> findPickProgress(PickProgress pick);
	List<PickProgress> findButlerList(PickProgress pick);
	int selectCountt(PickProgress pick);
	String getDefTranslateCode();
}

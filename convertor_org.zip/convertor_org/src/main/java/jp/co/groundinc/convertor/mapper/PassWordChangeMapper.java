package jp.co.groundinc.convertor.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.groundinc.convertor.domain.UserMaster;

@Mapper
public interface PassWordChangeMapper {
	int countAll(@Param("userCode") String userCode, @Param("password") String password);
	int updateUserPassword(UserMaster user);

}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.PrintLogInquiry;
import jp.co.groundinc.convertor.mapper.PrintLogInquiryMapper;

@Service
public class PrintLogInquiryService {
	@Autowired
	PrintLogInquiryMapper printLogInquiryMapper;
	@Autowired
	CommonUtility commonUtility;

	public List<PrintLogInquiry> findPrintLog(PrintLogInquiry printLogInquiry) {

		String dateStart = CommonUtility.dateFomat(printLogInquiry.getPrintDateStart());
		printLogInquiry.setPrintDateStart(dateStart);

		String timeStart = CommonUtility.timeFomat(printLogInquiry.getPrintTimeStart());
		printLogInquiry.setPrintTimeStart(timeStart);

		String timeEnd = CommonUtility.timeFomat(printLogInquiry.getPrintTimeEnd());
		printLogInquiry.setPrintTimeEnd(timeEnd);

		List<PrintLogInquiry> list = printLogInquiryMapper.selectPrintLog(printLogInquiry);
		return list;

	}
	
	public int selectCountt(PrintLogInquiry printLogInquiry) {

		String dateStart = CommonUtility.dateFomat(printLogInquiry.getPrintDateStart());
		printLogInquiry.setPrintDateStart(dateStart);

		int count = printLogInquiryMapper.selectCountt(printLogInquiry);
		return count;

	}
}
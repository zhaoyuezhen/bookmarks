package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.ExceptionsInquiry;
import jp.co.groundinc.convertor.domain.ExceptionsInquiryDetail;
@Mapper
public interface ExceptionsInquiryMapper {

	List<ExceptionsInquiry> selectExceptionsInquiry(ExceptionsInquiry exceptionsInquiry);
	
	List<ExceptionsInquiryDetail> selectExceptionsInquiryDetail(ExceptionsInquiryDetail exceptionsDetail);
	
	int selectCountt(ExceptionsInquiry exceptionsInquiry);

}

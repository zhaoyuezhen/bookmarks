package jp.co.groundinc.convertor.domain;

public class ExceptionsInquiryDetail {
	
	private String exceptionTimestamp;
	private String executionId;
	private String containerId;
	private String operationKind;
	private String location;
	private String sku;
	private String exceptionDate;
	private String exceptionKind;
	private int exceptionQty;
	private String ppsId;
	private String ppsName;
    private String ppsBinId;
    private String ppsBinName;
    private String userCode;
    private String userName;
    
    
    public String getExceptionDate() {
		return exceptionDate;
	}
	public void setExceptionDate(String exceptionDate) {
		this.exceptionDate = exceptionDate;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getExceptionTimestamp() {
		return exceptionTimestamp;
	}
	public void setExceptionTimestamp(String exceptionTimestamp) {
		this.exceptionTimestamp = exceptionTimestamp;
	}
	public String getExecutionId() {
		return executionId;
	}
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}
	public String getContainerId() {
		return containerId;
	}
	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}
	public String getOperationKind() {
		return operationKind;
	}
	public void setOperationKind(String operationKind) {
		this.operationKind = operationKind;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getExceptionKind() {
		return exceptionKind;
	}
	public void setExceptionKind(String exceptionKind) {
		this.exceptionKind = exceptionKind;
	}
	public int getExceptionQty() {
		return exceptionQty;
	}
	public void setExceptionQty(int exceptionQty) {
		this.exceptionQty = exceptionQty;
	}
	public String getPpsId() {
		return ppsId;
	}
	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}
	public String getPpsName() {
		return ppsName;
	}
	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}
	public String getPpsBinId() {
		return ppsBinId;
	}
	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}
	public String getPpsBinName() {
		return ppsBinName;
	}
	public void setPpsBinName(String ppsBinName) {
		this.ppsBinName = ppsBinName;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
    
    
}

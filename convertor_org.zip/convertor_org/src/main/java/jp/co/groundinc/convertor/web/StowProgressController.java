package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StowProgress;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.StowProgressService;

@Controller
@EnableAutoConfiguration
@SessionAttributes

public class StowProgressController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	StowProgressService stowProgressService;
	
	@Autowired
	CommonUtility commonUtility;
	
	@InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    	/*dataBinder.registerCustomEditor(String.class, "dataReceivedTime", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "nextdataReceivedTime", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedDate", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "nextdataReceivedDate", new TimePropertyEditor());*/
    }
	@ModelAttribute("dataReceivedTime")
	public String dataReceivedTime()throws ParseException{
		logger.info("--- StowProgressController.stowProgress() start ---");
		return "00:00";
	}

	@ModelAttribute("nextdataReceivedTime")
	public String nextdataReceivedTime() throws ParseException {
		logger.info("--- StowProgressController.stowProgress() start ---");
		return "23:59";
	}
	@ModelAttribute("dataReceivedDate")
	public String dataReceivedDate()throws ParseException{
		logger.info("--- StowProgressController.stowProgress() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("nextdataReceivedDate")
	public String nextdataReceivedDate() throws ParseException {
		logger.info("--- StowProgressController.stowProgress() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("putKind")
	public List<Translate> putKind() {
		logger.info("--- StowProgressController.putKind() start ---");
		return commonService.getTranslateList("PutKind");
	}
	
	
	 @ModelAttribute("stowProgress")
	public StowProgress stowProgress() {
		logger.info("--- StowProgressController.stowProgress() start ---");
		return new StowProgress();
	}
	   
	@RequestMapping(value = "/stow_progress")
	public ModelAndView stowProgress(ModelAndView modelView) throws ParseException {
		logger.info("--- StowProgressController.stowProgress() start ---");
		StowProgress stowProgress = new StowProgress();
		String dataReceivedDate =CommonUtility.dateFomat(commonService.getOperationDate());
		String nextdataReceivedDate = CommonUtility.dateFomat(commonService.getOperationDate());
		stowProgress.setDataReceivedDate(dataReceivedDate);
		stowProgress.setNextdataReceivedDate(nextdataReceivedDate);
	    stowProgress.setDataReceivedTime("000000");
	    stowProgress.setNextdataReceivedTime("235959");
		List<StowProgress> stowProgressList = stowProgressService.selectStowProgress(stowProgress);
		modelView.addObject("result", stowProgressList);

		stowProgress.setDataReceivedTime("00:00");
		stowProgress.setNextdataReceivedTime("23:59");
		stowProgress.setDataReceivedDate( dataReceivedDate.substring(0,4) + "-" + dataReceivedDate.substring(4,6)+"-" + dataReceivedDate.substring(6));
		stowProgress.setNextdataReceivedDate(nextdataReceivedDate.substring(0,4) + "-" + nextdataReceivedDate.substring(4,6)+"-" + nextdataReceivedDate.substring(6));
		modelView.addObject("stowProgress",stowProgress);
		modelView.addObject("dataReceivedDate","2017-10-30");
		modelView.addObject("nextdataReceivedDate","2017-10-30");
		modelView.setViewName("stow_progress");
		return modelView;

	}
	
	@RequestMapping(value = "/stow_progress", params = "action=back")
	public String back(Model model) {
		logger.info("--- StowProgressController.back() start ---");
		return "work_menu";
	}

	@RequestMapping(value = "/stow_progress", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("stowProgress") StowProgress stowProgressFrom, BindingResult result, ModelAndView modelView){
		logger.info("--- StowProgressController.search() start ---");
		
		modelView.setViewName("/stow_progress");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		
		String dataReceivedDate =stowProgressFrom.getDataReceivedDate();
		String nextdataReceivedDate=stowProgressFrom.getNextdataReceivedDate();
		String dataReceivedTime = stowProgressFrom.getDataReceivedTime();
		String nextdataReceivedTime=stowProgressFrom.getNextdataReceivedTime();
		String putKind = stowProgressFrom.getPutKind();
		String putKindName = stowProgressFrom.getPutKindName();
		
		
		if (StringUtils.isEmpty(dataReceivedTime)) {
			dataReceivedTime = "00:00:00";
		} else {
			dataReceivedTime = dataReceivedTime + ":00";
		}
	
		if (StringUtils.isEmpty(nextdataReceivedTime)) {
			nextdataReceivedTime = "23:59:59";
		} else {
			nextdataReceivedTime = nextdataReceivedTime + ":59";
		}
		
		if(StringUtils.isEmpty(nextdataReceivedDate)) {
			nextdataReceivedDate=dataReceivedDate;
		}
	
		stowProgressFrom.setDataReceivedDate(dataReceivedDate);
		stowProgressFrom.setDataReceivedTime(dataReceivedTime.length() >= 5 ? dataReceivedTime.substring(0,5) : "00:00");
		stowProgressFrom.setNextdataReceivedDate(nextdataReceivedDate);
		stowProgressFrom.setNextdataReceivedTime(nextdataReceivedTime.length() >= 5 ? nextdataReceivedTime.substring(0,5) : "23:59");

		if(!StringUtils.isEmpty(dataReceivedDate) && !StringUtils.isEmpty(nextdataReceivedDate)){
            if (CommonUtility.compareDateTimeStartafterEnd(dataReceivedDate+" "+dataReceivedTime, nextdataReceivedDate+" "+nextdataReceivedTime)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationDate = messageSource.getMessage("StowProgress.search.dataReceivedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("operationDate", operationDate);
				return modelView;
		     }
	     }
    	StowProgress stowProgress = new StowProgress();
		stowProgress.setDataReceivedDate( CommonUtility.dateFomat(dataReceivedDate));
		stowProgress.setNextdataReceivedDate(CommonUtility.dateFomat(nextdataReceivedDate));
		stowProgress.setDataReceivedTimeStart(CommonUtility.timeFomat(dataReceivedTime));
		stowProgress.setDataReceivedTimeEnd(CommonUtility.timeFomat(nextdataReceivedTime));
		stowProgress.setPutKind(putKind);
		stowProgress.setPutKindName(putKindName);
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=stowProgressService.selectStowProgressCount(stowProgress);
		if(count <= countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
        
			List<StowProgress> stowProgressList = stowProgressService.selectStowProgress(stowProgress);
		
			if (CollectionUtils.isEmpty(stowProgressList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		modelView.addObject("result", stowProgressList);
		return modelView;

	}

}

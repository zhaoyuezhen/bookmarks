package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class WcsReportField implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String key;
	private String display_name;
	
	public WcsReportField(String key, String display_name) {
		this.key = key;
		this.display_name = display_name;
	}
	
	public String getKey() {
		return key;
	}
	public String getDisplay_name() {
		return display_name;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}

}

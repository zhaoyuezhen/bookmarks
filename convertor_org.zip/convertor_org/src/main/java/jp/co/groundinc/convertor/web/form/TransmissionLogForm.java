package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;

public class TransmissionLogForm {
	private String transMissionType;
	private String transMissionTypeDetail;
	private String sendrecvKind;
	private String processingStatus;
	@NotNull(message = "{transmissionLog.StartDate.empty.message}")
	private String startDate;
	private String endDate;
	
	public String getTransMissionType() {
		return transMissionType;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public void setTransMissionType(String transMissionType) {
		this.transMissionType = transMissionType;
	}
	public String getTransMissionTypeDetail() {
		return transMissionTypeDetail;
	}
	public void setTransMissionTypeDetail(String transMissionTypeDetail) {
		this.transMissionTypeDetail = transMissionTypeDetail;
	}
	public String getSendrecvKind() {
		return sendrecvKind;
	}
	public void setSendrecvKind(String sendrecvKind) {
		this.sendrecvKind = sendrecvKind;
	}
	public String getProcessingStatus() {
		return processingStatus;
	}
	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}
	
	
	
	
}

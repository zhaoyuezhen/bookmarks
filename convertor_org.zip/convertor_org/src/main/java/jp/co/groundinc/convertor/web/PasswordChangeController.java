package jp.co.groundinc.convertor.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.service.PasswordChangeService;
import jp.co.groundinc.convertor.web.form.PasswordChangeForm;

@Controller
@EnableAutoConfiguration
@SessionAttributes(value = { "passwordChangeForm" }) 
public class PasswordChangeController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	PasswordChangeService passwordChangeService;
	
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }
    
	@ModelAttribute("passwordChangeForm")
	public PasswordChangeForm passwordChangeForm() {
		logger.info("--- PasswordChangeController.passwordChangeForm() start ---");
		return new PasswordChangeForm();
	}
	
	@RequestMapping("/pwd_change")
	public String passwordChange(Model model) {
		logger.info("--- PasswordChangeController.passwordChange() start ---");
		PasswordChangeForm form = new PasswordChangeForm();
		model.addAttribute("passwordChangeForm", form);
		
        return "pwd_change";
	}
	
	@RequestMapping(value="/pwd_change", params="action=update")
	public ModelAndView passwordChange(@Validated @ModelAttribute PasswordChangeForm form, BindingResult result, ModelAndView modelView) {
		logger.info("--- PasswordChangeController.passwordchange(update) start ---");
		
		modelView.setViewName("/pwd_change");
		
    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	String userCode = form.getUserCode();
    	String oldPassword = form.getOldPassword();
    	String password = form.getPassword();
    	String verifyPassword = form.getVerifyPassword();
    	
    	if (!passwordChangeService.exists(userCode, oldPassword)) {
            String message = messageSource.getMessage("PasswordChange.update.NotExists.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
            
            return modelView;
    	}
    	
    	if (!password.equals(verifyPassword)) {
            String message = messageSource.getMessage("PasswordChange.update.Unequal.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
            
            return modelView;
    	}
    	
    	if (password.equals(oldPassword)) {
            String message = messageSource.getMessage("PasswordChange.update.equal.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
            
            return modelView;
    	}
    	
		UserMaster user = new UserMaster();
		user.setUserCode(form.getUserCode());
		user.setPassword(form.getPassword());
		user.setOldPassword(form.getOldPassword());
		
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String Date = df.format(new Date()).toString();
		user.setPasswordChangeDate(Date);

    	String logInUser = form.getUserCode();
    	user.setUpdateUser(logInUser);
    	user.setUpdateDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setUpdateTime(CommonUtility.getSysDateTime().get("TIME"));
    	
		passwordChangeService.updateUserPassword(user);

        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        return modelView;
	}
}



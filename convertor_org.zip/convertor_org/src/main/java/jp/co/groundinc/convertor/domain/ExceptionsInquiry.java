package jp.co.groundinc.convertor.domain;

public class ExceptionsInquiry {
	
	private String exceptionDateStart;
	
	private String exceptionDateEnd;
	
	private String exceptionDate;
	
	private String sku;

	private String skuName;

	private String exceptionQty;
   

	public String getExceptionDateStart() {
		return exceptionDateStart;
	}

	public void setExceptionDateStart(String exceptionDateStart) {
		this.exceptionDateStart = exceptionDateStart;
	}

	public String getExceptionDateEnd() {
		return exceptionDateEnd;
	}

	public void setExceptionDateEnd(String exceptionDateEnd) {
		this.exceptionDateEnd = exceptionDateEnd;
	}

	public String getExceptionDate() {
		return exceptionDate;
	}

	public void setExceptionDate(String exceptionDate) {
		this.exceptionDate = exceptionDate;
	}

	public String getExceptionQty() {
		return exceptionQty;
	}

	public void setExceptionQty(String exceptionQty) {
		this.exceptionQty = exceptionQty;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

}

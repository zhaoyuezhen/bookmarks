package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StockAdjustInquiry;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetail;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetailReports;
import jp.co.groundinc.convertor.service.StockAdjustInquiryService;
import jp.co.groundinc.convertor.web.form.StockAdjustInquiryForm;
import jp.co.groundinc.convertor.web.form.StockInquiryDetailForm;
import jp.co.groundinc.convertor.web.report.StockAdjustInquiryDetailReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class StockAdjustInquiryDetailController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	StockAdjustInquiryService stockAdjustInquiryService;

	@Autowired
	MessageSource messageSource;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("stockInquiryDetailForm")
	public StockInquiryDetailForm stockInquiryDetailForm() {
		logger.info("--- StockAdjustInquiryDetailController.stockInquiryDetailForm() start ---");
		return new StockInquiryDetailForm();
	}

	@RequestMapping(value = "/stockAdjustInquiryDetail")
	public ModelAndView stockAdjustInquiryDetail(@RequestParam("auditNo") String auditNo, ModelAndView modelView) {
		modelView.setViewName("/stock_adjust_inquiry_detail");
		logger.info("--- StockAdjustInquiryDetailController.stockAdjustInquiryDetail() start ---");
		List<StockAdjustInquiryDetail> stockAdjustInquiryDetailList = stockAdjustInquiryService.findStockAdjustInquiryDetailInfo(auditNo);
		//List<Integer> reauditCountList = new ArrayList<Integer>();
		//Map<Integer,Integer> indexCountMap =new HashMap<Integer,Integer>();
		List<Integer> indexList = new ArrayList<Integer>();
		for (int i = 0; i < stockAdjustInquiryDetailList.size(); i++) {
		
				String str = stockAdjustInquiryDetailList.get(i).getExpectedQty() + "／"
						+ stockAdjustInquiryDetailList.get(i).getResultQty() + "／"
						+ stockAdjustInquiryDetailList.get(i).getDiffQty()+ "／"
						+ stockAdjustInquiryDetailList.get(i).getExtraQty();
				stockAdjustInquiryDetailList.get(i).setErd(str);
				
				if((stockAdjustInquiryDetailList.get(i).getOperatedDate() == null) || (stockAdjustInquiryDetailList.get(i).getOperatedTime() == null)){
			    	if((stockAdjustInquiryDetailList.get(i).getOperatedDate() == null)){
					    String operatedDateTime = "";
					    stockAdjustInquiryDetailList.get(i).setOperatedDateTime(operatedDateTime);
			    	}
			    	 if((stockAdjustInquiryDetailList.get(i).getOperatedTime() == null)){
					     String operatedDateTime = "";
					     stockAdjustInquiryDetailList.get(i).setOperatedDateTime(operatedDateTime);
					  }	
			     }else{
					     String operatedDateTime = stockAdjustInquiryDetailList.get(i).getOperatedDate()+stockAdjustInquiryDetailList.get(i).getOperatedTime();
					     String newOperatedDateTime = CommonUtility.getDateTime(operatedDateTime);
					     stockAdjustInquiryDetailList.get(i).setOperatedDateTime(newOperatedDateTime);
			    }
				if(stockAdjustInquiryDetailList.get(i).getIrregularKindName().equals("イレギュラーあり")){
					
					Integer iMaxCount=0;
					if(indexList.size() ==0){
						indexList.add(i);
						iMaxCount = Integer.parseInt(stockAdjustInquiryDetailList.get(i).getReauditCount());
					}else{
						if(iMaxCount==Integer.parseInt(stockAdjustInquiryDetailList.get(i).getReauditCount())){
							indexList.add(i);
						}else{
							break;
						}
					}
				}
			 	
		}
		for(Integer i : indexList){
			stockAdjustInquiryDetailList.get(i).setCheckBoxFlag("true");
		}
		StockAdjustInquiry stockAdjustInquiry = stockAdjustInquiryService.findStockAdjustInquiryInfo(auditNo);
		modelView.addObject("stockAdjustInquirys", stockAdjustInquiry);
		modelView.addObject("stockAdjustInquiryDetailList", stockAdjustInquiryDetailList);
		return modelView;
	}
	
	@RequestMapping(value = "/stockAdjustInquiryDetail", params = "action=Detailback")
	public ModelAndView Detailback(ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- search() start ---");
		modelView.setViewName("/stock_adjust_inquiry");
		StockAdjustInquiryForm stockAdjustInquiryForm = (StockAdjustInquiryForm)request.getSession().getAttribute("stockAdjustInquiryForm");
		String startDateStart = stockAdjustInquiryForm.getStartDateStart();
		String startDateEnd = stockAdjustInquiryForm.getStartDateEnd();
		String maxReauditCount =stockAdjustInquiryForm.getMaxReauditCount();
		modelView.addObject("operationDateStart", startDateStart);
		modelView.addObject("operationDateEnd", startDateEnd);
		modelView.addObject("maxReauditCount", maxReauditCount);
		
		String auditNoStart = stockAdjustInquiryForm.getAuditNoStart();
		String auditNoEnd = stockAdjustInquiryForm.getAuditNoEnd();
		String startTime = stockAdjustInquiryForm.getStartTime();
		String irregularKind = stockAdjustInquiryForm.getIrregularKind();
		String irregularKindName = stockAdjustInquiryForm.getIrregularKindName();
		String auditId = stockAdjustInquiryForm.getAuditId();
		String auditTypeName = stockAdjustInquiryForm.getAuditTypeName();
		String auditParamValueFrom = stockAdjustInquiryForm.getAuditParamValueFrom();
		String auditParamValueTo = stockAdjustInquiryForm.getAuditParamValueTo();
		String auditParamValue = stockAdjustInquiryForm.getAuditParamValue();
		String expectedCount = stockAdjustInquiryForm.getExpectedCount();
		String resultCount = stockAdjustInquiryForm.getResultCount();
		String targetCount = stockAdjustInquiryForm.getTargetCount();
		StockAdjustInquiry stockAdjustInquiry = new StockAdjustInquiry();
		stockAdjustInquiry.setAuditNoStart(auditNoStart);
		stockAdjustInquiry.setAuditNoEnd(auditNoEnd);
		stockAdjustInquiry.setStartDateStart(startDateStart);
		stockAdjustInquiry.setStartDateEnd(startDateEnd);
		stockAdjustInquiry.setStartTime(startTime);
		stockAdjustInquiry.setIrregularKind(irregularKind);
		stockAdjustInquiry.setIrregularKindName(irregularKindName);
		stockAdjustInquiry.setAuditId(auditId);
		stockAdjustInquiry.setAuditParamValue(auditParamValue);
		stockAdjustInquiry.setAuditParamValueFrom(auditParamValueFrom);
		stockAdjustInquiry.setAuditParamValueTo(auditParamValueTo);
		stockAdjustInquiry.setAuditTypeName(auditTypeName);
		stockAdjustInquiry.setExpectedCount(expectedCount);
		stockAdjustInquiry.setResultCount(resultCount);
		stockAdjustInquiry.setTargetCount(targetCount);
		stockAdjustInquiry.setMaxReauditCount(Integer.parseInt(maxReauditCount));

		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())
				&& StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {

			String startDateFrom = stockAdjustInquiry.getStartDateStart();

			stockAdjustInquiry.setStartDateEnd(startDateFrom);
		}
		if (StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())
				&& !StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {

			String startDateTo = stockAdjustInquiry.getStartDateEnd();

			stockAdjustInquiry.setStartDateStart(startDateTo);
		}
		
		List<StockAdjustInquiry> stockAdjustList = stockAdjustInquiryService.findStockAdjustInquiry(stockAdjustInquiry);

		for (int i = 0; i < stockAdjustList.size(); i++) {
			
			if (StringUtils.isEmpty(stockAdjustList.get(i).getExpectedCount())) {
				stockAdjustList.get(i).setExpectedCount("");
			}
			if (StringUtils.isEmpty(stockAdjustList.get(i).getResultCount())) {
				stockAdjustList.get(i).setResultCount("");
			}
			if (!StringUtils.isEmpty(stockAdjustList.get(i).getStartDate())
					&& !StringUtils.isEmpty(stockAdjustList.get(i).getStartTime())) {
				String str = stockAdjustList.get(i).getStartDate() + stockAdjustList.get(i).getStartTime();
				String newstr = CommonUtility.getDateTime(str);
				stockAdjustList.get(i).setStartDateTime(newstr);
			}
		}
		modelView.addObject("stockAdjustList", stockAdjustList);
		modelView.addObject("stockAdjustInquiryForm", stockAdjustInquiryForm);
		return modelView;
	}
	
	@RequestMapping(value = "/stockAdjustInquiryDetail", params = "action=Registration")
	public ModelAndView Registration(@Validated @ModelAttribute("stockInquiryDetailForm") StockInquiryDetailForm stockInquiryDetailForm,
			BindingResult result,HttpServletRequest request)throws Exception {
		logger.info("--- StockAdjustInquiryDetailController.Registration() start ---");
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("/stock_adjust_inquiry_detail");
		StockAdjustInquiry stockAdjustInquiry = stockAdjustInquiryService.findStockAdjustInquiryInfo(stockInquiryDetailForm.getAuditNo());
		modelView.addObject("stockAdjustInquirys", stockAdjustInquiry);
		if (result.hasErrors()|| stockInquiryDetailForm.getAuditNoList()==null) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String [] auditNoList = null;
		String [] slotList = null;
		String [] skuList = null;
		
		auditNoList = stockInquiryDetailForm.getAuditNoList().split(",");
		
		if(stockInquiryDetailForm.getSlotList() !=null){
			slotList = stockInquiryDetailForm.getSlotList().split(",");
		}
		
		if(stockInquiryDetailForm.getSkuList() !=null){
			 skuList = stockInquiryDetailForm.getSkuList().split(",");
		}
		
		 UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Date dt = new Date();
			DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
			String sysDate = dfDate.format(dt);
			DateFormat dfTime = new SimpleDateFormat("HHmmss");
			String sysTime = dfTime.format(dt);
			String userId = userDetails.getUsername();
		 
		 if(stockInquiryDetailForm.getAuditTypeName().equals("スロット指定")){
			 String [] newslotList =null;
			 if(stockInquiryDetailForm.getSlotList() !=null && stockInquiryDetailForm.getSlotList().length()!=0){
					Set<String> set = new HashSet<String>();  
					set.addAll(Arrays.asList(slotList));  
					newslotList = set.toArray(new String[0]); 
				}
			 
			 for(int i=0;i<newslotList.length;i++){
				 StockAdjustInquiryDetail stockAdjustInquiryDetail = new StockAdjustInquiryDetail();
				 stockAdjustInquiryDetail.setAuditNo(auditNoList[i]);
				 if(slotList[i].length()>=1){
					 stockAdjustInquiryDetail.setAuditParamValue(slotList[i]); 
				 }else{
					 stockAdjustInquiryDetail.setAuditParamValue(""); 
				 }
				 stockAdjustInquiryDetail.setSendStatus(CommonConstant.SEND_STATUS);
				 stockAdjustInquiryDetail.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
				 stockAdjustInquiryDetail.setCreateDate(sysDate);
				 stockAdjustInquiryDetail.setCreateTime(sysTime);
				 stockAdjustInquiryDetail.setCreateUser(userId);
				 stockAdjustInquiryDetail.setUpdateDate(sysDate);
				 stockAdjustInquiryDetail.setUpdateTime(sysTime);
				 stockAdjustInquiryDetail.setUpdateUser(userId);
				 
				 stockAdjustInquiryService.insertAuditExpectationDetail(stockAdjustInquiryDetail); 
				 
			 }
			 
		 }else if(stockInquiryDetailForm.getAuditTypeName().equals("商品指定")){
			 for(int i=0;i<auditNoList.length;i++){
				 StockAdjustInquiryDetail stockAdjustInquiryDetail = new StockAdjustInquiryDetail();
				 stockAdjustInquiryDetail.setAuditNo(auditNoList[i]);
				 if(skuList[i].length()>=1){
					 stockAdjustInquiryDetail.setAuditParamValue(skuList[i]); 
				 }else{
					 stockAdjustInquiryDetail.setAuditParamValue(""); 
				 }
				 stockAdjustInquiryDetail.setSendStatus(CommonConstant.SEND_STATUS);
				 stockAdjustInquiryDetail.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
				 stockAdjustInquiryDetail.setCreateDate(sysDate);
				 stockAdjustInquiryDetail.setCreateTime(sysTime);
				 stockAdjustInquiryDetail.setCreateUser(userId);
				 stockAdjustInquiryDetail.setUpdateDate(sysDate);
				 stockAdjustInquiryDetail.setUpdateTime(sysTime);
				 stockAdjustInquiryDetail.setUpdateUser(userId);
				 
				 stockAdjustInquiryService.insertAuditExpectationDetail(stockAdjustInquiryDetail); 
				 break;
			 }
			 
		 }
		 if (auditNoList.length >= 1) {
			 StockAdjustInquiryDetailReport reprot = new StockAdjustInquiryDetailReport("StockAdjustInquiryDetailReport");
				List<StockAdjustInquiryDetailReports> stockAdjustInquiryDetailReportList = new ArrayList<StockAdjustInquiryDetailReports>();
				StockAdjustInquiryDetailReports stockAdjustInquiryDetailReports = new StockAdjustInquiryDetailReports();
				stockAdjustInquiryDetailReports.setAuditNo(auditNoList[0]);
				stockAdjustInquiryDetailReportList.add(stockAdjustInquiryDetailReports);
				
				reprot.buildDocument(stockAdjustInquiryDetailReportList, request);
				reprot.exportReport(auditNoList[0]);
			}
		 
		 List<StockAdjustInquiryDetail> stockAdjustInquiryDetailList = stockAdjustInquiryService.findStockAdjustInquiryDetailInfo(stockInquiryDetailForm.getAuditNo());
			for (int i = 0; i < stockAdjustInquiryDetailList.size(); i++) {
			
					String str = stockAdjustInquiryDetailList.get(i).getExpectedQty() + "／"
							+ stockAdjustInquiryDetailList.get(i).getResultQty() + "／"
							+ stockAdjustInquiryDetailList.get(i).getDiffQty()+ "／"
							+ stockAdjustInquiryDetailList.get(i).getExtraQty();
					stockAdjustInquiryDetailList.get(i).setErd(str);
				
				if (!StringUtils.isEmpty(stockAdjustInquiryDetailList.get(i).getOperatedDate())
						&& !StringUtils.isEmpty(stockAdjustInquiryDetailList.get(i).getOperatedTime())) {
					String operatedDateTime = stockAdjustInquiryDetailList.get(i).getOperatedDate() + stockAdjustInquiryDetailList.get(i).getOperatedTime();
					String newOperatedDateTime = CommonUtility.getDateTime(operatedDateTime);
					stockAdjustInquiryDetailList.get(i).setOperatedDateTime(newOperatedDateTime);
				 }	
			}
			
			
			//modelView.addObject("stockAdjustInquiryDetailList", stockAdjustInquiryDetailList);
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
}

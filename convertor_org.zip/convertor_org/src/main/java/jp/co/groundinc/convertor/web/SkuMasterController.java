package jp.co.groundinc.convertor.web;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.SkuMaster;
import jp.co.groundinc.convertor.domain.SkuMasterCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.SkuMasterService;
import jp.co.groundinc.convertor.web.form.SkuMasterForm;
@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "skuMasterForm", "checkStatus", "deletionKind"})
public class SkuMasterController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private final String  status ="1";
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	SkuMasterService skuMasterService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

    @ModelAttribute("skuMasterForm")
	public SkuMasterForm skuMasterForm() {
		logger.info("--- SkuMasterController.skuMasterForm() start ---");
		
		return new SkuMasterForm();
	}

	@ModelAttribute("checkStatus")
	public List<Translate> checkStatus(HttpServletRequest request) {
		logger.info("--- SkuMasterController.checkStatus() start ---");
		return commonService.getTranslateList("CheckStatus");
	}
	
	@ModelAttribute("deletionKind")
	public List<Translate> deletionKind(HttpServletRequest request) {
		logger.info("--- SkuMasterController.deletionKind() start ---");
		return commonService.getTranslateList("DeletionKind");
	}
	
	@RequestMapping("/sku_master")
	public SkuMasterForm viewSkuMaster(Model model, HttpServletRequest request) {
		logger.info("--- SkuMasterController.viewSkuMaster() start ---");
		SkuMasterForm skuMasterForm = new SkuMasterForm();
		request.getSession().setAttribute("productname", "");
		return skuMasterForm;
	}


	@RequestMapping(value = "/sku_master", params = "action=clear")
	public String skuMasterClear(HttpServletRequest request, Model model,SessionStatus status) throws ParseException {
		logger.info("--- skuMasterClear() start ---");
		SkuMasterForm skuMasterForm = (SkuMasterForm)request.getSession().getAttribute("skuMasterForm");
		skuMasterForm.setSku(null);
		skuMasterForm.setStockStatus(null);
		skuMasterForm.setCheckStatus(null);
		skuMasterForm.setSkuName(null);
		skuMasterForm.setDeletionKind(null);
		skuMasterForm.setUpdateUser(null);
		model.addAttribute("SkuMaster", skuMasterForm);
		request.getSession().setAttribute("productname", "");
		return "sku_master";
	}

	@RequestMapping(value = "/sku_master", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("skuMasterForm") SkuMasterForm skuMasterForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- search() start ---");
		modelView.setViewName("/sku_master");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String sku = skuMasterForm.getSku();
		if(StringUtils.isEmpty(sku)){
			request.getSession().setAttribute("productname", "");
		}
		String skuName = skuMasterForm.getSkuName();
		String checkStatus = skuMasterForm.getCheckStatus();
		String deletionKind = skuMasterForm.getDeletionKind();
		String updateUser = skuMasterForm.getUpdateUser();
		SkuMaster skuMaster = new SkuMaster();
		skuMaster.setSku(sku);
		skuMaster.setSkuName(skuName);
		skuMaster.setCheckStatus(checkStatus);
		skuMaster.setDeletionKind(deletionKind);
		skuMaster.setUpdateUser(updateUser);
		int count  = commonService.selectTableUpperLimitCount();
	    int ProductCount = skuMasterService.selectProductCount(skuMaster);
		if(count<=ProductCount){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<SkuMaster> skuList = skuMasterService.selectSkuMaster(skuMaster);
		
		if (CollectionUtils.isEmpty(skuList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		for (int i = 0; i < skuList.size(); i++) {
			BigDecimal BD = new   BigDecimal(Double.toString(skuList.get(i).getLogisticsCbm()));
			BigDecimal setScale = BD.setScale(6,BigDecimal.ROUND_HALF_DOWN);
			skuList.get(i).setLogisticsCbm1(String.valueOf(setScale));
			if (!StringUtils.isEmpty(skuList.get(i).getUpdateDate()) && !StringUtils.isEmpty(skuList.get(i).getUpdateTime())) {
				String str = skuList.get(i).getUpdateDate() + skuList.get(i).getUpdateTime();
				String newstr = CommonUtility.getDateTime(str);
				skuList.get(i).setUpdateDateTime(newstr);
				
			}
			if(skuList.get(i).getLogisticsSkuWeight()!=null){
				String logisticsSkuWeight = skuList.get(i).getLogisticsSkuWeight().multiply(new BigDecimal("1000")).toString();
				String logisticsSkuWeightt = logisticsSkuWeight.substring(0, logisticsSkuWeight.indexOf("."));
				BigDecimal logisticsSkuWeighttf=new BigDecimal(logisticsSkuWeightt);
				skuList.get(i).setLogisticsSkuWeight(logisticsSkuWeighttf);
			}
		}
		modelView.addObject("skuList", skuList);
		return modelView;
	}
	@RequestMapping(value = "/sku_master", params = "action=update")
	public ModelAndView statusUpdate(@Validated @ModelAttribute("skuMasterForm") SkuMasterForm skuMasterForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- statusUpdate() start ---");
		modelView.setViewName("/sku_master");
		String[] skuCode = skuMasterForm.getSkug();
		if (skuCode == null || skuCode.length == 0) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate= dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime= dfTime.format(dt);
		String logInUser = userDetails.getUsername();
		for(int i=0;i<skuCode.length;i++){
			SkuMaster skuMaster = new SkuMaster();
			skuMaster.setCheckStatus(status);
			skuMaster.setSku(skuCode[i]);
		    skuMaster.setUpdateUser(logInUser);
		    skuMaster.setUpdateDate(sysDate);
		    skuMaster.setUpdateTime(sysTime);
		    skuMasterService.updateSkuMaster(skuMaster);	
		}
		SkuMasterForm skuMasterForm1 = (SkuMasterForm)request.getSession().getAttribute("skuMasterForm");
		skuMasterForm1.setSkug(null);
		String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
		modelView.addObject("validationMessage", message);
		return modelView;
	}
	@RequestMapping(value = "/sku_master", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("skuMasterForm") SkuMasterForm skuMasterForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- SkuMasterController.download() start ---");
		modelView.setViewName("/sku_master");
		String sku = skuMasterForm.getSku();
		String skuName = skuMasterForm.getSkuName();
		String checkStatus = skuMasterForm.getCheckStatus();
		String checkStatusName = skuMasterForm.getCheckStatusName();
		String deletionKind = skuMasterForm.getDeletionKind();
		String updateUser = skuMasterForm.getUpdateUser();
		
		SkuMaster skuMaster = new SkuMaster();
		skuMaster.setSku(sku);
		skuMaster.setSkuName(skuName);
		skuMaster.setCheckStatus(checkStatus);
		skuMaster.setCheckStatusName(checkStatusName);
		skuMaster.setDeletionKind(deletionKind);
		skuMaster.setUpdateUser(updateUser);
		
		int count  = commonService.selectTableUpperCSVLimitCount();
	    int ProductCount = skuMasterService.selectProductCount(skuMaster);
		if(count<=ProductCount){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<SkuMasterCsv> skuMasterCsvList = 
				skuMasterService.findSkuMasterCsv(
						sku, skuName, checkStatus, checkStatusName,deletionKind,updateUser);
		
		if (CollectionUtils.isEmpty(skuMasterCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/sku_master");
			return modelView;
		}
		
		modelView.addObject("skuMasterCsvList", skuMasterCsvList);
		modelView.setViewName("SkuMasterCsvView");
		
		return modelView;
	}
 }


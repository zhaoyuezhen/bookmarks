package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.PickList;
import jp.co.groundinc.convertor.domain.PickListCsv;
@Mapper
public interface PickListMapper {

	List<PickList> selectPickList();
	int selectCountt(PickList pickList);
	String selectOrderPick(); 
	String selectTotalPick(); 
	String selectNote1();
	String selectNote2();
	String selectNote3();
	String selectNote4();
	String selectNote5();
	String selectNote6();
	String selectNote7();
	String selectNote8();
	String selectNote9();
	String selectNote10();
	String selectNote11();
	String selectNote12();
	String selectNote13();
	String selectOrderProcessSeqence();
	int updateOrderAreaInterface(PickList pickList);
	int updateOrderSkuKindInterface(PickList pickList);
	List<PickListCsv> findPickListArea1OrderCsv(String processSequenceNo);
	List<PickListCsv> findPickListArea1TotaruCsv(String processSequenceNo);
	List<PickListCsv> findPickListArea29OrderCsv(PickList pickList);
	List<PickListCsv> findPickListArea29TotalCsv(PickList pickList);
	List<PickListCsv> findPickListArea1030OrderCsv(PickList pickList);
	List<PickListCsv> findPickListArea1030TotalCsv(PickList pickList);
	void insertPrintLog(PickList pickList);
	int updateAllMissingOrderInterface(String processSequence);
	
	List<PickListCsv> findPickListAllMissingCsv(String processSequence);
}

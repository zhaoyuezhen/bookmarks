package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.domain.StockAdjustIndication;
import jp.co.groundinc.convertor.domain.StockAdjustIndicationReports;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.StockAdjustIndicationService;
import jp.co.groundinc.convertor.web.form.StockAdjustIndicationForm;
import jp.co.groundinc.convertor.web.report.StockAdjustIndicationReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class StockAdjustIndicationController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CommonConstant commonConstant;

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	StockAdjustIndicationService stockAdjustIndicationService;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("stockAdjustIndicationForm")
	public StockAdjustIndicationForm stockAdjustIndicationForm() {
		logger.info("--- StockAdjustIndicationController.stockAdjustIndicationForm() start ---");
		return new StockAdjustIndicationForm();
	}

	@RequestMapping("/stockadjustindication")
	public String stockInstruction(Model model, HttpServletRequest request, SessionStatus status) {
		logger.info("--- StockAdjustIndicationController.stockInstruction() start ---");
		StockAdjustIndicationForm form = new StockAdjustIndicationForm();
		model.addAttribute("stockAdjustIndicationForm", form);
		return "stock_adjust_indication";
	}

	@RequestMapping(value = "/stockadjustindication", params = "action=back")
	public String viewPickInstructionBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- StockAdjustIndicationController.viewPickInstructionBack() start ---");
		status.setComplete();
		return "stock_menu";
	}

	@RequestMapping(value = "/stockadjustindication", params = "action=clear")
	public String inventoriesInstructionClear(Model model, SessionStatus status,
			@Validated @ModelAttribute("stockAdjustIndicationForm") StockAdjustIndicationForm stockAdjustIndicationForm)
			throws ParseException {
		logger.info("--- StockAdjustIndicationController.inventoriesInstructionClear() start ---");
		status.setComplete();
		String deClassification = stockAdjustIndicationForm.getClassification();
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			model.addAttribute("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			model.addAttribute("Classification", CommonConstant.SLOT);
		}
		stockAdjustIndicationForm.setMsuIdEnd(null);
		stockAdjustIndicationForm.setMsuIdStart(null);
		stockAdjustIndicationForm.setMsuSideEnd(null);
		stockAdjustIndicationForm.setMsuSideStart(null);
		stockAdjustIndicationForm.setMsuStepEnd(null);
		stockAdjustIndicationForm.setMsuStepStart(null);
		stockAdjustIndicationForm.setSkuStart(null);
		stockAdjustIndicationForm.setSkuEnd(null);
		model.addAttribute("stockAdjustIndicationForm", stockAdjustIndicationForm);
		return "stock_adjust_indication";
	}

	@RequestMapping(value = "/stockadjustindication", params = "action=search")
	public ModelAndView selectInventoriesInstructionInfo(
			@Validated @ModelAttribute("stockAdjustIndicationForm") StockAdjustIndicationForm stockAdjustIndicationForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- selectInventoriesInstructionInfo() start ---");
		modelView.setViewName("/stock_adjust_indication");
		String deClassification = stockAdjustIndicationForm.getClassification();
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			modelView.addObject("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			modelView.addObject("Classification", CommonConstant.SLOT);
		}
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		if (stockAdjustIndicationForm.getClassification().equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			String skuStart = stockAdjustIndicationForm.getSkuStart();
			String skuEnd = stockAdjustIndicationForm.getSkuEnd();

			if (!StringUtils.isEmpty(skuStart) && StringUtils.isEmpty(skuEnd)) {
				skuEnd = skuStart;
			}
			if (StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
				skuStart = skuEnd;
			}
			if (!StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {

				Matcher skuStartm = Pattern.compile(CommonConstant.REGEX).matcher(skuStart);
				Matcher skuEndm = Pattern.compile(CommonConstant.REGEX).matcher(skuEnd);
				if (!skuStartm.matches() && !skuEndm.matches()) {
					if (Integer.valueOf(skuStart).intValue() > Integer.valueOf(skuEnd).intValue()) {
						String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
						modelView.addObject("validationMessage", message);
						String skuerror = messageSource.getMessage("InventoriesInstruction.sku.message", null,
								Locale.JAPAN);
						modelView.addObject("skuerror", skuerror);
						return modelView;
					}
				}
			}

			StockAdjustIndication stockAdjustIndication = new StockAdjustIndication();
			stockAdjustIndication.setSkuStart(skuStart);
			stockAdjustIndication.setSkuEnd(skuEnd);
			int count = commonService.selectTableUpperLimitCount();
			int ProductCount = stockAdjustIndicationService.selectProductCount(stockAdjustIndication);
			if (count <= ProductCount) {
				String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			List<StockAdjustIndication> productInfolist = stockAdjustIndicationService
					.findProductInfo(stockAdjustIndication);
			if (CollectionUtils.isEmpty(productInfolist)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			modelView.addObject("inventoriesInstructionList", productInfolist);
		} else {
			String msuIdStart = stockAdjustIndicationForm.getMsuIdStart();
			String msuSideStart = stockAdjustIndicationForm.getMsuSideStart();
			String msuStepStart = stockAdjustIndicationForm.getMsuStepStart();
			String msuIdEnd = stockAdjustIndicationForm.getMsuIdEnd();
			String msuSideEnd = stockAdjustIndicationForm.getMsuSideEnd();
			String msuStepEnd = stockAdjustIndicationForm.getMsuStepEnd();
			String slotErrorStart = this.slotCheck(msuIdStart, msuSideStart, msuStepStart);
			String slotErrorEnd = this.slotCheck(msuIdEnd, msuSideEnd, msuStepEnd);
			if (slotErrorStart != null) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.addObject("sloterror", slotErrorStart);
				return modelView;
			}
			if (slotErrorEnd != null) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.addObject("sloterror", slotErrorEnd);
				return modelView;
			}

			StockAdjustIndication stockAdjustIndication = new StockAdjustIndication();
			stockAdjustIndication.setMsuIdStart(msuIdStart);
			stockAdjustIndication.setMsuIdEnd(msuIdEnd);
			stockAdjustIndication.setMsuSideStart(msuSideStart);
			stockAdjustIndication.setMsuSideEnd(msuSideEnd);
			stockAdjustIndication.setMsuStepStart(msuStepStart);
			stockAdjustIndication.setMsuStepEnd(msuStepEnd);
			/*String locationStart = this.getLocitionStart(msuIdStart, msuSideStart, msuStepStart);
			String locationEnd = this.getLocitionEnd(msuIdEnd, msuSideEnd, msuStepEnd);
			stockAdjustIndication.setLocationEnd(locationEnd);
			stockAdjustIndication.setLocationStart(locationStart);*/
			int count = commonService.selectTableUpperLimitCount();
			int slotCount = stockAdjustIndicationService.selectSlotCountp(stockAdjustIndication);
			if (count <= slotCount) {
				String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			List<StockAdjustIndication> Locationlist = stockAdjustIndicationService
					.findLocationInfo(stockAdjustIndication);
			if (CollectionUtils.isEmpty(Locationlist)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			modelView.addObject("inventoriesInstructionList", Locationlist);
		}
		return modelView;
	}

	@RequestMapping(value = "/stockadjustindication", params = "action=inventoriesInstruction")
	public ModelAndView insertInventoriesInstruction(
			@Validated @ModelAttribute("stockAdjustIndicationForm") StockAdjustIndicationForm stockAdjustIndicationForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) throws Exception {
		logger.info("--- selectInventoriesInstructionInfo() start ---");
		String deClassification = stockAdjustIndicationForm.getClassification();
		modelView.setViewName("/stock_adjust_indication");
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			modelView.addObject("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			modelView.addObject("Classification", CommonConstant.SLOT);
		}
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("hhmmss");
		String sysTime = dfTime.format(dt);
		String Seqence = stockAdjustIndicationService.selectAuditSeqence().trim();
		if (stockAdjustIndicationForm.getClassification().equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			String[] skuCode = stockAdjustIndicationForm.getSkus();
			if (skuCode == null || skuCode.length == 0) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			StockAdjustIndication stockAdjustIndication = new StockAdjustIndication();
			stockAdjustIndication.setAuditNo(Seqence);
			stockAdjustIndication.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
			stockAdjustIndication.setAuditParamValueFrom(skuCode[0]);
			stockAdjustIndication.setAuditParamValueTo(skuCode[skuCode.length - 1]);
			stockAdjustIndication.setTargetSlotCount(stockAdjustIndicationForm.getSlotCounts());
			stockAdjustIndication.setAuditStockKind(CommonConstant.KY_AUDIT_STOCK_KIND);
			stockAdjustIndication.setStartDate(sysDate);
			stockAdjustIndication.setStartTime(sysTime);
			stockAdjustIndication.setUpdateUser(userDetails.getUsername());
			stockAdjustIndication.setUpdateDate(sysDate);
			stockAdjustIndication.setUpdateTime(sysTime);
			stockAdjustIndication.setCreateUser(userDetails.getUsername());
			stockAdjustIndication.setCreateDate(sysDate);
			stockAdjustIndication.setCreateTime(sysTime);
			stockAdjustIndicationService.insertauditException(stockAdjustIndication);
			for (int i = 0; i < skuCode.length; i++) {
				List<StockAdjustIndication> ViewstockDetailList = stockAdjustIndicationService
						.selectViewStockDetail(skuCode[i]);
			/*	for (int j = 0; j < ViewstockDetailList.size(); j++) {
					StockAdjustIndication stockAdjustIndicationd = new StockAdjustIndication();
					stockAdjustIndicationd.setAuditNo(Seqence);
					stockAdjustIndicationd.setAuditParamValue(ViewstockDetailList.get(j).getSkuDetail());
					stockAdjustIndicationd.setLocation(ViewstockDetailList.get(j).getLocation());
					stockAdjustIndicationd.setStockQty(ViewstockDetailList.get(j).getStockQty());
					stockAdjustIndicationd.setSku(ViewstockDetailList.get(j).getSkuDetail());
					stockAdjustIndicationd.setUpdateUser(userDetails.getUsername());
					stockAdjustIndicationd.setUpdateDate(sysDate);
					stockAdjustIndicationd.setUpdateTime(sysTime);
					stockAdjustIndicationd.setCreateUser(userDetails.getUsername());
					stockAdjustIndicationd.setCreateDate(sysDate);
					stockAdjustIndicationd.setCreateTime(sysTime);
					stockAdjustIndicationService.insertAuditStock(stockAdjustIndicationd);

				}*/

				StockAdjustIndication AuditExceptionDetailSku = new StockAdjustIndication();
				AuditExceptionDetailSku.setAuditNo(Seqence);
				AuditExceptionDetailSku.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
				AuditExceptionDetailSku.setAuditParamValue(skuCode[i]);
				AuditExceptionDetailSku.setSendStatus(CommonConstant.SEND_STATUS);
				AuditExceptionDetailSku.setUpdateUser(userDetails.getUsername());
				AuditExceptionDetailSku.setUpdateDate(sysDate);
				AuditExceptionDetailSku.setUpdateTime(sysTime);
				AuditExceptionDetailSku.setCreateUser(userDetails.getUsername());
				AuditExceptionDetailSku.setCreateDate(sysDate);
				AuditExceptionDetailSku.setCreateTime(sysTime);
				stockAdjustIndicationService.insertAuditExceptionDetail(AuditExceptionDetailSku);

			}
			List<StockAdjustIndicationReports> stockAdjustIndicationReportsList = stockAdjustIndicationService
					.findStockAdjustIndicationReports(Seqence);

			if (CollectionUtils.isEmpty(stockAdjustIndicationReportsList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.setViewName("/stock_adjust_indication");
				return modelView;
			}

			StockAdjustIndicationReport reprot = new StockAdjustIndicationReport("StockAdjustIndicationReport");
			reprot.buildDocument(stockAdjustIndicationReportsList, request);
			reprot.exportReport(Seqence);
			modelView.setViewName("/stock_adjust_indication");
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);

			return modelView;
		} else {
			String[] locations = stockAdjustIndicationForm.getLocations();
			if (locations == null || locations.length == 0) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			StockAdjustIndication stockAdjustIndication = new StockAdjustIndication();
			stockAdjustIndication.setAuditNo(Seqence);
			stockAdjustIndication.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
			stockAdjustIndication.setAuditParamValueFrom(locations[0]);
			stockAdjustIndication.setAuditParamValueTo(locations[locations.length - 1]);
			stockAdjustIndication.setTargetSlotCount(Integer.toString(locations.length));
			stockAdjustIndication.setAuditStockKind(CommonConstant.KY_AUDIT_STOCK_KIND);
			stockAdjustIndication.setStartDate(sysDate);
			stockAdjustIndication.setStartTime(sysTime);
			stockAdjustIndication.setUpdateUser(userDetails.getUsername());
			stockAdjustIndication.setUpdateDate(sysDate);
			stockAdjustIndication.setUpdateTime(sysTime);
			stockAdjustIndication.setCreateUser(userDetails.getUsername());
			stockAdjustIndication.setCreateDate(sysDate);
			stockAdjustIndication.setCreateTime(sysTime);
			stockAdjustIndicationService.insertauditException(stockAdjustIndication);

			for (int i = 0; i < locations.length; i++) {
				/*List<StockAdjustIndication> ViewstockDetailLocation = stockAdjustIndicationService
						.selectViewStockDetailLocation(locations[i]);
				if (!CollectionUtils.isEmpty(ViewstockDetailLocation)) {
					for(int j=0;j<ViewstockDetailLocation.size();j++){
					StockAdjustIndication euditStock = new StockAdjustIndication();
					euditStock.setAuditNo(Seqence);
					euditStock.setLocation(locations[i]);
					euditStock.setSku(ViewstockDetailLocation.get(j).getSkuDetail());
					euditStock.setStockQty(ViewstockDetailLocation.get(j).getStockQty());
					euditStock.setUpdateUser(userDetails.getUsername());
					euditStock.setUpdateDate(sysDate);
					euditStock.setUpdateTime(sysTime);
					euditStock.setCreateUser(userDetails.getUsername());
					euditStock.setCreateDate(sysDate);
					euditStock.setCreateTime(sysTime);
					stockAdjustIndicationService.insertAuditStock(euditStock);
					}
				} else {
					StockAdjustIndication euditStock1 = new StockAdjustIndication();
					euditStock1.setAuditNo(Seqence);
					euditStock1.setLocation(locations[i]);
					euditStock1.setSku(null);
					euditStock1.setUpdateUser(userDetails.getUsername());
					euditStock1.setUpdateDate(sysDate);
					euditStock1.setUpdateTime(sysTime);
					euditStock1.setCreateUser(userDetails.getUsername());
					euditStock1.setCreateDate(sysDate);
					euditStock1.setCreateTime(sysTime);
					stockAdjustIndicationService.insertAuditStock(euditStock1);

				}*/
				StockAdjustIndication uditExceptionDetialslot = new StockAdjustIndication();
				uditExceptionDetialslot.setAuditNo(Seqence);
				uditExceptionDetialslot.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
				uditExceptionDetialslot.setAuditParamValue(locations[i]);
				uditExceptionDetialslot.setSendStatus(CommonConstant.SEND_STATUS);
				uditExceptionDetialslot.setUpdateUser(userDetails.getUsername());
				uditExceptionDetialslot.setUpdateDate(sysDate);
				uditExceptionDetialslot.setUpdateTime(sysTime);
				uditExceptionDetialslot.setCreateUser(userDetails.getUsername());
				uditExceptionDetialslot.setCreateDate(sysDate);
				uditExceptionDetialslot.setCreateTime(sysTime);
				stockAdjustIndicationService.insertAuditExceptionDetail(uditExceptionDetialslot);
			}

			List<StockAdjustIndicationReports> stockAdjustIndicationReportsList = stockAdjustIndicationService
					.findStockAdjustIndicationReports(Seqence);

			if (CollectionUtils.isEmpty(stockAdjustIndicationReportsList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.setViewName("/stock_adjust_indication");
				return modelView;
			}

			StockAdjustIndicationReport reprot = new StockAdjustIndicationReport("StockAdjustIndicationReport");
			reprot.buildDocument(stockAdjustIndicationReportsList, request);
			reprot.exportReport(Seqence);
			modelView.setViewName("/stock_adjust_indication");
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);

			return modelView;
		}
	}


	private String slotCheck(String msuId, String msuSide, String msuStep) {

		String slotrror = null;
		if (!StringUtils.isEmpty(msuId) && StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {

			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;

		}
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {

			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		return slotrror;
	}

}

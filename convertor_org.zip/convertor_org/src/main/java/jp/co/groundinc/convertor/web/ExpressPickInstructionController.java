package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.ExpressPickInstruction;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.ExpressPickInstructionService;
import jp.co.groundinc.convertor.web.form.ExpressPickInstructionForm;
import jp.co.groundinc.convertor.web.utility.DatePropertyEditor;
import jp.co.groundinc.convertor.web.utility.TimePropertyEditor;

@Controller
@EnableAutoConfiguration
@SessionAttributes (value = { "expressPickInstructionForm" }) 

public class ExpressPickInstructionController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	ExpressPickInstructionService expressPickInstructionService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		dataBinder.registerCustomEditor(String.class, "pickDateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "pickDateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataRecievedDateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataRecievedDateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataRecievedTimeStart", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataRecievedTimeEnd", new TimePropertyEditor());
		
	}
	@ModelAttribute("pickDateStart")
	public String pickDateStart() throws ParseException {
		logger.info("--- ExpressPickInstructionController.pickDateStart() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("pickDateEnd")
	public String pickDateEnd() throws ParseException {
		logger.info("--- ExpressPickInstructionController.pickDateEnd() start ---");
		String newExpecteddateend =null;
		String expecteddateend = commonService.getOperationDate();
		if(!StringUtils.isEmpty(expecteddateend)){
			newExpecteddateend = commonService.getSpecifiedDayAfter(expecteddateend);
		}
		return newExpecteddateend;
	}

	@ModelAttribute("expressPickInstructionForm")
	public ExpressPickInstructionForm expressPickInstructionForm() {
		logger.info("--- ExpressPickInstructionController.expressPickInstructionForm() start ---");
		return new ExpressPickInstructionForm();
	}

	@RequestMapping("/express_pick_instruction")
	public ModelAndView expressPick(ModelAndView modelView) throws ParseException {
		logger.info("--- ExpressPickInstructionController.expressPick() start ---");
		modelView.setViewName("/express_pick_instruction");
		
		String opDate = commonService.getOperationDate();
		ExpressPickInstructionForm form = new ExpressPickInstructionForm();
		form.setPickDateStart(opDate);
		form.setPickDateEnd(commonService.getSpecifiedDayAfter(opDate));

		modelView.addObject("expressPickInstructionForm", form);

		return modelView;
	}

	@RequestMapping(value = "/express_pick_instruction", params = "action=clear")
	public ModelAndView expressPickClear(HttpServletRequest request, ModelAndView modelView) throws ParseException {
		logger.info("--- expressPickClear() start ---");
		String opDate = commonService.getOperationDate();
		ExpressPickInstructionForm form = new ExpressPickInstructionForm();
		form.setPickDateStart(opDate);
		form.setPickDateEnd(commonService.getSpecifiedDayAfter(opDate));

		modelView.addObject("expressPickInstructionForm", form);
		return modelView;
	}

	@RequestMapping(value = "/express_pick_instruction", params = "action=search")
	public ModelAndView search(
			@Validated @ModelAttribute("expressPickInstructionForm") ExpressPickInstructionForm expressPickInstructionForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- ExpressPickInstructionController.search() start ---");
		modelView.setViewName("/express_pick_instruction");
		
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String pickDateStart = expressPickInstructionForm.getPickDateStart();
		String pickDateEnd = expressPickInstructionForm.getPickDateEnd();

		if (!StringUtils.isEmpty(pickDateStart) && !StringUtils.isEmpty(pickDateEnd)) {
			if (CommonUtility.compareDate(pickDateStart, pickDateEnd)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationDate = messageSource.getMessage(
						"ExpressPickInstruction.search.pickDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("operationDate", operationDate);
				return modelView;
			}
		}
		if (!StringUtils.isEmpty(pickDateStart) && StringUtils.isEmpty(pickDateEnd)) {
			String dataStart = expressPickInstructionForm.getPickDateStart();
			expressPickInstructionForm.setPickDateEnd(dataStart);

		}
		
		
		String dataRecievedDateStart = expressPickInstructionForm.getDataRecievedDateStart();
		String dataRecievedTimeStart = expressPickInstructionForm.getDataRecievedTimeStart();
		if (StringUtils.isEmpty(dataRecievedTimeStart)) {
			dataRecievedTimeStart = "000000";
		} else {
			dataRecievedTimeStart = dataRecievedTimeStart + "00";
		}
		
		String dataRecievedDateEnd = expressPickInstructionForm.getDataRecievedDateEnd();
		String dataRecievedTimeEnd = expressPickInstructionForm.getDataRecievedTimeEnd();
		if (StringUtils.isEmpty(dataRecievedTimeEnd)) {
			dataRecievedTimeEnd = "235959";
		} else {
			dataRecievedTimeEnd = dataRecievedTimeEnd + "59";
		}
		
		if (!StringUtils.isEmpty(dataRecievedDateStart) && !StringUtils.isEmpty(dataRecievedDateEnd)) {
			String recievedDateTimeStart = dataRecievedDateStart + " " + dataRecievedTimeStart;
			String recievedDateTimeEnd = dataRecievedDateEnd + " " + dataRecievedTimeEnd;
			
			if (CommonUtility.compareDateTime(recievedDateTimeStart, recievedDateTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String recievedDateErrors = messageSource.getMessage(
						"ExpressPickInstruction.search.recievedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("recievedDateErrors", recievedDateErrors);
				return modelView;
			}
		} else if (!StringUtils.isEmpty(dataRecievedDateStart) && StringUtils.isEmpty(dataRecievedDateEnd)) {
			dataRecievedDateEnd = dataRecievedDateStart;
		} else if (StringUtils.isEmpty(dataRecievedDateStart) && !StringUtils.isEmpty(dataRecievedDateEnd)) {
			dataRecievedDateStart = dataRecievedDateEnd;
		} else {
			dataRecievedDateStart = "";
			dataRecievedTimeStart = "";
			dataRecievedDateEnd = "";
			dataRecievedTimeEnd = "";
		}
		
		ExpressPickInstruction expressPickInstruction = new ExpressPickInstruction();
		expressPickInstruction.setPickDateStart(expressPickInstructionForm.getPickDateStart());
		expressPickInstruction.setPickDateEnd(expressPickInstructionForm.getPickDateEnd());
		expressPickInstruction.setOrderId(expressPickInstructionForm.getOrderId());
		expressPickInstruction.setDataReceivedDateTimeStart(dataRecievedDateStart + dataRecievedTimeStart);
		expressPickInstruction.setDataReceivedDateTimeEnd(dataRecievedDateEnd + dataRecievedTimeEnd);

		expressPickInstructionForm.setDataRecievedDateStart(dataRecievedDateStart);
		expressPickInstructionForm.setDataRecievedDateEnd(dataRecievedDateEnd);
		expressPickInstructionForm.setDataRecievedTimeStart(dataRecievedTimeStart.length() >= 4 ? dataRecievedTimeStart.substring(0,4) : "");
		expressPickInstructionForm.setDataRecievedTimeEnd(dataRecievedTimeStart.length() >= 4 ? dataRecievedTimeEnd.substring(0,4) : "");
		int count = commonService.selectTableUpperLimitCount();
		int ProductCount = expressPickInstructionService.selectProductCount(expressPickInstruction);
		if (count <= ProductCount) {
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<ExpressPickInstruction> expressPickInstructionList = expressPickInstructionService
				.findExpressPickInstruction(expressPickInstruction);

		if (CollectionUtils.isEmpty(expressPickInstructionList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		for(int i = 0;i < expressPickInstructionList.size();i++){
			if (!StringUtils.isEmpty(expressPickInstructionList.get(i).getDataRecievedDate())
					&& !StringUtils.isEmpty(expressPickInstructionList.get(i).getDataRecievedTime())) {
				String oldDateTime1 =  expressPickInstructionList.get(i).getDataRecievedDate() + expressPickInstructionList.get(i).getDataRecievedTime();
				String dataReceivedDateTime=  CommonUtility.getDateTime1(oldDateTime1);
				String dataReceivedDateTime1 =  dataReceivedDateTime.substring(2, dataReceivedDateTime.length());
				expressPickInstructionList.get(i).setDataReceivedDateTime(dataReceivedDateTime1);
			}
		}
		modelView.addObject("expressPickInstructionList", expressPickInstructionList);
		
	
		modelView.addObject("expressPickInstructionForm", expressPickInstructionForm);
		
		return modelView;

	}

	@RequestMapping(value = "/express_pick_instruction", params = "action=Registration")
	public ModelAndView registration(
			@Validated @ModelAttribute("expressPickInstructionForm") ExpressPickInstructionForm expressPickInstructionForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- ExpressPickInstructionController.registration() start ---");

		modelView.setViewName("/express_pick_instruction");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String[] orders = expressPickInstructionForm.getAuditNost();
		
		
		if (orders == null || orders.length == 0) {
			String message = messageSource.getMessage("expressPickInstruction.register.empty.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
	
		List<String> failureList = new ArrayList<String>(); 
		for (String order : orders) {
			if (!expressPickInstructionService.registerPickOrder(order)) {
				failureList.add(order.substring(0, order.indexOf("_")));
			}
		}
		
		if (failureList.isEmpty()) {
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
		} else {
			String message = messageSource.getMessage("expressPickInstruction.register.failure.message", 
					new String[]{String.join(",", failureList)}, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		String userId = userDetails.getUsername();
		for(int i=0;i<orders.length;i++){
			String orderId = orders[i];
			List<ExpressPickInstruction> expressList = expressPickInstructionService.findOrderId(orderId);
			if(!CollectionUtils.isEmpty(expressList)){
				for(int j=0;j<expressList.size();j++){
						ExpressPickInstruction expressPickInstruction = new ExpressPickInstruction();
						expressPickInstruction.setOrderKind(CommonConstant.ORDER_KINDS);
						expressPickInstruction.setWorkingStatus(CommonConstant.WORKING_STATUS);
						expressPickInstruction.setSendStatus(CommonConstant.SEND_STATUS);
						expressPickInstruction.setBintags(CommonConstant.BINTAGS);
						expressPickInstruction.setArea(expressList.get(j).getArea());
						expressPickInstruction.setCbm(expressList.get(j).getCbm());
						expressPickInstruction.setOrderId(expressList.get(j).getOrderId());
						expressPickInstruction.setCheckMark(expressList.get(j).getCheckMark());
						expressPickInstruction.setDeliveryDate(expressList.get(j).getDeliveryDate());
						expressPickInstruction.setExpectedDate(expressList.get(j).getExpectedDate());
						expressPickInstruction.setExpectedQty(expressList.get(j).getExpectedQty());
						expressPickInstruction.setFlightName(expressList.get(j).getFlightName());
						expressPickInstruction.setFragileFlag(expressList.get(j).getFragileFlag());
						expressPickInstruction.setHomeNo(expressList.get(j).getHomeNo());
						expressPickInstruction.setLargeAreaCode(expressList.get(j).getLargeAreaCode());
						expressPickInstruction.setLoadingSourceCode(expressList.get(j).getLoadingSourceCode());
						expressPickInstruction.setLocation(expressList.get(j).getLocation());
						expressPickInstruction.setOrderAreaKind(expressList.get(j).getOrderAreaKind());
						expressPickInstruction.setUnitPrice(expressList.get(j).getUnitPrice());
						expressPickInstruction.setTotalPickSequence(expressList.get(j).getTotalPickSequence());
						expressPickInstruction.setTotalExpectedCount(expressList.get(j).getTotalExpectedCount());
						expressPickInstruction.setTotalAmount(expressList.get(j).getTotalAmount());
						expressPickInstruction.setSortLocation(expressList.get(j).getSortLocation());
						expressPickInstruction.setSkuName(expressList.get(j).getSkuName());
						expressPickInstruction.setSku(expressList.get(j).getSku());
						expressPickInstruction.setSkuKind(expressList.get(j).getSkuKind());
						expressPickInstruction.setShortenedOrderId(expressList.get(j).getShortenedOrderId());
						expressPickInstruction.setShippingSourceName(expressList.get(j).getShippingSourceName());
						expressPickInstruction.setShippingAddressName(expressList.get(j).getShippingAddressName());
						expressPickInstruction.setShippingAddress(expressList.get(j).getShippingAddress());
						expressPickInstruction.setSendStatus(expressList.get(j).getSendStatus());
						expressPickInstruction.setOrderDate(expressList.get(j).getOrderDate());
						expressPickInstruction.setOrdererName(expressList.get(j).getOrdererName());
						expressPickInstruction.setOrderFragileFlag(expressList.get(j).getOrderFragileFlag());
						expressPickInstruction.setOrderKind(expressList.get(j).getOrderKind());
						expressPickInstruction.setOrderlargeAreaLine(expressList.get(j).getOrderlargeAreaLine());
						expressPickInstruction.setOrderLineCount(expressList.get(j).getOrderLineCount());
						expressPickInstruction.setOrderLineId(expressList.get(j).getOrderLineId());
						expressPickInstruction.setPickBarcode(expressList.get(j).getPickBarcode());
						expressPickInstruction.setPackingBarcode(expressList.get(j).getPackingBarcode());
						expressPickInstruction.setPackingSize(expressList.get(j).getPackingSize());
						expressPickInstruction.setPickDate(expressList.get(j).getPickDate());
						expressPickInstruction.setPageTitle(expressList.get(j).getPageTitle());
						expressPickInstruction.setPicklistPageNo(expressList.get(j).getPicklistPageNo());
						expressPickInstruction.setPicklistKind(expressList.get(j).getPicklistKind());
						expressPickInstruction.setPicklistKindName(expressList.get(j).getPicklistKindName());
						expressPickInstruction.setPrintOrder(expressList.get(j).getPrintOrder());
						expressPickInstruction.setPrintFlag(expressList.get(j).getPrintFlag());
						expressPickInstruction.setPriority(expressList.get(j).getPriority());
						expressPickInstruction.setProcessSequenceNo(expressList.get(j).getProcessSequenceNo());
						expressPickInstruction.setCreatUser(userId);
						expressPickInstruction.setUpateUser(userId);
						expressPickInstruction.setCreatDate(sysDate);
						expressPickInstruction.setCreatTime(sysTime);
						expressPickInstruction.setUpadateDate(sysDate);
						expressPickInstruction.setUpadateTime(sysTime);
						expressPickInstructionService.insertOrderInterface(expressPickInstruction);
						
					}
				
			}
			else{
				String message = messageSource.getMessage("expressPickInstruction.ordeID.empty.message", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
		}

		ExpressPickInstruction expressPickInstruction = new ExpressPickInstruction();
		expressPickInstruction.setPickDateStart(expressPickInstructionForm.getPickDateStart());
		expressPickInstruction.setPickDateEnd(expressPickInstructionForm.getPickDateEnd());
		expressPickInstruction.setPicklistKind(expressPickInstructionForm.getPicklistKind());
		expressPickInstruction.setPicklistKindName(expressPickInstructionForm.getPicklistKindName());
		expressPickInstruction.setOrderId(expressPickInstructionForm.getOrderId());
		List<ExpressPickInstruction> expressPickInstructionList = expressPickInstructionService
				.findExpressPickInstruction(expressPickInstruction);
		
		modelView.addObject("expressPickInstructionList", expressPickInstructionList);
		return modelView;
	}
}

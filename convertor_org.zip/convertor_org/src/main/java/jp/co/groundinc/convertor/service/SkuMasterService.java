package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.domain.SkuMaster;
import jp.co.groundinc.convertor.domain.SkuMasterCsv;
import jp.co.groundinc.convertor.domain.SkuMasterDetailReports;
import jp.co.groundinc.convertor.mapper.SkuMasterMapper;

@Service
public class SkuMasterService {
	
	@Autowired
	SkuMasterMapper skuMasterMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<SkuMaster> selectSkuMaster(SkuMaster skuMaster) {
		logger.info("--- SkuMasterService.selectSkuMaster() start ---");
		List<SkuMaster> list = skuMasterMapper.selectSkuMaster(skuMaster);
		return list;
	}
	
	public void updateSkuMaster(SkuMaster skuMaster) {
		skuMasterMapper.updateSkuMaster(skuMaster);
		
	}
	public void updateSkuMasterDetail(SkuMaster skuMaster) {
		logger.info("--- SkuMasterService.updateSkuMasterDetail() start ---");
		skuMasterMapper.updateDetail(skuMaster);
	} 
	
	public void updateUrl(SkuMaster skuMaster) {
		logger.info("--- SkuMasterService.updateSkuMasterDetailUrl() start ---");
		skuMasterMapper.updateUrl(skuMaster);
	} 
	
	public SkuMaster findSkuMasterInfo(String sku) {
		logger.info("--- SkuMasterService.findSkuMasterInfo() start ---");
		SkuMaster skuMaster = skuMasterMapper.selectSkuMasterInfo(sku);
		return skuMaster;
	}
	
	public SkuMaster findSkuMasterDetail(String sku) {
		logger.info("--- SkuMasterService.findSkuMasterDetail() start ---");
		SkuMaster skuMasterDetail = skuMasterMapper.selectSkuMasterDetail(sku);
		return skuMasterDetail;
	}
	
	public int selectProductCount(SkuMaster skuMaster) {
		logger.info("--- SkuMasterService.selectProductCount() start ---");
		int count = skuMasterMapper.selectProductCount(skuMaster);
		return count;
	}
	
	public List<SkuMasterCsv> findSkuMasterCsv(
			String sku, String skuName, 
			String checkStatus, String checkStatusName,
			String deletionKind, String updateUser) {
		logger.info("--- SkuMasterService.findSkuMasterCsv() start ---");
		
		List<SkuMasterCsv> skuMasterCsvList = 
				skuMasterMapper.selectSkuMasterCsv(
						sku, skuName, checkStatus, checkStatusName,deletionKind,updateUser);
		return skuMasterCsvList;
	}
	
	public List<SkuMasterDetailReports> findSkuMasterDetailReports(String sku) {
		logger.info("--- SkuMasterService.findSkuMasterDetailReports() start ---");
		List<SkuMasterDetailReports> skuMasterDetailReportsList = 
				skuMasterMapper.selectSkuMasterDetailReports(sku);
		return skuMasterDetailReportsList;
	}

}
package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuditProgress;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.AuditProgressService;
import jp.co.groundinc.convertor.service.CommonService;

@Controller
@EnableAutoConfiguration
@SessionAttributes
public class AuditProgressController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	AuditProgressService auditProgressService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("startDate")
	public String startDate() throws ParseException {
		logger.info("--- AuditProgressController.auditProgress() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("nextStartDate")
	public String nextStartDate() throws ParseException {
		logger.info("--- AuditProgressController.auditProgress() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("auditType")
	public List<Translate> auditType() {
		logger.info("--- AuditProgressController.auditType() start ---");
		return commonService.getTranslateList("AuditStockType");
	}

	@ModelAttribute("auditProgress")
	public AuditProgress auditProgress() {
		logger.info("--- AuditProgressController.auditProgress() start ---");
		return new AuditProgress();
	}

	@RequestMapping(value = "/audit_progress")
	public ModelAndView auditProgress(ModelAndView modelView) throws ParseException {
		logger.info("--- AuditProgressController.auditProgress() start ---");
		AuditProgress auditProgress = new AuditProgress();
		String startDate = commonService.getOperationDate();
		String nextStartDate = commonService.getOperationDate();
		auditProgress.setStartDate(startDate);
		auditProgress.setNextStartDate(nextStartDate);
		List<AuditProgress> auditProgressList = auditProgressService.findAuditProgress(auditProgress);
		modelView.addObject("result", auditProgressList);
		modelView.setViewName("audit_progress");
		return modelView;

	}

	@RequestMapping(value = "/audit_progress", params = "action=clear")
	public String auditProgressClear(HttpServletRequest request, Model model) throws ParseException {
		logger.info("--- auditProgressClear() start ---");
		AuditProgress auditProgress = new AuditProgress();
		model.addAttribute("AuditProgress", auditProgress);
		model.addAttribute("operationDateStart", commonService.getOperationDate());
		model.addAttribute("operationDateEnd", commonService.getOperationDate());
		return "audit_progress";
	}

	@RequestMapping(value = "/audit_progress", params = "action=back")
	public String back(Model model) {
		logger.info("--- AuditProgressController.back() start ---");
		return "work_menu";
	}

	@RequestMapping(value = "/audit_progress", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("auditProgress") AuditProgress auditProgress,
			BindingResult result, ModelAndView modelView) {
		logger.info("--- AuditProgressController.search() start ---");
		modelView.addObject("startDate", auditProgress.getStartDate());
		modelView.addObject("nextStartDate", auditProgress.getNextStartDate());
		modelView.setViewName("/audit_progress");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String startDate = auditProgress.getStartDate();
		String nextStartDate = auditProgress.getNextStartDate();

		if (!StringUtils.isEmpty(startDate) && !StringUtils.isEmpty(nextStartDate)) {

			if (CommonUtility.comparedateStartafterEnd(startDate, nextStartDate)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationDate = messageSource.getMessage("AuditProgress.search.startDate.Datecomparison.message",null, Locale.JAPAN);
				modelView.addObject("operationDate", operationDate);
				return modelView;
			}
		}
		if (!StringUtils.isEmpty(startDate) && StringUtils.isEmpty(nextStartDate)) {

			String dataStart = auditProgress.getStartDate();
			auditProgress.setNextStartDate(dataStart);
		}
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = auditProgressService.selectCountt(auditProgress);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<AuditProgress> auditProgressList = auditProgressService.findAuditProgress(auditProgress);

		if (CollectionUtils.isEmpty(auditProgressList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		modelView.addObject("result", auditProgressList);

		return modelView;

	}

}

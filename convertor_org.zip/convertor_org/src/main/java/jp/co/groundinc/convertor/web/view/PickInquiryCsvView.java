package jp.co.groundinc.convertor.web.view;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.groundinc.convertor.CommonUtility;

public class PickInquiryCsvView extends AbstractCsvView {
	@Override
	public void buildCsvDocument(Map<String, Object> model, HttpServletRequest request, PrintWriter writer)
			throws Exception {
		@SuppressWarnings("unchecked")
		ArrayList<Object> pickInquiryCsvList = (ArrayList<Object>)model.get("pickInquiryCsvList");

		CommonUtility.WriteCsvFile(writer, pickInquiryCsvList, getCsvHeaderCode(), getCsvHeaderName());
	}

}

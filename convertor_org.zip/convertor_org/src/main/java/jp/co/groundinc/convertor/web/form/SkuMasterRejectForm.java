package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class SkuMasterRejectForm {
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{skuMasterReject.product.Halfangle.message}")
	private String sku;
	private String skuName;
	private String sendStatus;
	private String sendStatusName;

	private String description;
	
	/**データ更新Start日*/
	@NotNull(message = "{skuMasterReject.dataReceivedDateStart.empty.message}")
	private String dataReceivedDateStart;
	/**データ更新End日*/
	private String dataReceivedDateEnd;
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public String getSendStatusName() {
		return sendStatusName;
	}
	public void setSendStatusName(String sendStatusName) {
		this.sendStatusName = sendStatusName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDataReceivedDateStart() {
		return dataReceivedDateStart;
	}
	public void setDataReceivedDateStart(String dataReceivedDateStart) {
		this.dataReceivedDateStart = dataReceivedDateStart;
	}
	public String getDataReceivedDateEnd() {
		return dataReceivedDateEnd;
	}
	public void setDataReceivedDateEnd(String dataReceivedDateEnd) {
		this.dataReceivedDateEnd = dataReceivedDateEnd;
	}
	
	@Override
	public String toString() {
		return "SkuMasterRejectForm [sku=" + sku + ", skuName=" + skuName + ", sendStatus=" + sendStatus
				+ ", description=" + description + "]";
	}
	
	
	
}

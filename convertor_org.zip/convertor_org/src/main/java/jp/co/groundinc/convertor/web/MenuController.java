package jp.co.groundinc.convertor.web;

import java.security.Principal;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.groundinc.convertor.service.AuthUserService;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class MenuController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
    @Autowired
    AuthUserService authUserService;
    
    @RequestMapping("/main_menu")
    public String mainMenu(HttpServletRequest request, Principal principal, Model model) {
    	logger.info("--- AuthController.mainMenu() start ---");
    	
    	model.addAttribute("loginError", false);
    	
    	Map<String, String> authorityKindMap = authUserService.getAllAuthorityKinds();
    	request.getSession().setAttribute("authorityKindMap", authorityKindMap);
    	
    	return "redirect:/pick_progress";
    }
}

package jp.co.groundinc.convertor.web.report;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

public class PickListOrderReport1 extends AbstractReport {

	public PickListOrderReport1(String reportName) {
		super(reportName);
		
	}

	@Override
	public void buildDocument(List<?> documentDataList, HttpServletRequest request) throws Exception {
		setDocumentDataList(documentDataList, request);
		
	}

}

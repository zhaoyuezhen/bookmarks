package jp.co.groundinc.convertor.web.view;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.groundinc.convertor.CommonUtility;

public class StockAdjustInquiryCsvView extends AbstractCsvView {
	@Override
	public void buildCsvDocument(Map<String, Object> model, HttpServletRequest request, PrintWriter writer)
			throws Exception {
		@SuppressWarnings("unchecked")
		ArrayList<Object> stockAdjustInquiryDetailCsvList = (ArrayList<Object>)model.get("stockAdjustInquiryDetailCsvList");

		CommonUtility.WriteCsvFile(writer, stockAdjustInquiryDetailCsvList, getCsvHeaderCode(), getCsvHeaderName());
	}

}

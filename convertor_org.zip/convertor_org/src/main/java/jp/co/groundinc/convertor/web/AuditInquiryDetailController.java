package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuditInquiry;
import jp.co.groundinc.convertor.domain.AuditInquiryDetail;
import jp.co.groundinc.convertor.domain.AuditInquiryDetailReports;
import jp.co.groundinc.convertor.service.AuditInquiryService;
import jp.co.groundinc.convertor.web.form.AuditInquiryDetailForm;
import jp.co.groundinc.convertor.web.form.AuditInquiryForm;
import jp.co.groundinc.convertor.web.report.AuditInquiryDetailReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class AuditInquiryDetailController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	AuditInquiryService auditInquiryService;

	@Autowired
	MessageSource messageSource;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("auditInquiryDetailForm")
	public AuditInquiryDetailForm auditInquiryDetailForm() {
		logger.info("--- AuditInquiryDetailController.auditInquiryDetailForm() start ---");
		return new AuditInquiryDetailForm();
	}
	
	@RequestMapping(value = "/auditInquiryDetail")
	public ModelAndView auditInquiryDetail(@RequestParam("auditNo") String auditNo, ModelAndView modelView) {
		modelView.setViewName("/audit_inquiry_detail");
		logger.info("--- AuditInquiryDetailController.auditInquiryDetail() start ---");
		List<AuditInquiryDetail> auditInquiryDetailList = auditInquiryService.findAuditInquiryDetailInfo(auditNo);
		//List<Integer> reauditCountList = new ArrayList<Integer>();
		//Map<Integer,Integer> indexCountMap =new HashMap<Integer,Integer>();
		List<Integer> indexList = new ArrayList<Integer>();
		for (int i = 0; i < auditInquiryDetailList.size(); i++) {
				String str = auditInquiryDetailList.get(i).getExpectedQty() + "／"
						+ auditInquiryDetailList.get(i).getResultQty() + "／"
						+ auditInquiryDetailList.get(i).getDiffQty()+"／"
						+ auditInquiryDetailList.get(i).getExtraQty();
				auditInquiryDetailList.get(i).setErd(str);
		  
			if((auditInquiryDetailList.get(i).getOperatedDate() == null) || (auditInquiryDetailList.get(i).getOperatedTime() == null)){
		    	if((auditInquiryDetailList.get(i).getOperatedDate() == null)){
				  String operatedDateTime = "";
		    	  auditInquiryDetailList.get(i).setOperatedDateTime(operatedDateTime);
		    	}
		    	 if((auditInquiryDetailList.get(i).getOperatedTime() == null)){
				  String operatedDateTime = "";
				  auditInquiryDetailList.get(i).setOperatedDateTime(operatedDateTime);
				  }	
		     }else{
				String operatedDateTime = auditInquiryDetailList.get(i).getOperatedDate()+auditInquiryDetailList.get(i).getOperatedTime();
				String newOperatedDateTime = CommonUtility.getDateTime(operatedDateTime);
				auditInquiryDetailList.get(i).setOperatedDateTime(newOperatedDateTime);
		    }	
			/** checkBox あるかどうか　の判断 */
			if(auditInquiryDetailList.get(i).getIrregularKindName().equals("イレギュラーあり")){
				Integer iMaxCount=0;
				if(indexList.size() == 0){
					indexList.add(i);
					iMaxCount = Integer.parseInt(auditInquiryDetailList.get(i).getReauditCount());
				}else{
					if(iMaxCount==Integer.parseInt(auditInquiryDetailList.get(i).getReauditCount())){
						indexList.add(i);
					}else{
						break;
					}
				}
			}
		}
		/**  */
		for(Integer i : indexList){
			auditInquiryDetailList.get(i).setCheckBoxFlag("true");
		}
		AuditInquiry auditInquiry = auditInquiryService.findAuditInquiryInfo(auditNo);
		modelView.addObject("auditInquirys", auditInquiry);
		modelView.addObject("auditInquiryDetailList", auditInquiryDetailList);
		return modelView;
	}
	
	
	@RequestMapping(value = "/auditInquiryDetail", params = "action=Detailback")
	public ModelAndView Detailback(ModelAndView modelView,BindingResult result,HttpServletRequest request) {
		logger.info("--- search() start ---");
		modelView.setViewName("/audit_inquiry");
		AuditInquiryForm auditInquiryForm = (AuditInquiryForm)request.getSession().getAttribute("auditInquiryForm");
		String startDateStart = auditInquiryForm.getStartDateStart();
		String startDateEnd = auditInquiryForm.getStartDateEnd();
		String maxReauditCount = auditInquiryForm.getMaxReauditCount();
		String irregularKind = auditInquiryForm.getIrregularKind();
		
		modelView.addObject("operationDateStart", startDateStart);
		modelView.addObject("operationDateEnd", startDateEnd);
		modelView.addObject("maxReauditCount", maxReauditCount);
	
		String auditNoStart = auditInquiryForm.getAuditNoStart();
		String auditNoEnd = auditInquiryForm.getAuditNoEnd();
		String startTime = auditInquiryForm.getStartTime();
		String expectedCount = auditInquiryForm.getExpectedCount();
		String resultCount = auditInquiryForm.getResultCount();
	
		String irregularKindName = auditInquiryForm.getIrregularKindName();
		String auditId =auditInquiryForm.getAuditId();
		String auditTypeName = auditInquiryForm.getAuditTypeName();
		String auditParamValueFrom = auditInquiryForm.getAuditParamValueFrom();
		String auditParamValueTo = auditInquiryForm.getAuditParamValueTo();
		String auditParamValue = auditInquiryForm.getAuditParamValue();
		String expectedSkuCount = auditInquiryForm.getExpectedSkuCount();
		String resultSkuCount = auditInquiryForm.getResultSkuCount();
		String targetCount = auditInquiryForm.getTargetCount();
		AuditInquiry auditInquiry = new AuditInquiry();
		auditInquiry.setAuditNoStart(auditNoStart);
		auditInquiry.setAuditNoEnd(auditNoEnd);
		auditInquiry.setStartDateStart(startDateStart);
		auditInquiry.setStartDateEnd(startDateEnd);
		auditInquiry.setExpectedCount(expectedCount);
		auditInquiry.setResultCount(resultCount);
		auditInquiry.setStartTime(startTime);
		auditInquiry.setIrregularKind(irregularKind);
		auditInquiry.setIrregularKindName(irregularKindName);
		auditInquiry.setAuditId(auditId);
		auditInquiry.setAuditParamValue(auditParamValue);
		auditInquiry.setAuditParamValueFrom(auditParamValueFrom);
		auditInquiry.setAuditParamValueTo(auditParamValueTo);
		auditInquiry.setAuditTypeName(auditTypeName);
		auditInquiry.setExpectedSkuCount(expectedSkuCount);
		auditInquiry.setResultSkuCount(resultSkuCount);
		auditInquiry.setTargetCount(targetCount);
		auditInquiry.setMaxReauditCount(Integer.parseInt(maxReauditCount));
		
		if (!StringUtils.isEmpty(auditInquiry.getStartDateStart()) && StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {

			String startDateFrom = auditInquiry.getStartDateStart();

			auditInquiry.setStartDateEnd(startDateFrom);
		}
		if (StringUtils.isEmpty(auditInquiry.getStartDateStart()) && !StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {

			String startDateTo =auditInquiry.getStartDateEnd();

			auditInquiry.setStartDateStart(startDateTo);
		}
		
		List<AuditInquiry> auditList = auditInquiryService.findAuditInquiry(auditInquiry);

		for (int i = 0; i < auditList.size(); i++) {
			
			if (StringUtils.isEmpty(auditList.get(i).getExpectedCount())) {
				auditList.get(i).setExpectedCount("");
			}
			if (StringUtils.isEmpty(auditList.get(i).getResultCount())) {
				auditList.get(i).setResultCount("");
			}
			if (!StringUtils.isEmpty(auditList.get(i).getStartDate())&& !StringUtils.isEmpty(auditList.get(i).getStartTime())) {
				String str = auditList.get(i).getStartDate() + auditList.get(i).getStartTime();
				String newstr = CommonUtility.getDateTime(str);
				auditList.get(i).setStartDateTime(newstr);
			}
		}
		modelView.addObject("auditList", auditList);
		modelView.addObject("auditInquiryForm", auditInquiryForm);
		return modelView;
	}

	@RequestMapping(value = "/auditInquiryDetail", params = "action=Registration")
	public ModelAndView Registration(@Validated @ModelAttribute("auditInquiryDetailForm") AuditInquiryDetailForm auditInquiryDetailForm,
			BindingResult result,HttpServletRequest request) throws Exception {
		logger.info("--- AuditInquiryDetailController.Registration() start ---");
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("/audit_inquiry_detail");
		AuditInquiry auditInquiry = auditInquiryService.findAuditInquiryInfo(auditInquiryDetailForm.getAuditNo());
	 	modelView.addObject("auditInquirys", auditInquiry);
		if (result.hasErrors()||auditInquiryDetailForm.getAuditNoList()==null) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String [] auditNoList = null;
		String [] slotList = null;
		String [] skuList = null;
		
		auditNoList = auditInquiryDetailForm.getAuditNoList().split(",");
		
		
		if(auditInquiryDetailForm.getSlotList() !=null){
			slotList = auditInquiryDetailForm.getSlotList().split(",");
		}
		
		if(auditInquiryDetailForm.getSkuList() !=null){
			 skuList = auditInquiryDetailForm.getSkuList().split(",");
		}
		
		 UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Date dt = new Date();
			DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
			String sysDate = dfDate.format(dt);
			DateFormat dfTime = new SimpleDateFormat("HHmmss");
			String sysTime = dfTime.format(dt);
			String userId = userDetails.getUsername();
		 
		 if(auditInquiryDetailForm.getAuditTypeName().equals("スロット指定")){
			 String [] newslotList =null;
			 if(auditInquiryDetailForm.getSlotList() !=null && auditInquiryDetailForm.getSlotList().length()!=0){
					Set<String> set = new HashSet<String>();  
					set.addAll(Arrays.asList(slotList));  
					newslotList = set.toArray(new String[0]); 
				}
			 
			 for(int i=0;i<newslotList.length;i++){
				 AuditInquiryDetail auditInquiryDetail = new AuditInquiryDetail();
				 auditInquiryDetail.setAuditNo(auditNoList[i]);
				 if(slotList[i].length()>=1){
					 auditInquiryDetail.setAuditParamValue(slotList[i]); 
				 }else{
					 auditInquiryDetail.setAuditParamValue(""); 
				 }
				 auditInquiryDetail.setSendStatus(CommonConstant.SEND_STATUS);
				 auditInquiryDetail.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
				 auditInquiryDetail.setCreateDate(sysDate);
				 auditInquiryDetail.setCreateTime(sysTime);
				 auditInquiryDetail.setCreateUser(userId);
				 auditInquiryDetail.setUpdateDate(sysDate);
				 auditInquiryDetail.setUpdateTime(sysTime);
				 auditInquiryDetail.setUpdateUser(userId);
				 
				 auditInquiryService.insertAuditExpectationDetail(auditInquiryDetail); 
			 }
			 
		 }else if(auditInquiryDetailForm.getAuditTypeName().equals("商品指定")){
			 for(int i=0;i<auditNoList.length;i++){
				 AuditInquiryDetail auditInquiryDetail = new AuditInquiryDetail();
				 auditInquiryDetail.setAuditNo(auditNoList[i]);
				 if(skuList[i].length()>=1){
					 auditInquiryDetail.setAuditParamValue(skuList[i]); 
				 }else{
					 auditInquiryDetail.setAuditParamValue(""); 
				 }
				 auditInquiryDetail.setSendStatus(CommonConstant.SEND_STATUS);
				 auditInquiryDetail.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
				 auditInquiryDetail.setCreateDate(sysDate);
				 auditInquiryDetail.setCreateTime(sysTime);
				 auditInquiryDetail.setCreateUser(userId);
				 auditInquiryDetail.setUpdateDate(sysDate);
				 auditInquiryDetail.setUpdateTime(sysTime);
				 auditInquiryDetail.setUpdateUser(userId);
				 
				 auditInquiryService.insertAuditExpectationDetail(auditInquiryDetail);
				 
				 break;
			 }
				
		 }
		if (auditNoList.length >= 1) {
			AuditInquiryDetailReport reprot = new AuditInquiryDetailReport("AuditInquiryDetailReport");
			List<AuditInquiryDetailReports> auditInquiryList = new ArrayList<AuditInquiryDetailReports>();
			AuditInquiryDetailReports auditInquiryDetailReport = new AuditInquiryDetailReports();
			auditInquiryDetailReport.setAuditNo(auditNoList[0]);
			auditInquiryList.add(auditInquiryDetailReport);
			
			reprot.buildDocument(auditInquiryList, request);
			reprot.exportReport(auditNoList[0]);
		}
		 List<AuditInquiryDetail> auditInquiryDetailList = auditInquiryService.findAuditInquiryDetailInfo(auditInquiryDetailForm.getAuditNo());
			for (int i = 0; i < auditInquiryDetailList.size(); i++) {
					String str = auditInquiryDetailList.get(i).getExpectedQty() + "／"
							+ auditInquiryDetailList.get(i).getResultQty() + "／"
							+ auditInquiryDetailList.get(i).getDiffQty()+"／"
							+ auditInquiryDetailList.get(i).getExtraQty();
					auditInquiryDetailList.get(i).setErd(str);
				String operatedDateTime = auditInquiryDetailList.get(i).getOperatedDate()+auditInquiryDetailList.get(i).getOperatedTime();
				String newOperatedDateTime = CommonUtility.getDateTime(operatedDateTime);
				auditInquiryDetailList.get(i).setOperatedDateTime(newOperatedDateTime);
			
			 if (CollectionUtils.isEmpty(auditInquiryDetailList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.setViewName("/audit_inquiry_detail");
				return modelView;
			 }
		}	 
		
		 	//modelView.addObject("auditInquiryDetailList", auditInquiryDetailList);
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
  }
	
}	

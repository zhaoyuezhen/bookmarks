package jp.co.groundinc.convertor.web.view;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.groundinc.convertor.CommonUtility;

public class TransmissionLogCsvView extends AbstractCsvView {
	@Override
	public void buildCsvDocument(Map<String, Object> model, HttpServletRequest request, PrintWriter writer)
			throws Exception {
		@SuppressWarnings("unchecked")
		ArrayList<Object> transmissionLogCsvList = (ArrayList<Object>)model.get("transmissionLogCsvList");

		CommonUtility.WriteCsvFile(writer, transmissionLogCsvList, getCsvHeaderCode(), getCsvHeaderName());
	}

}

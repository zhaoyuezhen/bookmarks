package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.groundinc.convertor.domain.StockAdjustIndication;
import jp.co.groundinc.convertor.domain.StockAdjustIndicationReports;
@Mapper
public interface StockAdjustIndicationMapper {
	String selectSlotCount(String sku);
	List<StockAdjustIndication> selectProductInfo(StockAdjustIndication stockAdjustIndication);
	String selectAuditSeqenceNext();
	String  selectAuditSeqence();
	void insertAuditExpectation(StockAdjustIndication stockAdjustIndication);
	void insertAuditExceptionDetail(StockAdjustIndication stockAdjustIndication);
	void insertAuditStock(StockAdjustIndication stockAdjustIndication);
	List<StockAdjustIndication> selectViewStockDetail(String sku);
	List<StockAdjustIndication> selectViewStockDetailLocation(String location);
	List<StockAdjustIndication> findLocationInfo(StockAdjustIndication stockAdjustIndication);
	int selectProductCount(StockAdjustIndication stockAdjustIndication);
	int selectSlotCountp(StockAdjustIndication stockAdjustIndication);
	List<StockAdjustIndicationReports> selectStockAdjustIndicationReports(
			@Param("Seqence") String Seqence);
}

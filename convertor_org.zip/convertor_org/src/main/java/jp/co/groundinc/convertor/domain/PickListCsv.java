package jp.co.groundinc.convertor.domain;

public class PickListCsv {
    private String largeAreaCode;
    private String pageTitle;
    private String  picklistKindName;
    private String expectedDate;
    private String ppsId;
    private String ppsBinId;
    private String flightName;
    private String homeNo;
    private String shippingAddress;
    private String orderId;
    private int orderLineCount;
    private float totalCbmInPage;
    private String pickBarcode;
    private String packingBarcode;
    private String area;
    private String location;
    private String sku;
    private String skuKind;
    private int expectedQty;
    private int resultQty;
    private int missingFlag;
    private String checkMark;
    private String skuName;
    private int packingSize;
    private float cbm;
    private int loadingSourceCode;
    private int priority;
    private String orderKind;
    private String orderAreaKind;
    private String fragileFlag;
    private String orderFragileFlag;
    private String printFlag;
    private String sendStatus;
    private String processSequenceNo;
    private int printOrder;
    private String sortLocation;
    private String csvExportDate;
	private String csvExportTime;
	
	public int getResultQty() {
		return resultQty;
	}
	public void setResultQty(int resultQty) {
		this.resultQty = resultQty;
	}
	public int getMissingFlag() {
		return missingFlag;
	}
	public void setMissingFlag(int missingFlag) {
		this.missingFlag = missingFlag;
	}
	public String getLargeAreaCode() {
		return largeAreaCode;
	}
	public void setLargeAreaCode(String largeAreaCode) {
		this.largeAreaCode = largeAreaCode;
	}
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getPicklistKindName() {
		return picklistKindName;
	}
	public void setPicklistKindName(String picklistKindName) {
		this.picklistKindName = picklistKindName;
	}
	public String getExpectedDate() {
		return expectedDate;
	}
	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}
	public String getPpsId() {
		return ppsId;
	}
	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}
	public String getPpsBinId() {
		return ppsBinId;
	}
	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getHomeNo() {
		return homeNo;
	}
	public void setHomeNo(String homeNo) {
		this.homeNo = homeNo;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getOrderLineCount() {
		return orderLineCount;
	}
	public void setOrderLineCount(int orderLineCount) {
		this.orderLineCount = orderLineCount;
	}
	public float getTotalCbmInPage() {
		return totalCbmInPage;
	}
	public void setTotalCbmInPage(float totalCbmInPage) {
		this.totalCbmInPage = totalCbmInPage;
	}
	public String getPickBarcode() {
		return pickBarcode;
	}
	public void setPickBarcode(String pickBarcode) {
		this.pickBarcode = pickBarcode;
	}
	public String getPackingBarcode() {
		return packingBarcode;
	}
	public void setPackingBarcode(String packingBarcode) {
		this.packingBarcode = packingBarcode;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public int getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}
	public String getCheckMark() {
		return checkMark;
	}
	public void setCheckMark(String checkMark) {
		this.checkMark = checkMark;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public int getPackingSize() {
		return packingSize;
	}
	public void setPackingSize(int packingSize) {
		this.packingSize = packingSize;
	}
	
	public String getCbm() {
        return String.format("%.6f", cbm);
    }
	public void setCbm(float cbm) {
		this.cbm = cbm;
	}
	public int getLoadingSourceCode() {
		return loadingSourceCode;
	}
	public void setLoadingSourceCode(int loadingSourceCode) {
		this.loadingSourceCode = loadingSourceCode;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getOrderKind() {
		return orderKind;
	}
	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}
	public String getOrderAreaKind() {
		return orderAreaKind;
	}
	public void setOrderAreaKind(String orderAreaKind) {
		this.orderAreaKind = orderAreaKind;
	}
	public String getFragileFlag() {
		return fragileFlag;
	}
	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}
	public String getOrderFragileFlag() {
		return orderFragileFlag;
	}
	public void setOrderFragileFlag(String orderFragileFlag) {
		this.orderFragileFlag = orderFragileFlag;
	}
	public String getPrintFlag() {
		return printFlag;
	}
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public String getProcessSequenceNo() {
		return processSequenceNo;
	}
	public void setProcessSequenceNo(String processSequenceNo) {
		this.processSequenceNo = processSequenceNo;
	}
	public int getPrintOrder() {
		return printOrder;
	}
	public void setPrintOrder(int printOrder) {
		this.printOrder = printOrder;
	}
	public String getSortLocation() {
		return sortLocation;
	}
	public void setSortLocation(String sortLocation) {
		this.sortLocation = sortLocation;
	}
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}    
}

package jp.co.groundinc.convertor.web;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.SkuMaster;
import jp.co.groundinc.convertor.domain.SkuMasterDetailReports;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.SkuMasterService;
import jp.co.groundinc.convertor.web.form.SkuMasterDetailForm;
import jp.co.groundinc.convertor.web.form.SkuMasterForm;
import jp.co.groundinc.convertor.web.report.SkuMasterDetailReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration

public class SkuMasterDetailController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	SkuMasterService skuMasterService;

	@Autowired
	private Environment env;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("skuMasterDetailForm")
	public SkuMasterDetailForm skuMasterForm(HttpServletRequest request) {
		logger.info("--- SkuMasterController.skuMasterForm() start ---");
		SkuMasterDetailForm skuMasterDetailForm = new SkuMasterDetailForm();
		return skuMasterDetailForm;
	}

	@ModelAttribute("logisticsSkuKind")
	public List<Translate> skuKind() {
		logger.info("--- SkuMasterController.skuKind() start ---");
		return commonService.getTranslateList("SkuKind");
	}

	@ModelAttribute("fragileFlag")
	public List<Translate> skuFragileFlag() {
		logger.info("--- SkuMasterController.skuKind() start ---");
		return commonService.getTranslateList("FragileFlag");
	}

	@ModelAttribute("stockDirection")
	public List<Translate> skuStockDirection() {
		logger.info("--- SkuMasterController.skuKind() start ---");
		return commonService.getTranslateList("StackDirection");
	}

	@ModelAttribute("stackingFlag")
	public List<Translate> skuStackingFlag() {
		logger.info("--- SkuMasterController.skuStackingFlag() start ---");
		return commonService.getTranslateList("StacableFlag");
	}

	@ModelAttribute("nestingFlag")
	public List<Translate> skuNestingFlag() {
		logger.info("--- SkuMasterController.skuNestingFlag() start ---");
		return commonService.getTranslateList("NestingFlag");
	}

	@ModelAttribute("slotType")
	public List<Translate> skuSlotType() {
		logger.info("--- SkuMasterController.skuSlotType() start ---");
		return commonService.getTranslateList("SlotType");
	}

	@ModelAttribute("nestingDirection")
	public List<Translate> skuNestingDirection() {
		logger.info("--- SkuMasterController.skuNestingDirection() start ---");
		return commonService.getTranslateList("NestingDirection");
	}

	@ModelAttribute("storeType")
	public List<Translate> skuStoreType() {
		logger.info("--- SkuMasterController.skuStoreType() start ---");
		return commonService.getTranslateList("StoreType");
	}

	@RequestMapping(value = "/skuMasterDetail")
	public ModelAndView skuMasterDetail(@RequestParam("sku") String sku, ModelAndView modelView,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		modelView.setViewName("sku_master_detail");
		logger.info("--- SkuMasterDetailController.skuMasterDetail() start ---");

		SkuMaster skuMaster = skuMasterService.findSkuMasterDetail(sku);
		SkuMasterDetailForm skuMasterDetailForm = new SkuMasterDetailForm();
		skuMasterDetailForm.setFragileFlag(skuMaster.getFragileFlag());
		skuMasterDetailForm.setStockDirection(skuMaster.getStockDirection());
		skuMasterDetailForm.setStackingFlag(skuMaster.getStackingFlag());
		skuMasterDetailForm.setNestingFlag(skuMaster.getNestingFlag());

		if (skuMaster.getStackingFlag().equals("0") && skuMaster.getNestingFlag().equals("0")) {
			skuMasterDetailForm.setStoreType("0");
			skuMasterDetailForm.setNestingDirection("0");
		}
		if (skuMaster.getStackingFlag().equals("1") && skuMaster.getNestingFlag().equals("0")) {
			skuMasterDetailForm.setStoreType("1");
			skuMasterDetailForm.setNestingDirection("0");
		}
		if (skuMaster.getStackingFlag().equals("0") && skuMaster.getNestingFlag().equals("1")) {
			skuMasterDetailForm.setStoreType("2");

		}
		if (skuMaster.getStackingFlag().equals("1") && skuMaster.getNestingFlag().equals("1")) {
			skuMasterDetailForm.setStoreType("2");
		}
		skuMasterDetailForm.setNestingDirection(skuMaster.getNestingDirection());
		skuMasterDetailForm.setSlotType(skuMaster.getSlotType());
		skuMasterDetailForm.setMaxStacableCount(skuMaster.getMaxStacableCount());
		skuMasterDetailForm.setSkuy(skuMaster.getSku());
		skuMasterDetailForm.setLogisticsSkuName(skuMaster.getLogisticsSkuName());
		skuMasterDetailForm.setCbm(skuMaster.getCbm());
		double Depth = (skuMaster.getLogisticsSkuDepth() * 0.01);
		double Height = (skuMaster.getLogisticsSkuHeight() * 0.01);
		double Height1 = (skuMaster.getLogisticsSkuWidth() * 0.01);
		double keyisanCbm = Depth * Height * Height1;
		BigDecimal BD = new BigDecimal(Double.toString(keyisanCbm));
		BigDecimal setScale = BD.setScale(6, BigDecimal.ROUND_HALF_DOWN);
		skuMasterDetailForm.setLogisticsCbm(String.valueOf(setScale));
		skuMasterDetailForm.setLogisticsScanningCode(skuMaster.getLogisticsScanningCode());
		skuMasterDetailForm.setSkuName(skuMaster.getSkuName());
		skuMasterDetailForm.setSkuKind(skuMaster.getSkuKind());
		skuMasterDetailForm.setSkuWidth(String.valueOf(skuMaster.getSkuWidth()));
		skuMasterDetailForm.setSkuDepth(String.valueOf(skuMaster.getSkuDepth()));
		skuMasterDetailForm.setSkuHeight(String.valueOf(skuMaster.getSkuHeight()));
		skuMasterDetailForm.setSkuWeight(String.valueOf(skuMaster.getSkuWeight()));
		skuMasterDetailForm.setCbm(skuMaster.getCbm());
		skuMasterDetailForm.setScanningCode(skuMaster.getScanningCode());
		if (skuMaster.getMaxNestingCount() != null) {
			skuMasterDetailForm.setMaxNestingCount(String.valueOf(skuMaster.getMaxNestingCount()));

		} else {
			skuMasterDetailForm.setMaxNestingCount(null);
		}
		skuMasterDetailForm.setNestingIncrementCount(skuMaster.getNestingIncrementCount());
		if (skuMaster.getLogisticsSkuWidth() == 0) {
			skuMasterDetailForm.setLogisticsSkuWidth(null);
		} else {
			skuMasterDetailForm.setLogisticsSkuWidth(String.valueOf(skuMaster.getLogisticsSkuWidth()));
		}
		if (skuMaster.getLogisticsSkuDepth() == 0) {
			skuMasterDetailForm.setLogisticsSkuDepth(null);
		} else {
			skuMasterDetailForm.setLogisticsSkuDepth(String.valueOf(skuMaster.getLogisticsSkuDepth()));
		}
		if (skuMaster.getLogisticsSkuHeight() == 0) {
			skuMasterDetailForm.setLogisticsSkuHeight(null);
		} else {
			skuMasterDetailForm.setLogisticsSkuHeight(String.valueOf(skuMaster.getLogisticsSkuHeight()));
		}
		if (skuMaster.getLogisticsSkuWeight() == null) {
			skuMasterDetailForm.setLogisticsSkuWeight(null);
		} else {
			// skuMasterDetailForm.setLogisticsSkuWeight(String.valueOf(skuMaster.getLogisticsSkuWeight()));
			String logisticsSkuWeight = skuMaster.getLogisticsSkuWeight().multiply(new BigDecimal("1000")).toString();
			String logisticsSkuWeightt = logisticsSkuWeight.substring(0, logisticsSkuWeight.indexOf("."));
			skuMasterDetailForm.setLogisticsSkuWeight(logisticsSkuWeightt);
		}

		String skuImageUrl = skuMaster.getSkuImageUrl();
		if (!StringUtils.isEmpty(skuImageUrl)) {

		}

		modelView.addObject("skuMasterDetailForm", skuMasterDetailForm);
		modelView.addObject("skuMaster", skuMaster);
		modelView.addObject("logicalDeletionFlag", skuMaster.getLogicalDeletionFlag());
		return modelView;
	}

	@RequestMapping(value = "/skuImage/{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public byte[] skuImage(@PathVariable String skuCode) {
		String filePath = env.getProperty("convertor.skuimage.filepath");
		byte[] imageData = null;

		try {
			imageData = CommonUtility.getImageFile(filePath, skuCode);
		} catch (IOException e) {
			logger.error("--- skuImage() " + e.getMessage());
		}

		return imageData;
	}

	@RequestMapping(value = "/sku_master_detail", params = "action=back")
	public ModelAndView skuMasterDetailBack(HttpServletRequest request, ModelAndView modelView) {
		logger.info("--- skuMasterDetailBack() start ---");
		modelView.setViewName("/sku_master");
		SkuMasterForm skuMasterForm = (SkuMasterForm) request.getSession().getAttribute("skuMasterForm");
		modelView.addObject("skuMasterForm", skuMasterForm);
		SkuMaster skuMaster = new SkuMaster();
		String sku1 = skuMasterForm.getSku();
		String skuName = skuMasterForm.getSkuName();
		String checkStatus = skuMasterForm.getCheckStatus();
		String deletionKind = skuMasterForm.getDeletionKind();
		String updateUser = skuMasterForm.getUpdateUser();
		skuMaster.setSku(sku1);
		skuMaster.setSkuName(skuName);
		skuMaster.setCheckStatus(checkStatus);
		skuMaster.setDeletionKind(deletionKind);
		skuMaster.setUpdateUser(updateUser);

		List<SkuMaster> skuList = skuMasterService.selectSkuMaster(skuMaster);

		for (int i = 0; i < skuList.size(); i++) {
			BigDecimal BD = new BigDecimal(Double.toString(skuList.get(i).getLogisticsCbm()));
			BigDecimal setScale = BD.setScale(6, BigDecimal.ROUND_HALF_DOWN);
			skuList.get(i).setLogisticsCbm1(String.valueOf(setScale));
			if (!StringUtils.isEmpty(skuList.get(i).getUpdateDate())
					&& !StringUtils.isEmpty(skuList.get(i).getUpdateTime())) {
				String str = skuList.get(i).getUpdateDate() + skuList.get(i).getUpdateTime();
				String newstr = CommonUtility.getDateTime(str);
				skuList.get(i).setUpdateDateTime(newstr);

			}
			if (skuList.get(i).getLogisticsSkuWeight() != null) {
				String logisticsSkuWeight = skuList.get(i).getLogisticsSkuWeight().multiply(new BigDecimal("1000"))
						.toString();
				String logisticsSkuWeightt = logisticsSkuWeight.substring(0, logisticsSkuWeight.indexOf("."));
				BigDecimal logisticsSkuWeighttf = new BigDecimal(logisticsSkuWeightt);
				skuList.get(i).setLogisticsSkuWeight(logisticsSkuWeighttf);
			}
		}
		modelView.addObject("skuList", skuList);
		return modelView;
	}

	@RequestMapping(value = "/sku_master_detail", params = "action=update")
	public ModelAndView update(
			@Validated @ModelAttribute("skuMasterDetailForm") SkuMasterDetailForm skuMasterDetailForm,
			BindingResult result, HttpServletRequest request, ModelAndView modelView) throws Exception {
		logger.info("--- SkuMasterDetailController.update() start ---");
		modelView.setViewName("/sku_master");
		SkuMasterForm skuMasterForm = (SkuMasterForm) request.getSession().getAttribute("skuMasterForm");
		modelView.addObject("skuMasterForm", skuMasterForm);

		if (result.hasErrors()) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}

		String sku = skuMasterDetailForm.getSkuy();
		String logisticsCbm = skuMasterDetailForm.getCbm();
		String logisticsSkuImageUrl = skuMasterDetailForm.getLogisticsSkuImageUrl();
		String logisticsSkuName = skuMasterDetailForm.getLogisticsSkuName();
		String logisticsSkuWidth = skuMasterDetailForm.getLogisticsSkuWidth();
		String logisticsSkuDepth = skuMasterDetailForm.getLogisticsSkuDepth();
		String logisticsSkuWeight = skuMasterDetailForm.getLogisticsSkuWeight();
		String logisticsSkuHeight = skuMasterDetailForm.getLogisticsSkuHeight();
		String logisticsScanningCode = skuMasterDetailForm.getLogisticsScanningCode();
		String fragileFlag = skuMasterDetailForm.getFragileFlag();
		String stockDirection = skuMasterDetailForm.getStockDirection();
		String nestingDirection = skuMasterDetailForm.getNestingDirection();
		String slotType = skuMasterDetailForm.getSlotType();
		String maxStacableCount = skuMasterDetailForm.getMaxStacableCount();
		String maxNestingCount = skuMasterDetailForm.getMaxNestingCount();
		String nestingIncrementCount = skuMasterDetailForm.getNestingIncrementCount();
		String logicalDeletionFlag = skuMasterDetailForm.getLogicalDeletionFlag();
		String logisticsSkuKind = skuMasterDetailForm.getLogisticsSkuKind();
		String storeType = skuMasterDetailForm.getStoreType();

		if (!StringUtils.isEmpty(logisticsSkuWidth) && StringUtils.isEmpty(logisticsSkuDepth)
				&& StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}

		if (StringUtils.isEmpty(logisticsSkuWidth) && !StringUtils.isEmpty(logisticsSkuDepth)
				&& StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}

		if (StringUtils.isEmpty(logisticsSkuWidth) && StringUtils.isEmpty(logisticsSkuDepth)
				&& !StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}
		if (!StringUtils.isEmpty(logisticsSkuWidth) && !StringUtils.isEmpty(logisticsSkuDepth)
				&& StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}
		if (!StringUtils.isEmpty(logisticsSkuWidth) && StringUtils.isEmpty(logisticsSkuDepth)
				&& !StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}
		if (StringUtils.isEmpty(logisticsSkuWidth) && !StringUtils.isEmpty(logisticsSkuDepth)
				&& !StringUtils.isEmpty(logisticsSkuHeight)) {
			String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
			modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}

		if (!StringUtils.isEmpty(logisticsSkuWidth) && !StringUtils.isEmpty(logisticsSkuDepth)
				&& !StringUtils.isEmpty(logisticsSkuHeight)) {
			if (!StringUtils.isEmpty(logisticsCbm)) {
				
				// 小数点前整数
				String logisticsCbm1 = logisticsCbm;
				if(logisticsCbm.contains(".")){
					 logisticsCbm1 = logisticsCbm.substring(0, logisticsCbm.indexOf("."));
				}
				
				if (logisticsCbm1.length() > 1) {
					String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
					modelView.addObject("validationMessage", message);
					String logicalDeletionFlag1 = skuMasterDetailForm.getLogicalDeletionFlag();
					modelView.addObject("logicalDeletionFlag", logicalDeletionFlag1);
					skuMasterDetailForm.setLogisticsCbm(logisticsCbm);
					modelView.addObject("skuMasterDetailForm", skuMasterDetailForm);
					modelView.setViewName("/sku_master_detail");
					return modelView;
				}
			}
		}

		if (!StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuWeight())) {

			if (Integer.parseInt(skuMasterDetailForm.getLogisticsSkuWeight()) > 999994
					|| Integer.parseInt(skuMasterDetailForm.getLogisticsSkuWeight()) < 1) {
				String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String getLogisticsSkuWeightError = messageSource
						.getMessage("skuMasterDetail.LogisticsSkuWeightError.message", null, Locale.JAPAN);
				modelView.addObject("LogisticsSkuWeightError", getLogisticsSkuWeightError);
				modelView.setViewName("/sku_master_detail");
				return modelView;
			}

		}
		if (storeType.equals("2")) {
			if (StringUtils.isEmpty(skuMasterDetailForm.getMaxNestingCount())||StringUtils.isEmpty(skuMasterDetailForm.getNestingIncrementCount())
					|| skuMasterDetailForm.getNestingDirection().equals("0")) {
				String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
				SkuMaster skuMaster = skuMasterService.findSkuMasterDetail(skuMasterDetailForm.getSkuy());
				modelView.addObject("logicalDeletionFlag", skuMaster.getLogicalDeletionFlag());
				modelView.addObject("validationMessage", message);
				modelView.addObject("skuMasterDetailForm", skuMasterDetailForm);
				modelView.setViewName("/sku_master_detail");
				return modelView;
			} 
		}
		if (!StringUtils.isEmpty(logisticsSkuName)) {
			Matcher logisticsSkuNamet = Pattern.compile(CommonConstant.REGXN).matcher(logisticsSkuName);
			if (!logisticsSkuNamet.matches()) {
				String message = messageSource.getMessage("skuMasterDetail.update.message", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String logisticsSkuNameError = messageSource.getMessage("skuMasterDetail.logisticsSkuNameError.message",
						null, Locale.JAPAN);
				SkuMaster skuMaster = skuMasterService.findSkuMasterDetail(skuMasterDetailForm.getSkuy());
				modelView.addObject("logicalDeletionFlag", skuMaster.getLogicalDeletionFlag());
				modelView.addObject("logisticsSkuNameError", logisticsSkuNameError);
				modelView.setViewName("/sku_master_detail");
				return modelView;
			}
		}
		
		if (!skuMasterDetailForm.getSkuImageFile().isEmpty()) {
			String filePath = env.getProperty("convertor.skuimage.filepath");
			CommonUtility.saveImageFile(filePath, skuMasterDetailForm.getSkuy(), skuMasterDetailForm.getSkuImageFile());
		}

		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		String logInUser = userDetails.getUsername();
		SkuMaster skuMaster = new SkuMaster();
		if (StringUtils.isEmpty(logisticsSkuWidth) && StringUtils.isEmpty(logisticsSkuDepth)
				&& StringUtils.isEmpty(logisticsSkuHeight)) {
			skuMaster.setLogisticsSkuWidtht(null);
			skuMaster.setLogisticsSkuDeptht(null);
			skuMaster.setLogisticsSkuHeightt(null);
			skuMaster.setLogisticsCbmtt(null);
		}

		if (!StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuWeight())) {
			BigDecimal LogisticsSkuWeights = new BigDecimal(logisticsSkuWeight).divide(new BigDecimal("1000"));
			skuMaster.setLogisticsSkuWeight(LogisticsSkuWeights);
		}

		if (!StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuWidth())) {
			BigDecimal LogisticsSkuWidths = new BigDecimal(logisticsSkuWidth);
			skuMaster.setLogisticsSkuWidtht(LogisticsSkuWidths);
		}
		if (!StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuDepth())) {
			BigDecimal logisticsSkuDepths = new BigDecimal(logisticsSkuDepth);
			skuMaster.setLogisticsSkuDeptht(logisticsSkuDepths);
		}
		if (!StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuHeight())) {
			BigDecimal logisticsSkuHeights = new BigDecimal(logisticsSkuHeight);
			skuMaster.setLogisticsSkuHeightt(logisticsSkuHeights);
		}
		if (!StringUtils.isEmpty(skuMasterDetailForm.getCbm())) {
			BigDecimal logisticsCbms = new BigDecimal(skuMasterDetailForm.getCbm());
			skuMaster.setLogisticsCbmtt(logisticsCbms);
		}
		if(StringUtils.isEmpty(skuMasterDetailForm.getLogisticsScanningCode())){
			skuMaster.setLogisticsScanningCode(null);
		}
		if(StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuImageUrl())){
			skuMaster.setLogisticsSkuImageUrl(null);
		}
		if(StringUtils.isEmpty(skuMasterDetailForm.getLogisticsSkuName())){
			skuMaster.setLogisticsSkuName(null);
		}

		skuMaster.setSku(sku);
		skuMaster.setLogisticsSkuName(logisticsSkuName);
		skuMaster.setLogisticsSkuKind(logisticsSkuKind);
		skuMaster.setLogisticsSkuImageUrl(logisticsSkuImageUrl);
		skuMaster.setLogisticsScanningCode(logisticsScanningCode);
		skuMaster.setFragileFlag(fragileFlag);
		skuMaster.setStockDirection(stockDirection);
		if (storeType.equals("2")) {
			skuMaster.setStackingFlag("0");
			skuMaster.setNestingFlag("1");
			skuMaster.setMaxStacableCount("1");
			skuMaster.setStockDirection("1");
			skuMaster.setNestingDirection(nestingDirection);
			skuMaster.setNestingIncrementCount(nestingIncrementCount);
			if (!StringUtils.isEmpty(maxNestingCount)) {
				BigDecimal maxNestingCountb = new BigDecimal(maxNestingCount);
				skuMaster.setMaxNestingCount(maxNestingCountb);
			}
		}
		if (storeType.equals("1")) {
			skuMaster.setStackingFlag("1");
			skuMaster.setNestingFlag("0");
			skuMaster.setMaxStacableCount("1");
			skuMaster.setNestingDirection("0");
			skuMaster.setNestingIncrementCount(null);
			skuMaster.setMaxNestingCount(null);
		}
		if (storeType.equals("0")) {
			skuMaster.setStackingFlag("0");
			skuMaster.setNestingFlag("0");
			skuMaster.setNestingDirection("0");
			skuMaster.setNestingIncrementCount(null);
			skuMaster.setMaxNestingCount(null);
			if (StringUtils.isEmpty(maxStacableCount)) {
				skuMaster.setMaxStacableCount(null);
			} else {
				skuMaster.setMaxStacableCount(maxStacableCount);
			}

		}

		skuMaster.setSlotType(slotType);
		skuMaster.setLogicalDeletionFlag(logicalDeletionFlag);
		skuMaster.setUpdateUser(logInUser);
		skuMaster.setUpdateDate(sysDate);
		skuMaster.setUpdateTime(sysTime);
		skuMasterService.updateSkuMasterDetail(skuMaster);
		String sku1 = skuMasterForm.getSku();
		String skuName = skuMasterForm.getSkuName();
		String checkStatus = skuMasterForm.getCheckStatus();
		String deletionKind = skuMasterForm.getDeletionKind();
		String updateUserId = skuMasterForm.getUpdateUser();

		SkuMaster skuMaster1 = new SkuMaster();
		skuMaster1.setSku(sku1);
		skuMaster1.setSkuName(skuName);
		skuMaster1.setCheckStatus(checkStatus);
		skuMaster1.setDeletionKind(deletionKind);
		skuMaster1.setUpdateUser(updateUserId);
		skuMaster1.setUpdateDate(sysDate);
		skuMaster1.setUpdateTime(sysTime);

		List<SkuMaster> skuList = skuMasterService.selectSkuMaster(skuMaster1);
		for (int i = 0; i < skuList.size(); i++) {
			BigDecimal BD = new BigDecimal(Double.toString(skuList.get(i).getLogisticsCbm()));
			BigDecimal setScale = BD.setScale(6, BigDecimal.ROUND_HALF_DOWN);
			skuList.get(i).setLogisticsCbm1(String.valueOf(setScale));
			if (!StringUtils.isEmpty(skuList.get(i).getUpdateDate())
					&& !StringUtils.isEmpty(skuList.get(i).getUpdateTime())) {
				String str = skuList.get(i).getUpdateDate() + skuList.get(i).getUpdateTime();
				String newstr = CommonUtility.getDateTime(str);
				skuList.get(i).setUpdateDateTime(newstr);

			}

			if (skuList.get(i).getLogisticsSkuWeight() != null) {
				String logisticsSkuWeight1 = skuList.get(i).getLogisticsSkuWeight().multiply(new BigDecimal("1000"))
						.toString();
				String logisticsSkuWeightt = logisticsSkuWeight1.substring(0, logisticsSkuWeight1.indexOf("."));
				BigDecimal logisticsSkuWeighttf = new BigDecimal(logisticsSkuWeightt);
				skuList.get(i).setLogisticsSkuWeight(logisticsSkuWeighttf);
			}
		}
		modelView.addObject("skuList", skuList);

		// Report
		List<SkuMasterDetailReports> skuMasterDetailReportsList = skuMasterService.findSkuMasterDetailReports(sku);

		if (CollectionUtils.isEmpty(skuMasterDetailReportsList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/sku_master_detail");
			return modelView;
		}

		SkuMasterDetailReport reprot = new SkuMasterDetailReport("SkuMasterDetailReport");
		reprot.buildDocument(skuMasterDetailReportsList, request);
		reprot.exportReport(sku);

		String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
		modelView.addObject("validationMessage", message);
		return modelView;
	}

}

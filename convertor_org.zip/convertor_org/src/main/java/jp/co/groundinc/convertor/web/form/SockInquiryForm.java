package jp.co.groundinc.convertor.web.form;

public class SockInquiryForm {

}

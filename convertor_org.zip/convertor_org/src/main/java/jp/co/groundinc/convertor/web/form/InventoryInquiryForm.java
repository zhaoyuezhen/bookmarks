package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.Pattern;

public class InventoryInquiryForm {
	
	private String operatedDate;
	
	private String operatedDateStart;
	
	private String operatedDateEnd;
	
	private String operatedTime;

	/**ステーション*/
	private String ppsId;
	
	private String ppsName;
	
	/**出荷伝票番号*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoryInquiry.ticket.Halfangle.message}")
	private String keyId;
	
	/**商品コード*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoryInquiry.product.Halfangle.message}")
	private String sku;
	
	/**商品名*/
	private String skuName;

	private String qty;
	
	private String ppsBinId;
	
	private String ppsBinName;
	
	private String operationKindCode;
	
	private String operationKindName;
   
	private String operationTagCode;
	
	private String operationTagName;
	
	private String location;
	
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoryInquiry.userCode.Halfangle.message}")
	private String userCode;
	
	private String userName;
	
	private String operatedDateTime;
   
	@Pattern(regexp = "[0-9]*", message= "{InventoryInquiry.search.msuId.Numeric.message}")
    private String msuId;
    
	@Pattern(regexp = "[0-9]*", message= "{InventoryInquiry.search.msuSide.Numeric.message}")
    private String msuSide;
    
	@Pattern(regexp = "[a-zA-Z0-9]*", message= "{InventoryInquiry.search.msuStep.AlphaNumeric.message}")
    private String msuStep;
    
	@Pattern(regexp = "[0-9]*", message= "{InventoryInquiry.search.msuSlot.Numeric.message}")
    private String msuSlot;
    
    private String slot;
    
    private String Put;
    
    private String Pick;
   
    private String ManualPick;
    
    private String ManualPut;
   
    private String Audit;
    
    private String StockAdjust;
    
    private String PickExceptions;
    
    private String AuditExceptions;
    
	public String getPickExceptions() {
		return PickExceptions;
	}

	public void setPickExceptions(String pickExceptions) {
		PickExceptions = pickExceptions;
	}

	public String getAuditExceptions() {
		return AuditExceptions;
	}

	public void setAuditExceptions(String auditExceptions) {
		AuditExceptions = auditExceptions;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getPut() {
		return Put;
	}

	public void setPut(String put) {
		Put = put;
	}

	public String getPick() {
		return Pick;
	}

	public void setPick(String pick) {
		Pick = pick;
	}

	public String getManualPick() {
		return ManualPick;
	}

	public void setManualPick(String manualPick) {
		ManualPick = manualPick;
	}

	public String getManualPut() {
		return ManualPut;
	}

	public void setManualPut(String manualPut) {
		ManualPut = manualPut;
	}

	public String getAudit() {
		return Audit;
	}

	public void setAudit(String audit) {
		Audit = audit;
	}

	public String getStockAdjust() {
		return StockAdjust;
	}

	public void setStockAdjust(String stockAdjust) {
		StockAdjust = stockAdjust;
	}
	
	public String getMsuId() {
		return msuId;
	}

	public void setMsuId(String msuId) {
		this.msuId = msuId;
	}

	public String getMsuSide() {
		return msuSide;
	}

	public void setMsuSide(String msuSide) {
		this.msuSide = msuSide;
	}

	public String getMsuStep() {
		return msuStep;
	}

	public void setMsuStep(String msuStep) {
		this.msuStep = msuStep;
	}

	public String getMsuSlot() {
		return msuSlot;
	}

	public void setMsuSlot(String msuSlot) {
		this.msuSlot = msuSlot;
	}

	public String getOperatedDateTime() {
		return operatedDateTime;
	}

	public void setOperatedDateTime(String operatedDateTime) {
		this.operatedDateTime = operatedDateTime;
	}

	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOperationKindCode() {
		return operationKindCode;
	}

	public void setOperationKindCode(String operationKindCode) {
		this.operationKindCode = operationKindCode;
	}

	public String getOperationKindName() {
		return operationKindName;
	}

	public void setOperationKindName(String operationKindName) {
		this.operationKindName = operationKindName;
	}

	public String getOperationTagCode() {
		return operationTagCode;
	}

	public void setOperationTagCode(String operationTagCode) {
		this.operationTagCode = operationTagCode;
	}

	public String getOperationTagName() {
		return operationTagName;
	}

	public void setOperationTagName(String operationTagName) {
		this.operationTagName = operationTagName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOperatedDateStart() {
		return operatedDateStart;
	}

	public void setOperatedDateStart(String operatedDateStart) {
		this.operatedDateStart = operatedDateStart;
	}

	public String getOperatedDateEnd() {
		return operatedDateEnd;
	}

	public void setOperatedDateEnd(String operatedDateEnd) {
		this.operatedDateEnd = operatedDateEnd;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getPpsName() {
		return ppsName;
	}

	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}

	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}

	public String getPpsBinId() {
		return ppsBinId;
	}

	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}

	public String getPpsBinName() {
		return ppsBinName;
	}

	public void setPpsBinName(String ppsBinName) {
		this.ppsBinName = ppsBinName;
	}

}

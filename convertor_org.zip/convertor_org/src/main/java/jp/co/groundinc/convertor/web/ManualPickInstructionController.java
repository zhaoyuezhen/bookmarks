package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.ManualPickInstruction;
import jp.co.groundinc.convertor.domain.ManualPickInstructionReports;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.ManualPickInstructionService;
import jp.co.groundinc.convertor.web.form.ManualPickInstructionForm;
import jp.co.groundinc.convertor.web.report.ManualPickInstructionReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class ManualPickInstructionController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	ManualPickInstructionService manualPickInstructionService;

	@Autowired
	CommonService commonService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("manualPickInstructionForm")
	public ManualPickInstructionForm pickInquiryForm() {
		logger.info("--- ManualPickInstructionController.manualPickInstructionForm() start ---");
		return new ManualPickInstructionForm();
	}

	@RequestMapping(value = "/manual_stock", params = "action=clear")
	public String viewPickInstructionClear(HttpServletRequest request, Model model, SessionStatus status)
			throws ParseException {
		logger.info("--- viewPickInstructionClear() start ---");
		ManualPickInstructionForm form = new ManualPickInstructionForm();
		model.addAttribute("manualPickInstructionForm", form);
		status.setComplete();
		return "manual_pick_Instruction";
	}

	@RequestMapping(value = "/manual_stock", params = "action=back")
	public String viewPickInstructionBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- viewPickInstructionBack() start ---");
		return "pick_menu";
	}

	@RequestMapping("/manual_stock")
	public ModelAndView ManualStock(Model model, HttpServletRequest request,ModelAndView modelView) {
		logger.info("--- ManualPickInstructionController.ManualStock() start ---");
		modelView.setViewName("/manual_pick_Instruction");
		ManualPickInstructionForm form = new ManualPickInstructionForm();
		model.addAttribute("manualPickInstructionForm", form);
		
		return modelView;
	}

	@RequestMapping(value = "/manual_stock", params = "action=search")
	public ModelAndView selectPickInquiryInfo(
			@Validated @ModelAttribute("manualPickInstructionForm") ManualPickInstructionForm manualPickInstructionForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- selectPickInquiryInfo() start ---");
		manualPickInstructionForm.setPickQtys(null);
		manualPickInstructionForm.setScheduled(null);
		modelView.setViewName("/manual_pick_Instruction");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String skuStart = manualPickInstructionForm.getSkuStart();
		String skuEnd = manualPickInstructionForm.getSkuEnd();

		if (!StringUtils.isEmpty(skuStart) && StringUtils.isEmpty(skuEnd)) {
			skuEnd = skuStart;
		}
		if (StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
			skuStart = skuEnd;
		}
		if (!StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
			String regex = ".*[a-zA-Z]+.*";
			Matcher skuStartm = Pattern.compile(regex).matcher(skuStart);
			Matcher skuEndm = Pattern.compile(regex).matcher(skuEnd);
			if (!skuStartm.matches() && !skuEndm.matches()) {
				if (Integer.valueOf(skuStart).intValue() > Integer.valueOf(skuEnd).intValue()) {
					String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
					modelView.addObject("validationMessage", message);
					String skuerror = messageSource.getMessage("stockInquiry.sku.message", null, Locale.JAPAN);
					modelView.addObject("skuerror", skuerror);
					return modelView;
				}
			}
		}
		
		ManualPickInstruction manualPickInstruction = new ManualPickInstruction();
		manualPickInstruction.setSkuStart(skuStart);
		manualPickInstruction.setSkuEnd(skuEnd);
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=manualPickInstructionService.selectCountt(manualPickInstruction);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<ManualPickInstruction> pickInquirylist = manualPickInstructionService.findPickInfo(manualPickInstruction);
		if (CollectionUtils.isEmpty(pickInquirylist)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		    }
		modelView.addObject("pickInquirylist", pickInquirylist);
		return modelView;
	}

	@RequestMapping(value = "/manual_stock", params = "action=Registration")
	public ModelAndView pickInstruction(
			@Validated @ModelAttribute("manualPickInstructionForm") ManualPickInstructionForm manualPickInstructionForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) throws Exception {
		logger.info("--- selectPickInquiryInfo() start ---");
		modelView.setViewName("/manual_pick_Instruction");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String[] yoteyisus = manualPickInstructionForm.getScheduled();
		String[] skuCodes = manualPickInstructionForm.getSkus();
		String[] pickQty = manualPickInstructionForm.getPickQtys();

		if (yoteyisus == null || yoteyisus.length == 0) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String pickQtyError1 = this.checkArufaCheck(yoteyisus);
		if (!StringUtils.isEmpty(pickQtyError1)) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.addObject("pickQtyError1", pickQtyError1);
			return modelView;
		}
		
		String pickQtyError = this.checkPresetNumber(yoteyisus, pickQty);
		if (!StringUtils.isEmpty(pickQtyError)) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.addObject("pickQtyError", pickQtyError);
			return modelView;
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("hhmmss");
		String sysTime = dfTime.format(dt);
		String userId = userDetails.getUsername();
		String orderId = manualPickInstructionService.selectOrderSeqence().trim();
		String processSequenceNo = manualPickInstructionService.selectprocessSequenceNo();
		for (int i = 0; i < yoteyisus.length; i++) {
			if (!StringUtils.isEmpty(yoteyisus[i])) {
				int expectedQty1 = Integer.parseInt(yoteyisus[i]);
				ManualPickInstruction manualPickInstruction = new ManualPickInstruction();
				manualPickInstruction.setOrderId(orderId);
				manualPickInstruction.setProcessSequenceNo(processSequenceNo.trim());
				manualPickInstruction.setExpectedDate(sysDate);
				manualPickInstruction.setDataReceivedDate(sysDate);
				manualPickInstruction.setOrderKind(CommonConstant.ORDER_KIND);
				manualPickInstruction.setWorkingStatus(CommonConstant.WORKING_STATUS);
				manualPickInstruction.setFileOutputFlag(CommonConstant.FILE_OUTPUT_FLAG);
				manualPickInstruction.setPriority(CommonConstant.PRIORITY);
				manualPickInstruction.setCreatUser(userId);
				manualPickInstruction.setUpateUser(userId);
				manualPickInstruction.setCreatDate(sysDate);
				manualPickInstruction.setCreatTime(sysTime);
				manualPickInstruction.setUpadateDate(sysDate);
				manualPickInstruction.setUpadateTime(sysTime);
				String orderLineId = Integer.toString(i + 1);
				manualPickInstruction.setOrderLineId(orderLineId);
				manualPickInstruction.setSku(skuCodes[i]);
				manualPickInstruction.setExpectedQty(expectedQty1);
				manualPickInstructionService.insetrOrderManual(manualPickInstruction);
				String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			    modelView.addObject("validationMessage", message);
			}
		}
		        //Reports
				List<ManualPickInstructionReports> manualPickInstructionReportsList = 
						manualPickInstructionService.findManualPickInstructionReports(orderId);
				
				if (CollectionUtils.isEmpty(manualPickInstructionReportsList)) {
					String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
					modelView.addObject("validationMessage", message);
					modelView.setViewName("/manual_pick_Instruction");
					return modelView;
				}
				
				ManualPickInstructionReport reprot = new ManualPickInstructionReport("ManualPickInstructionReport");
					reprot.buildDocument(manualPickInstructionReportsList, request);
					reprot.exportReport(orderId);
				    modelView.setViewName("/manual_pick_Instruction");
			    ManualPickInstruction manualPickInstruction = new ManualPickInstruction(); 
			    manualPickInstruction.setFileOutputFlag(manualPickInstruction.getFileOutputFlag());
			    manualPickInstruction.setOrderId(orderId);
			    manualPickInstructionService.updateFileOutputFlag(manualPickInstruction);
		            return modelView;
	}

	private String checkPresetNumber(String yoteyisus[], String pickQtytt[]) {
		String pickQtyError = null;
		for (int i = 0; i < pickQtytt.length; i++) {
			if (!StringUtils.isEmpty(yoteyisus[i])) {
				String expectedQty = yoteyisus[i];
				String pickQty = pickQtytt[i];
				int expectedQty1 = Integer.parseInt(expectedQty);
				int pickQty1 = Integer.parseInt(pickQty);
				if (pickQty1 < expectedQty1) {
					pickQtyError = messageSource.getMessage("manualpick.expectedQty.message", null, Locale.JAPAN);
					return pickQtyError;
				}
			}
		}
		return pickQtyError;

	}
	
	private String checkArufaCheck(String yoteyisus[]) {
		String ArufaError = null;
		for (int i = 0; i < yoteyisus.length; i++) {
			String expectedQty = yoteyisus[i];
			Matcher expectedQtytt = Pattern.compile(CommonConstant.REGX).matcher(expectedQty);
			if(!StringUtils.isEmpty(yoteyisus[i])&& !expectedQtytt.matches()){
				ArufaError = messageSource.getMessage("manualpick.expectedQty.message", null, Locale.JAPAN);
				return ArufaError;
			}
			if(expectedQty.equals("0")){
				ArufaError = messageSource.getMessage("manualpick.expectedQty.message", null, Locale.JAPAN);
				return ArufaError;
			}
		}
		return ArufaError;

	}

}

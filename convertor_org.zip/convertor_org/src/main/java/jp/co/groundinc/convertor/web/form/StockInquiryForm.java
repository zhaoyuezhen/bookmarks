package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.Pattern;

public class StockInquiryForm {
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{stockInquiry.sku.From.message}")
	private String skuStart;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{stockInquiry.sku.To.message}")
	private String skuEnd;
	private String skuName;
	@Pattern(regexp = "[0-9]+([.]{1}[0-9]+){0,1}", message = "{stockInquiry.CBM.From.message}")
	private String totalCbmAbove;
	@Pattern(regexp = "[0-9]+([.]{1}[0-9]+){0,1}", message = "{stockInquiry.CBM.To.message}")
	private String totalCbmUnder;
	private String retentionDays;

	public String getSkuStart() {
		return skuStart;
	}

	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}

	public String getSkuEnd() {
		return skuEnd;
	}

	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getTotalCbmAbove() {
		return totalCbmAbove;
	}

	public void setTotalCbmAbove(String totalCbmAbove) {
		this.totalCbmAbove = totalCbmAbove;
	}

	public String getTotalCbmUnder() {
		return totalCbmUnder;
	}

	public void setTotalCbmUnder(String totalCbmUnder) {
		this.totalCbmUnder = totalCbmUnder;
	}

	public String getRetentionDays() {
		return retentionDays;
	}

	public void setRetentionDays(String retentionDays) {
		this.retentionDays = retentionDays;
	}

}

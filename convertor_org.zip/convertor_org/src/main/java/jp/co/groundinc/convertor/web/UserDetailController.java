package jp.co.groundinc.convertor.web;

import java.security.Principal;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.UserMasterService;
import jp.co.groundinc.convertor.web.form.UserDetailForm;
import jp.co.groundinc.convertor.web.form.UserMasterForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "authorityKinds" }) 
public class UserDetailController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CommonService commonService ;
	
	@Autowired
	UserMasterService userMasterService ;

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }
    
	@ModelAttribute("authorityKinds")
	public List<Translate> authorityKinds() {
		logger.info("--- UserDetailController.authorityKinds() start ---");
		return commonService.getTranslateList("AuthorityKind");
	}
	
    @RequestMapping("/user_detail")
    public ModelAndView userDetail(
    		@ModelAttribute("userEditMode") String userEditMode,
    		@ModelAttribute("tbUserCode") String tbUserCode,
    		ModelAndView modelView) {
    	logger.info("--- UserDetailController.userDetail() start ---");
    	
    	UserDetailForm form = new UserDetailForm();

    	if (userEditMode == null || tbUserCode == null) {
    		userEditMode = CommonConstant.USER_EDIT_MODE_ADDITION;
    	}
    	
    	if (userEditMode.equals(CommonConstant.USER_EDIT_MODE_EDIT)) {
    		UserMaster user = userMasterService.findByUserCd(tbUserCode);
        	if (user == null) {
                String message = messageSource.getMessage("UserMaster.userId.NotExists.message", null, Locale.JAPAN);
                modelView.addObject("validationMessage", message);
                userEditMode = CommonConstant.USER_EDIT_MODE_ADDITION;
        	} else {
            	form.setUserCode(user.getUserCode());
            	form.setUserName(user.getUserName());
            	form.setAuthoritykind(user.getAuthorityKind());
        	}
    	}
    	
		modelView.addObject("userEditMode", userEditMode);
		modelView.addObject("userDetailForm", form);
		
        return modelView;
    }
    
    @RequestMapping(value="/user_detail", params="action=addition")
    public ModelAndView addition(Principal principal, @Validated @ModelAttribute UserDetailForm form, BindingResult result, ModelAndView modelView) {
    	logger.info("--- UserDetailController.addition() start ---");
    	modelView.setViewName("/user_detail");
    	modelView.addObject("userEditMode", CommonConstant.USER_EDIT_MODE_ADDITION);
    	
    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (userMasterService.exists(form.getUserCode())) {
            String message = messageSource.getMessage("UserMaster.userId.Exists.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (!StringUtils.isEmpty(form.getUserName())) {
			Matcher userName = Pattern.compile(CommonConstant.REGXU).matcher(form.getUserName());
			if (!userName.matches()) {
				String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String userNameError = messageSource.getMessage("userMasterDetail.userNameError.message",
						null, Locale.JAPAN);
			
				modelView.addObject("userNameError", userNameError);
				modelView.setViewName("/user_detail");
				return modelView;
			}
		}
    	
    	UserMaster user = new UserMaster();
    	user.setUserCode(form.getUserCode());
    	user.setUserName(form.getUserName());
    	user.setAuthorityKind(form.getAuthoritykind());
    	user.setPassword(form.getUserCode());
    	
    	String logInUser = principal.getName();
    	user.setCreateUser(logInUser);
    	user.setCreateDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setCreateTime(CommonUtility.getSysDateTime().get("TIME"));
    	user.setUpdateUser(logInUser);
    	user.setUpdateDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setUpdateTime(CommonUtility.getSysDateTime().get("TIME"));
    	
    	userMasterService.addUser(user);
    	
    	modelView.addObject(form);
    	modelView.addObject("userEditMode", CommonConstant.USER_EDIT_MODE_EDIT);
    	
        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        return modelView;
    }
    
    @RequestMapping(value="/user_detail", params="action=update")
    public ModelAndView update(Principal principal, @Validated @ModelAttribute UserDetailForm form, BindingResult result, ModelAndView modelView) {
    	logger.info("--- UserDetailController.update() start ---");

    	modelView.addObject("userEditMode", CommonConstant.USER_EDIT_MODE_EDIT);
    	modelView.setViewName("/user_detail");
    	
    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (!userMasterService.exists(form.getUserCode())) {
            String message = messageSource.getMessage("UserMaster.userId.NotExists.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (!StringUtils.isEmpty(form.getUserName())) {
			Matcher userName = Pattern.compile(CommonConstant.REGXU).matcher(form.getUserName());
			if (!userName.matches()) {
				String message = messageSource.getMessage("userMasterDetail.update.message", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String userNameError = messageSource.getMessage("userMasterDetail.userNameError.message",
						null, Locale.JAPAN);
			
				modelView.addObject("userNameError", userNameError);
				modelView.setViewName("/user_detail");
				return modelView;
			}
		}
    	
    	UserMaster user = new UserMaster();
    	user.setUserCode(form.getUserCode());
    	user.setUserName(form.getUserName());
    	user.setAuthorityKind(form.getAuthoritykind());
    	
    	String logInUser = principal.getName();
    	user.setUpdateUser(logInUser);
    	user.setUpdateDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setUpdateTime(CommonUtility.getSysDateTime().get("TIME"));
    	
    	userMasterService.updateUser(user);
    	
        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        return modelView;
    }
    
    @RequestMapping(value="/user_detail", params="action=pwdReset")
    public ModelAndView pwdReset(Principal principal, @Validated @ModelAttribute UserDetailForm form, BindingResult result, ModelAndView modelView) {
    	logger.info("--- UserDetailController.pwdReset() start ---");

    	modelView.addObject("userEditMode", CommonConstant.USER_EDIT_MODE_EDIT);
    	modelView.setViewName("/user_detail");
    	
    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (!userMasterService.exists(form.getUserCode())) {
            String message = messageSource.getMessage("UserMaster.userId.NotExists.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	String logInPassword = userDetails.getPassword();
    	UserMaster user = new UserMaster();
    	user.setUserCode(form.getUserCode());
    	String logInUser = principal.getName();
    	user.setUpdateUser(logInUser);
    	user.setOldPassword(logInPassword);
    	user.setPasswordChangeDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setUpdateDate(CommonUtility.getSysDateTime().get("DATE"));
    	user.setUpdateTime(CommonUtility.getSysDateTime().get("TIME"));
    	
    	userMasterService.resetUserPassword(user);
    	
        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        
        return modelView;
    }
    
    @RequestMapping(value="/user_detail", params="action=delete")
    public ModelAndView delete(@ModelAttribute @Validated UserDetailForm form, BindingResult result, ModelAndView modelView) {
    	logger.info("--- UserDetailController.delete() start ---");
    	
    	modelView.addObject("userEditMode", CommonConstant.USER_EDIT_MODE_EDIT);
    	modelView.setViewName("/user_detail");
    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Edit.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	if (!userMasterService.exists(form.getUserCode())) {
            String message = messageSource.getMessage("UserMaster.userId.NotExists.message", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	UserMaster user = new UserMaster();
    	user.setUserCode(form.getUserCode());

    	userMasterService.deleteUser(user);
    	
    	UserDetailForm userDetailForm = new UserDetailForm();
    	modelView.addObject("userDetailForm", userDetailForm);
        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        
        return userDetail(CommonConstant.USER_EDIT_MODE_ADDITION, null, modelView);
    }
    
    @RequestMapping(value="/user_detail", params="action=back")
    public ModelAndView backUserMaster(HttpServletRequest request,ModelAndView modelView) throws ParseException {
    	logger.info("--- UserDetailController.backUserMaster() start ---");
    	modelView.setViewName("/user_master");
    	UserMasterForm userMasterForm = (UserMasterForm) request.getSession().getAttribute("userMasterForm");
		modelView.addObject("userMasterForm", userMasterForm);
		UserMaster user = new UserMaster();
    	String userCode = userMasterForm.getUserCode();
    	String userName = userMasterForm.getUserName();
    	String authoritykind = userMasterForm.getAuthoritykind(); 
    	String passwordChangeDate = userMasterForm.getPasswordChangeDate();
    	
    	user.setUserCode(userCode);
    	user.setUserName(userName);
    	user.setAuthorityKind(authoritykind);
    	user.setPasswordChangeDate(passwordChangeDate);
        List<UserMaster> userList = userMasterService.findUsers(user);
        modelView.addObject("users", userList);
        return modelView;  
    }
}

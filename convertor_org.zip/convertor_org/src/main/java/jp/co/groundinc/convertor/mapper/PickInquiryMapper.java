package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.PickInquiry;
import jp.co.groundinc.convertor.domain.PickInquiryCsv;
@Mapper
public interface PickInquiryMapper {

	List<PickInquiry> selectSyukoinfo(PickInquiry pickInquiry);
	String selectproductName(String productcoder);
	int selectCountt(PickInquiry pickInquiry);
	String getDefTranslateCode();
	List<PickInquiryCsv> selectPickInquiryCsv(
			@Param("datareceiveddateStart") String datareceiveddateStart,
			@Param("datareceiveddateEnd") String datareceiveddateEnd,
			@Param("datareceivedtimeStart") String datareceivedtimeStart,
			@Param("datareceivedtimeEnd") String datareceivedtimeEnd,
			@Param("expecteddateStart") String expecteddateStart,
			@Param("expecteddateEnd") String expecteddateEnd,
			@Param("operateddateStart") String operateddateStart,
			@Param("operateddateEnd") String operateddateEnd,
			
			@Param("operatedTimeStart") String operatedTimeStart,
			@Param("operatedTimeEnd") String operatedTimeEnd,
			
			@Param("orderid") String orderid,
			@Param("workingstatus") String workingstatus,
			@Param("ppsid") String ppsid,
			@Param("ppsbinid") String ppsbinid,
			@Param("irregularKind") String irregularKind,
			@Param("irregularKindName") String irregularKindName,
			@Param("orderKind") String orderKind,
			@Param("orderKindName") String orderKindName,
			@Param("sku") String sku,
			@Param("allMissingFlag") String allMissingFlag);
	
}

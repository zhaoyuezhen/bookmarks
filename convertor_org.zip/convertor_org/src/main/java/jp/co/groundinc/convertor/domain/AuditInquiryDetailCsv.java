package jp.co.groundinc.convertor.domain;

public class AuditInquiryDetailCsv {
	private String auditNo;
	private String auditStockKind;
	private String auditStockKindName;
	private String auditType;
	private String auditTypeName;
	private String auditId;
	private String location;
	private String sku;
	private String skuName;
	private int expectedQty;
	private int resultQty;
	private int diffQty;
	private int extraQty;
	private String ppsId;
	private String ppsName;
	private String userCode;
	private String userName;
	private String operatedDate;
	private String operatedTime;
	private String irregularKind;
	private String irregularKindName;
	private String csvExportDate;
	private String csvExportTime;

	
	public String getAuditNo() {
		return auditNo;
	}
	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}
	public String getAuditStockKind() {
		return auditStockKind;
	}
	public void setAuditStockKind(String auditStockKind) {
		this.auditStockKind = auditStockKind;
	}
	public String getAuditStockKindName() {
		return auditStockKindName;
	}
	public void setAuditStockKindName(String auditStockKindName) {
		this.auditStockKindName = auditStockKindName;
	}
	public String getAuditType() {
		return auditType;
	}
	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}
	public String getAuditTypeName() {
		return auditTypeName;
	}
	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public int getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}
	public int getResultQty() {
		return resultQty;
	}
	public void setResultQty(int resultQty) {
		this.resultQty = resultQty;
	}
	public int getDiffQty() {
		return diffQty;
	}
	public void setDiffQty(int diffQty) {
		this.diffQty = diffQty;
	}
	public int getExtraQty() {
		return extraQty;
	}
	public void setExtraQty(int extraQty) {
		this.extraQty = extraQty;
	}
	public String getPpsId() {
		return ppsId;
	}
	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}
	public String getPpsName() {
		return ppsName;
	}
	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getOperatedDate() {
		return operatedDate;
	}
	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}
	public String getOperatedTime() {
		return operatedTime;
	}
	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}
	public String getIrregularKind() {
		return irregularKind;
	}
	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}
	public String getIrregularKindName() {
		return irregularKindName;
	}
	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}

}

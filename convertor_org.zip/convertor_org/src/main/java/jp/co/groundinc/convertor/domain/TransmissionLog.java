package jp.co.groundinc.convertor.domain;

public class TransmissionLog {
	private String transmissionId;
	private String transmissionTypeDetail;
	private String transmissionType;
	private String sendrecvKind;
	private String processingStatus;
	private String transmissionTypeName;
	private String transmissionTypeDetailName;
	private String sendrecvKindName;
	private String processingStatusName;
	private String processedDate;
	private String processedTime;
	private String processedDateTime;
	private String totalCount;
	private String errorCount;
	private String filePath;
	private String startDate;
	private String endDate;

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getProcessedDateTime() {
		return processedDateTime;
	}

	public void setProcessedDateTime(String processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	public String getTransmissionId() {
		return transmissionId;
	}

	public void setTransmissionId(String transmissionId) {
		this.transmissionId = transmissionId;
	}

	public String getTransmissionTypeDetail() {
		return transmissionTypeDetail;
	}

	public void setTransmissionTypeDetail(String transmissionTypeDetail) {
		this.transmissionTypeDetail = transmissionTypeDetail;
	}

	public String getTransmissionType() {
		return transmissionType;
	}

	public void setTransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}

	public String getSendrecvKind() {
		return sendrecvKind;
	}

	public void setSendrecvKind(String sendrecvKind) {
		this.sendrecvKind = sendrecvKind;
	}

	public String getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getTransmissionTypeName() {
		return transmissionTypeName;
	}

	public void setTransmissionTypeName(String transmissionTypeName) {
		this.transmissionTypeName = transmissionTypeName;
	}

	public String getTransmissionTypeDetailName() {
		return transmissionTypeDetailName;
	}

	public void setTransmissionTypeDetailName(String transmissionTypeDetailName) {
		this.transmissionTypeDetailName = transmissionTypeDetailName;
	}

	public String getSendrecvKindName() {
		return sendrecvKindName;
	}

	public void setSendrecvKindName(String sendrecvKindName) {
		this.sendrecvKindName = sendrecvKindName;
	}

	public String getProcessingStatusName() {
		return processingStatusName;
	}

	public void setProcessingStatusName(String processingStatusName) {
		this.processingStatusName = processingStatusName;
	}

	public String getProcessedDate() {
		return processedDate;
	}

	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}

	public String getProcessedTime() {
		return processedTime;
	}

	public void setProcessedTime(String processedTime) {
		this.processedTime = processedTime;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StowProgress;
import jp.co.groundinc.convertor.mapper.StowProgressMapper;

@Service
public class StowProgressService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	StowProgressMapper stowProgressMapper;
	@Autowired
	CommonUtility commonUtility;
	public List<StowProgress> findStowProgress(StowProgress stowProgress) {

		logger.info("--- StowProgress.findStowProgress() start ---");

			String starDate = CommonUtility.dateFomat(stowProgress.getDataReceivedDate());
			String endDate = CommonUtility.dateFomat(stowProgress.getNextdataReceivedDate());
			stowProgress.setDataReceivedDate(starDate);
			stowProgress.setNextdataReceivedDate(endDate);
			List<StowProgress> stowProgressList = stowProgressMapper.findAll(stowProgress);

			return stowProgressList;
	}
	
	public int selectCountt(StowProgress stowProgress) {

		String starDate = CommonUtility.dateFomat(stowProgress.getDataReceivedDate());
		String endDate = CommonUtility.dateFomat(stowProgress.getNextdataReceivedDate());
		stowProgress.setDataReceivedDate(starDate);
		stowProgress.setNextdataReceivedDate(endDate);
		int count = stowProgressMapper.selectCountt(stowProgress);
		return count;

	}

	public List<StowProgress> selectStowProgress(StowProgress stowProgress) {

		logger.info("--- StowProgress.findStowProgress() start ---");

            List<StowProgress> stowProgressList = stowProgressMapper.selectStowProgress(stowProgress);

            return stowProgressList;
    }
    public int selectStowProgressCount(StowProgress stowProgress) {
        
        int count = stowProgressMapper.selectStowProgressCount(stowProgress);
        return count;

    }

}


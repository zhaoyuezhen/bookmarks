package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuditInquiry;
import jp.co.groundinc.convertor.domain.AuditInquiryDetailCsv;
import jp.co.groundinc.convertor.service.AuditInquiryService;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.web.form.AuditInquiryForm;
import jp.co.groundinc.convertor.web.report.AuditInquiryReport;
import jp.co.groundinc.convertor.web.report.AuditInquiryReport1;
import jp.co.groundinc.convertor.domain.AuditInquiryReports;
import jp.co.groundinc.convertor.domain.Translate;
@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "printerList", "auditInquiryForm" ,"irregularKind"})
public class AuditInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CommonService commonService;

    @Autowired
	AuditInquiryService auditInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}
	
	@ModelAttribute("printerList")
	public List<Translate> printerList() {
		logger.info("--- AuditInquiryController.printerList() start ---");
		return commonService.getTranslateList("PrinterCode");
	}
	
	@ModelAttribute("auditInquiryForm")
	public AuditInquiryForm auditInquiryForm() {
		logger.info("--- AuditInquiryController.auditInquiryForm() start ---");
		return new AuditInquiryForm();
	}

	@ModelAttribute("operationDateStart")
	public String startDateStart() throws ParseException {
		logger.info("--- AuditInquiryController.startDateStart() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("operationDateEnd")
	public String startDateEnd() throws ParseException {
		logger.info("--- AuditInquiryController.startDateEnd() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("maxReauditCount")
	public int maxReauditCount() throws ParseException {
		logger.info("--- AuditInquiryController.maxReauditCount() start ---");
		return 1;
	}
	
	@ModelAttribute("irregularKind")
	public List<Translate> irregularKind() {
		logger.info("--- AuditInquiryController.irregularKind() start ---");
		return commonService.getTranslateList("IrregularKind");
	}
	
	@RequestMapping(value = "/audit_inquiry", params = "action=back")
	public String auditInquiryBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- AuditInquiryController.auditInquiryBack() start ---");
		status.setComplete();
		return "audit_menu";
	}

	@RequestMapping("/audit_inquiry")
	public String viewAudit(Model model, HttpServletRequest request) throws ParseException {
		logger.info("--- AuditInquiryController.auditInquiry() start ---");
		AuditInquiryForm auditInquiryForm = (AuditInquiryForm)request.getSession().getAttribute("auditInquiryForm");
		if(auditInquiryForm !=null){
			auditInquiryForm.setAuditNoStart(null);
			auditInquiryForm.setAuditNoEnd(null);
			auditInquiryForm.setStartDate(commonService.getOperationDate());
			auditInquiryForm.setStartDateEnd(commonService.getOperationDate());
			
		}
		return "audit_inquiry";
	}

	@RequestMapping(value = "/audit_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("auditInquiryForm") AuditInquiryForm auditInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- search() start ---");
		modelView.setViewName("/audit_inquiry");
		
		String startDateStart = auditInquiryForm.getStartDateStart();
		String startDateEnd = auditInquiryForm.getStartDateEnd();
		
		String maxReauditCount =auditInquiryForm.getMaxReauditCount();
		
		
		modelView.addObject("operationDateStart", startDateStart);
		modelView.addObject("operationDateEnd", startDateEnd);
		modelView.addObject("maxReauditCount", maxReauditCount);
		
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String auditNoStart = auditInquiryForm.getAuditNoStart();
		String auditNoEnd = auditInquiryForm.getAuditNoEnd();
		String startTime = auditInquiryForm.getStartTime();
		String expectedCount= auditInquiryForm.getExpectedCount();
		String resultCount = auditInquiryForm.getResultCount();
		String irregularKindName = auditInquiryForm.getIrregularKindName();
		String auditId =auditInquiryForm.getAuditId();
		String auditTypeName = auditInquiryForm.getAuditTypeName();
		String auditParamValueFrom = auditInquiryForm.getAuditParamValueFrom();
		String auditParamValueTo = auditInquiryForm.getAuditParamValueTo();
		String auditParamValue = auditInquiryForm.getAuditParamValue();
		String expectedSkuCount = auditInquiryForm.getExpectedSkuCount();
		String resultSkuCount = auditInquiryForm.getResultSkuCount();
		String targetCount = auditInquiryForm.getTargetCount();
		String irregularKind = auditInquiryForm.getIrregularKind();
				
		if (!StringUtils.isEmpty(auditNoStart) && StringUtils.isEmpty(auditNoEnd)) {
			auditNoEnd = auditNoStart;
		}
		if (StringUtils.isEmpty(auditNoStart) && !StringUtils.isEmpty(auditNoEnd)) {
			auditNoStart = auditNoEnd;
		}
		if (!StringUtils.isEmpty(startDateStart) && !StringUtils.isEmpty(startDateEnd)) {

			if (CommonUtility.comparedateStartafterEnd(startDateStart, startDateEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String startDate = messageSource.getMessage("auditInquiry.startDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("startDate", startDate);
				return modelView;
			}
		}
		
		
		AuditInquiry auditInquiry = new AuditInquiry();
		auditInquiry.setAuditNoStart(auditNoStart);
		auditInquiry.setAuditNoEnd(auditNoEnd);
		auditInquiry.setStartDateStart(startDateStart);
		auditInquiry.setStartDateEnd(startDateEnd);
		auditInquiry.setExpectedCount(expectedCount);
		auditInquiry.setResultCount(resultCount);
		auditInquiry.setStartTime(startTime);
		auditInquiry.setIrregularKind(irregularKind);
		auditInquiry.setIrregularKindName(irregularKindName);
		auditInquiry.setAuditId(auditId);
		auditInquiry.setAuditParamValue(auditParamValue);
		auditInquiry.setAuditParamValueFrom(auditParamValueFrom);
		auditInquiry.setAuditParamValueTo(auditParamValueTo);
		auditInquiry.setAuditTypeName(auditTypeName);
		auditInquiry.setExpectedSkuCount(expectedSkuCount);
		auditInquiry.setResultSkuCount(resultSkuCount);
		auditInquiry.setTargetCount(targetCount);
		
		auditInquiry.setMaxReauditCount(Integer.parseInt(maxReauditCount));
		
		if (!StringUtils.isEmpty(auditInquiry.getStartDateStart()) && StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {

			String startDateFrom = auditInquiry.getStartDateStart();

			auditInquiry.setStartDateEnd(startDateFrom);
		}
		if (StringUtils.isEmpty(auditInquiry.getStartDateStart()) && !StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {

			String startDateTo =auditInquiry.getStartDateEnd();

			auditInquiry.setStartDateStart(startDateTo);
		}
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=auditInquiryService.selectCountt(auditInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<AuditInquiry> auditList = auditInquiryService.findAuditInquiry(auditInquiry);

		if (CollectionUtils.isEmpty(auditList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		    }

		for (int i = 0; i < auditList.size(); i++) {
			if (StringUtils.isEmpty(auditList.get(i).getExpectedCount())) {
				auditList.get(i).setExpectedCount("");
			}
			if (StringUtils.isEmpty(auditList.get(i).getResultCount())) {
				auditList.get(i).setResultCount("");
			}
			
			if (!StringUtils.isEmpty(auditList.get(i).getStartDate())&& !StringUtils.isEmpty(auditList.get(i).getStartTime())) {
				String str = auditList.get(i).getStartDate() + auditList.get(i).getStartTime();
				String newstr = CommonUtility.getDateTime(str);
				auditList.get(i).setStartDateTime(newstr);
			}
		}
		boolean flag =true;
		modelView.addObject("flag", flag);
		modelView.addObject("auditList", auditList);
		return modelView;
	}
	
	
	@RequestMapping(value = "/audit_inquiry", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("auditInquiryForm") AuditInquiryForm auditInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- AuditInquiryController.download() start ---");
		String [] orderIds = auditInquiryForm.getOrderIDs();
		
		if(orderIds == null||orderIds.length == 0){
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/audit_inquiry");
			return modelView;
		}
		
		List<String> orderIdList = new ArrayList<String>(); 
		for (String orderId : orderIds) {
			orderIdList.add(orderId);
		}
		
		// 棚卸履歴データ検索
		List<AuditInquiryDetailCsv> auditInquiryDetailCsvList = 
				auditInquiryService.findAuditInquiryDetailCsv(orderIdList);
		
		// 検索条件に該当する棚卸履歴データが存在しない場合
		if (CollectionUtils.isEmpty(auditInquiryDetailCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/audit_inquiry");
			return modelView;
		}
		
		modelView.addObject("auditInquiryDetailCsvList", auditInquiryDetailCsvList);
		modelView.setViewName("AuditInquiryCsvView");
		
		return modelView;
	}
	
	@RequestMapping(value = "/audit_inquiry", params = "action=print")
	public ModelAndView print(@Validated @ModelAttribute("auditInquiryForm") AuditInquiryForm auditInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) throws Exception {
		logger.info("--- AuditInquiryController.print() start ---");
		modelView.setViewName("/audit_inquiry");
		// 検索条件未指定の場合
		String auditNos[] = auditInquiryForm.getAuditNost();

		if (auditNos == null || auditNos.length == 0) {
			String message = messageSource.getMessage("auditInquiry.print.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String printerCode = auditInquiryForm.getPrinterCode();
		if (StringUtils.isEmpty(printerCode)) {
			String message = messageSource.getMessage("Common.print.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<String> auditNosList = new ArrayList<String>();
		for (String a : auditNos) {
			if (!auditNosList.contains(a)) {
				auditNosList.add(a);
			}
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		// 棚卸履歴データ検索
		for (int i = 0; i < auditNosList.size(); i++) {
			List<AuditInquiryReports> auditInquiryReportList = auditInquiryService
					.findAuditInquiryReport(auditNosList.get(i));
			if (CollectionUtils.isEmpty(auditInquiryReportList)) {
				continue;
			}
			AuditInquiryReport reprot = new AuditInquiryReport("AuditInquiryReport");
			AuditInquiryReport1 reprot1 = new AuditInquiryReport1("AuditInquiryReport1");
			reprot.buildDocument(auditInquiryReportList, request);
			reprot1.buildDocument(auditInquiryReportList, request);
			reprot.exportReport(printerCode);
			reprot1.exportReport(printerCode);
			/*AuditInquiry auditInquiryList = this.getPrintLogInfo(userDetails, sysDate, sysTime);
			auditInquiryList.setPrinter(auditInquiryForm.getPrinterCode());
			auditInquiryList.setFormId(reprot.getReportFileName());
			auditInquiryList.setFormName(reprot.getReportFileName()+"_"+timeStemp+"_"+auditInquiryForm.getPrinterCode()+".pdf");
			auditInquiryList.setFilePath(commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint"));
			auditInquiryService.insertPrintLog(auditInquiryList);*/
			AuditInquiry auditInquiryList1 = this.getPrintLogInfo(userDetails, sysDate, sysTime);
			auditInquiryList1.setPrinter(auditInquiryForm.getPrinterCode());
			auditInquiryList1.setFormId(reprot1.getReportFileName());
			auditInquiryList1.setFormName(reprot1.getReportFileNameLog()+".pdf");
			auditInquiryList1.setFilePath(commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint"));
			auditInquiryService.insertPrintLog(auditInquiryList1);
		}
		
		for (int i = 0; i < auditNosList.size(); i++) {
			List<AuditInquiryReports> auditInquiryExpectReportList = auditInquiryService
					.findAuditInquiryExpectReport(auditNosList.get(i));
			if (CollectionUtils.isEmpty(auditInquiryExpectReportList)) {
				continue;
			}
			AuditInquiryReport reprot = new AuditInquiryReport("AuditExpectionReport");
			AuditInquiryReport1 reprot1 = new AuditInquiryReport1("AuditExpectionReport1");
			reprot.buildDocument(auditInquiryExpectReportList, request);
			reprot.exportReport(printerCode);
			reprot1.buildDocument(auditInquiryExpectReportList, request);
			reprot1.exportReport(printerCode);
		/*	AuditInquiry auditInquiryList = this.getPrintLogInfo(userDetails, sysDate, sysTime);
			auditInquiryList.setPrinter(auditInquiryForm.getPrinterCode());
			auditInquiryList.setFormId(reprot.getReportFileName());
			auditInquiryList.setFormName(reprot.getReportFileName()+"_"+timeStemp+"_"+auditInquiryForm.getPrinterCode()+".pdf");
			auditInquiryList.setFilePath(commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint"));
			auditInquiryService.insertPrintLog(auditInquiryList);*/
			AuditInquiry auditInquiryList1 = this.getPrintLogInfo(userDetails, sysDate, sysTime);
			auditInquiryList1.setPrinter(auditInquiryForm.getPrinterCode());
			auditInquiryList1.setFormId(reprot1.getReportFileName());
			auditInquiryList1.setFormName(reprot1.getReportFileNameLog()+".pdf");
			auditInquiryList1.setFilePath(commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint"));
			auditInquiryService.insertPrintLog(auditInquiryList1);
			
		}
		
		String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
		modelView.addObject("validationMessage", message);
		return modelView;
	}
	
	
	private AuditInquiry getPrintLogInfo(UserDetails userDetails,String sysDate, String sysTime) throws ParseException{
		String Seqence = auditInquiryService.selectPrintLogSeqence().trim();
		AuditInquiry auditInquiryList = new AuditInquiry();
		auditInquiryList.setPrintId(Seqence);
		auditInquiryList.setPrintDate(commonService.getPrintdate());
		auditInquiryList.setPrintTime(sysTime);
		auditInquiryList.setUserCode(userDetails.getUsername());
		auditInquiryList.setCreateUser(userDetails.getUsername());
		auditInquiryList.setCreateDate(sysDate);
		auditInquiryList.setCreateTime(sysTime);
		auditInquiryList.setUpdateUser(userDetails.getUsername());
		auditInquiryList.setUpdateDate(sysDate);
		auditInquiryList.setUpdateTime(sysTime);
		return auditInquiryList;
		
	}
	

}

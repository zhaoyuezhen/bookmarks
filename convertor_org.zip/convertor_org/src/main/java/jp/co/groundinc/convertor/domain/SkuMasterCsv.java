package jp.co.groundinc.convertor.domain;

public class SkuMasterCsv {

	private String sku;
	private String skuName;
	private String skuKind;
	private float cbm;
	private int skuWidth;
	private int skuDepth;
	private int skuHeight;
	private int skuWeight;
	private String scanningCode;
	private String categoryCode;
	private String area;
	private String skuImageUrl;
	private String logisticsSkuName;
	private String logisticsSkuKind;
    private double logisticsCbm;
    private int logisticsSkuWidth;
	private int logisticsSkuDepth;
	private int logisticsSkuHeight;
	private int logisticsSkuWeight;
    private String logisticsScanningCode;
	private String logisticsSkuImageUrl;
	private String comments;
	private String msuSlotType;
	private String stockDirection;
	private String stackingFlag;
	private String nestingFlag;
	private String maxNestingCount;
	private String nestingWidth;
	private String nestingDepth;
	private String nestingHeight;
	private String nestingDirection;
	private String fragileFlag;
	private String slotType;
	private String logicalDeletionFlag;
	private String checkFlag;
	private String createUser;
	private String createDate;
	private String createTime;
	private String updateUser;
	private String updateDate;
	private String updateTime;
	private String checkStatus;
	private String checkStatusName;
	private String stockStatus;
	private String stockStatusName;
	private String deletionKind;
	private String deletionKindName;
	private String status;
    private String csvExportDate;
	private String csvExportTime;
	
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCheckStatusName() {
		return checkStatusName;
	}
	public void setCheckStatusName(String checkStatusName) {
		this.checkStatusName = checkStatusName;
	}
	public String getLogisticsSkuName() {
		return logisticsSkuName;
	}
	public void setLogisticsSkuName(String logisticsSkuName) {
		this.logisticsSkuName = logisticsSkuName;
	}
	public String getLogisticsSkuKind() {
		return logisticsSkuKind;
	}
	public void setLogisticsSkuKind(String logisticsSkuKind) {
		this.logisticsSkuKind = logisticsSkuKind;
	}
	public int getLogisticsSkuWidth() {
		return logisticsSkuWidth;
	}
	public void setLogisticsSkuWidth(int logisticsSkuWidth) {
		this.logisticsSkuWidth = logisticsSkuWidth;
	}
	public int getLogisticsSkuDepth() {
		return logisticsSkuDepth;
	}
	public void setLogisticsSkuDepth(int logisticsSkuDepth) {
		this.logisticsSkuDepth = logisticsSkuDepth;
	}
	public int getLogisticsSkuHeight() {
		return logisticsSkuHeight;
	}
	public void setLogisticsSkuHeight(int logisticsSkuHeight) {
		this.logisticsSkuHeight = logisticsSkuHeight;
	}
	public String getLogisticsScanningCode() {
		return logisticsScanningCode;
	}
	public void setLogisticsScanningCode(String logisticsScanningCode) {
		this.logisticsScanningCode = logisticsScanningCode;
	}
	public String getLogisticsSkuImageUrl() {
		return logisticsSkuImageUrl;
	}
	public void setLogisticsSkuImageUrl(String logisticsSkuImageUrl) {
		this.logisticsSkuImageUrl = logisticsSkuImageUrl;
	}
	public int getLogisticsSkuWeight() {
		return logisticsSkuWeight;
	}
	public void setLogisticsSkuWeight(int logisticsSkuWeight) {
		this.logisticsSkuWeight = logisticsSkuWeight;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSkuImageUrl() {
		return skuImageUrl;
	}
	public void setSkuImageUrl(String skuImageUrl) {
		this.skuImageUrl = skuImageUrl;
	}
	public String getCheckFlag() {
		return checkFlag;
	}
	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}
	public String getDeletionKind() {
		return deletionKind;
	}
	public void setDeletionKind(String deletionKind) {
		this.deletionKind = deletionKind;
	}
	public String getCheckStatus() {
		return checkStatus;
	}
	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getStockStatus() {
		return stockStatus;
	}
	public void setStockStatus(String stockStatus) {
		this.stockStatus = stockStatus;
	}
	public String getCbm() {
        return String.format("%.6f", cbm);
    }
	public void setCbm(float cbm) {
		this.cbm = cbm;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getLogisticsCbm() {
        return String.format("%.6f", logisticsCbm);
    }
	public void setLogisticsCbm(double logisticsCbm) {
		this.logisticsCbm = logisticsCbm;
	}
	public int getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(int skuWidth) {
		this.skuWidth = skuWidth;
	}
	public int getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(int skuDepth) {
		this.skuDepth = skuDepth;
	}
	public int getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(int skuHeight) {
		this.skuHeight = skuHeight;
	}
	public int getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(int skuWeight) {
		this.skuWeight = skuWeight;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getMsuSlotType() {
		return msuSlotType;
	}
	public void setMsuSlotType(String msuSlotType) {
		this.msuSlotType = msuSlotType;
	}
	public String getStockDirection() {
		return stockDirection;
	}
	public void setStockDirection(String stockDirection) {
		this.stockDirection = stockDirection;
	}
	public String getStackingFlag() {
		return stackingFlag;
	}
	public void setStackingFlag(String stackingFlag) {
		this.stackingFlag = stackingFlag;
	}
	public String getNestingFlag() {
		return nestingFlag;
	}
	public void setNestingFlag(String nestingFlag) {
		this.nestingFlag = nestingFlag;
	}
	public String getMaxNestingCount() {
		return maxNestingCount;
	}
	public void setMaxNestingCount(String maxNestingCount) {
		this.maxNestingCount = maxNestingCount;
	}
	public String getNestingWidth() {
		return nestingWidth;
	}
	public void setNestingWidth(String nestingWidth) {
		this.nestingWidth = nestingWidth;
	}
	public String getNestingDepth() {
		return nestingDepth;
	}
	public void setNestingDepth(String nestingDepth) {
		this.nestingDepth = nestingDepth;
	}
	public String getNestingHeight() {
		return nestingHeight;
	}
	public void setNestingHeight(String nestingHeight) {
		this.nestingHeight = nestingHeight;
	}
	public String getNestingDirection() {
		return nestingDirection;
	}
	public void setNestingDirection(String nestingDirection) {
		this.nestingDirection = nestingDirection;
	}
	public String getFragileFlag() {
		return fragileFlag;
	}
	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}
	public String getSlotType() {
		return slotType;
	}
	public void setSlotType(String slotType) {
		this.slotType = slotType;
	}
	public String getLogicalDeletionFlag() {
		return logicalDeletionFlag;
	}
	public void setLogicalDeletionFlag(String logicalDeletionFlag) {
		this.logicalDeletionFlag = logicalDeletionFlag;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getStockStatusName() {
		return stockStatusName;
	}
	public void setStockStatusName(String stockStatusName) {
		this.stockStatusName = stockStatusName;
	}
	public String getDeletionKindName() {
		return deletionKindName;
	}
	public void setDeletionKindName(String deletionKindName) {
		this.deletionKindName = deletionKindName;
	}
}

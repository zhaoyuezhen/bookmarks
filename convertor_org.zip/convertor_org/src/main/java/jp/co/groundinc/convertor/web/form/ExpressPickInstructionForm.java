package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


public class ExpressPickInstructionForm {
	
	private static final long serialVersionUID = 1L;

	private String expectedDate;
    
	private String picklistKind;
	
	private String picklistKindName;
	
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{expressPickInstruction.orderId.Halfangle.message}")
	private String orderId;
	
	private String [] auditNost;
	
	private String totalExpectedCount;
	
	private String pickDate;
	
	@NotNull(message = "{expressPickInstruction.pickDateStart.empty.message}")
	@NotEmpty(message = "{expressPickInstruction.pickDateStart.empty.message}")
	private String pickDateStart;
	
	private String pickDateEnd;
	
	private String dataRecievedDateStart;

	private String dataRecievedDateEnd;
	
	private String dataRecievedTimeStart;
	
	private String dataRecievedTimeEnd;
	
	public String getExpectedDate() {
		return expectedDate;
	}

	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}

	public String getPicklistKind() {
		return picklistKind;
	}

	public void setPicklistKind(String picklistKind) {
		this.picklistKind = picklistKind;
	}

	public String getPicklistKindName() {
		return picklistKindName;
	}

	public void setPicklistKindName(String picklistKindName) {
		this.picklistKindName = picklistKindName;
	}

	public String getOrderId() {
		return orderId;
	}

	public String[] getAuditNost() {
		return auditNost;
	}
	public void setAuditNost(String[] auditNost) {
		this.auditNost = auditNost;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTotalExpectedCount() {
		return totalExpectedCount;
	}

	public void setTotalExpectedCount(String totalExpectedCount) {
		this.totalExpectedCount = totalExpectedCount;
	}

	public String getPickDate() {
		return pickDate;
	}

	public void setPickDate(String pickDate) {
		this.pickDate = pickDate;
	}

	public String getPickDateStart() {
		return pickDateStart;
	}

	public void setPickDateStart(String pickDateStart) {
		this.pickDateStart = pickDateStart;
	}

	public String getPickDateEnd() {
		return pickDateEnd;
	}

	public void setPickDateEnd(String pickDateEnd) {
		this.pickDateEnd = pickDateEnd;
	}

	public String getDataRecievedDateStart() {
		return dataRecievedDateStart;
	}

	public void setDataRecievedDateStart(String dataRecievedDateStart) {
		this.dataRecievedDateStart = dataRecievedDateStart;
	}

	public String getDataRecievedDateEnd() {
		return dataRecievedDateEnd;
	}

	public void setDataRecievedDateEnd(String dataRecievedDateEnd) {
		this.dataRecievedDateEnd = dataRecievedDateEnd;
	}

	public String getDataRecievedTimeStart() {
		return dataRecievedTimeStart;
	}

	public void setDataRecievedTimeStart(String dataRecievedTimeStart) {
		this.dataRecievedTimeStart = dataRecievedTimeStart;
	}

	public String getDataRecievedTimeEnd() {
		return dataRecievedTimeEnd;
	}

	public void setDataRecievedTimeEnd(String dataRecievedTimeEnd) {
		this.dataRecievedTimeEnd = dataRecievedTimeEnd;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

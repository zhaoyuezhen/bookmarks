package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class StowProgress implements Serializable {

	private static final long serialVersionUID = 1L;

	private String operationDate;
	@NotNull(message = "{StowProgress.search.dataReceivedDate.empty.message}")
	private String dataReceivedDate;
	
	private String nextdataReceivedDate;
	
	private String dataReceivedTime;
	
	private String nextdataReceivedTime;

	private String putProgressKey;

	private String putProgressKeyName;

	private String totalExpectedCount;

	private String totalCompletedCount;

	private String totalIncompletedCount;

	private String completedRate;

	private String nextOperationDate;
	
    private String putKind;
	
	private String putKindName;
	
	private String DataReceivedTimeStart;
	
	private String DataReceivedTimeEnd;
	
	public String getPutKind() {
		return putKind;
	}

	public void setPutKind(String putKind) {
		this.putKind = putKind;
	}

	public String getPutKindName() {
		return putKindName;
	}

	public void setPutKindName(String putKindName) {
		this.putKindName = putKindName;
	}

	public String getNextdataReceivedDate() {
		return nextdataReceivedDate;
	}

	public void setNextdataReceivedDate(String nextdataReceivedDate) {
		this.nextdataReceivedDate = nextdataReceivedDate;
	}

	public String getTotalIncompletedCount() {
		return totalIncompletedCount;
	}

	public void setTotalIncompletedCount(String totalIncompletedCount) {
		this.totalIncompletedCount = totalIncompletedCount;
	}

	public String getNextOperationDate() {
		return nextOperationDate;
	}

	public void setNextOperationDate(String nextOperationDate) {
		this.nextOperationDate = nextOperationDate;
	}

	public String getOperationDate() {
		return operationDate;
	}

	public void setOperationDate(String operationDate) {
		this.operationDate = operationDate;
	}

	public String getDataReceivedDate() {
		return dataReceivedDate;
	}

	public void setDataReceivedDate(String dataReceivedDate) {
		this.dataReceivedDate = dataReceivedDate;
	}

	public String getPutProgressKey() {
		return putProgressKey;
	}

	public void setPutProgressKey(String putProgressKey) {
		this.putProgressKey = putProgressKey;
	}

	public String getPutProgressKeyName() {
		return putProgressKeyName;
	}

	public void setPutProgressKeyName(String putProgressKeyName) {
		this.putProgressKeyName = putProgressKeyName;
	}

	public String getTotalExpectedCount() {
		return totalExpectedCount;
	}

	public void setTotalExpectedCount(String totalExpectedCount) {
		this.totalExpectedCount = totalExpectedCount;
	}

	public String getTotalCompletedCount() {
		return totalCompletedCount;
	}

	public void setTotalCompletedCount(String totalCompletedCount) {
		this.totalCompletedCount = totalCompletedCount;
	}

	public String getCompletedRate() {
		return completedRate;
	}

	public void setCompletedRate(String completedRate) {
		this.completedRate = completedRate;
	}
	public String getDataReceivedTimeStart() {
		return DataReceivedTimeStart;
	}

	public void setDataReceivedTimeStart(String dataReceivedTimeStart) {
		DataReceivedTimeStart = dataReceivedTimeStart;
	}

	public String getDataReceivedTimeEnd() {
		return DataReceivedTimeEnd;
	}

	public void setDataReceivedTimeEnd(String dataReceivedTimeEnd) {
		DataReceivedTimeEnd = dataReceivedTimeEnd;
	}
	public String getDataReceivedTime() {
		return dataReceivedTime;
	}

	public void setDataReceivedTime(String dataReceivedTime) {
		this.dataReceivedTime = dataReceivedTime;
	}

	public String getNextdataReceivedTime() {
		return nextdataReceivedTime;
	}

	public void setNextdataReceivedTime(String nextdataReceivedTime) {
		this.nextdataReceivedTime = nextdataReceivedTime;
	}

}

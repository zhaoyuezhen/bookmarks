package jp.co.groundinc.convertor.service;

import java.text.ParseException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.domain.PickList;
import jp.co.groundinc.convertor.domain.PickListCsv;
import jp.co.groundinc.convertor.mapper.PickListMapper;

@Service
public class PickListService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	PickListMapper pickListMapper;

	public List<PickList> selectPickList() {
		List<PickList> list = pickListMapper.selectPickList();
		return list;

	}
	
	public int selectCountt(PickList pickList) {

		int count = pickListMapper.selectCountt(pickList);
		return count;
	}
	public String getOrderPick() throws ParseException {
		logger.info("--- PickListService.getOrderPick() start ---");
		String orderPick = pickListMapper.selectOrderPick(); 
		return orderPick;
	}
	public String getTotalPick() throws ParseException {
		logger.info("--- PickListService.getTotalPick() start ---");
		String totalPick = pickListMapper.selectTotalPick(); 
		return totalPick;
	}
	public String getNote1() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note1 = pickListMapper.selectNote1(); 
		return note1;
	}
	public String getNote2() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note2 = pickListMapper.selectNote2(); 
		return note2;
	}
	public String getNote3() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note3 = pickListMapper.selectNote3(); 
		return note3;
	}
	public String getNote4() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note4 = pickListMapper.selectNote4(); 
		return note4;
	}
	public String getNote5() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note5 = pickListMapper.selectNote5(); 
		return note5;
	}
	public String getNote6() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note6 = pickListMapper.selectNote6(); 
		return note6;
	}
	public String getNote7() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note7 = pickListMapper.selectNote7(); 
		return note7;
	}
	public String getNote8() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note8 = pickListMapper.selectNote8(); 
		return note8;
	}
	public String getNote9() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note9 = pickListMapper.selectNote9(); 
		return note9;
	}
	public String getNote10() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note10 = pickListMapper.selectNote10(); 
		return note10;
	}
	public String getNote11() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note11 = pickListMapper.selectNote11(); 
		return note11;
	}
	public String getNote12() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note12 = pickListMapper.selectNote12(); 
		return note12;
	}
	public String getNote13() throws ParseException {
		logger.info("--- PickListService.getNote() start ---");
		String note13 = pickListMapper.selectNote13(); 
		return note13;
	}
	public String selectprocessSequenceNo() {
		logger.info("--- PickListService.selectprocessSequenceNo() start ---");
		String processSequenceNo = pickListMapper.selectOrderProcessSeqence();
		return processSequenceNo;
	}
	
	public int updateAllMissingOrderInterface(String processSequence ){
		logger.info("--- PickListService.updateOrderAreaInterface() start ---");
		int i = pickListMapper.updateAllMissingOrderInterface(processSequence);
		return i ;
	}
	public int updateOrderAreaInterface(PickList pickList ){
		logger.info("--- PickListService.updateOrderAreaInterface() start ---");
		int i = pickListMapper.updateOrderAreaInterface(pickList);
		return i ;
	}
	
	public int updateOrderSendStatusInterface(PickList pickList ){
		logger.info("--- PickListService.updateOrderSendkindInterface() start ---");
		int i = pickListMapper.updateOrderSkuKindInterface(pickList);
		return i ;
		
	}
	
	public List<PickListCsv> findPickListArea1OrderCsv(String processSequenceNo ){
		logger.info("--- PickListService.findPickListArea1OrderCsv() start ---");
		List<PickListCsv> PickListOrderCsvList = pickListMapper.findPickListArea1OrderCsv(processSequenceNo);
		return PickListOrderCsvList;
		
	}
	
	public List<PickListCsv> findPickListArea1TotaruCsv(String processSequenceNo ){
		logger.info("--- PickListService.findPickListArea1TotaruCsv() start ---");
		List<PickListCsv> PickListTotaruCsvList = pickListMapper.findPickListArea1TotaruCsv(processSequenceNo);
		return PickListTotaruCsvList;
		
	}
	
	public List<PickListCsv> findPickListArea29OrderCsv(PickList pickList ){
		logger.info("--- PickListService.PickList findPickListArea2OrderCsv() start ---");
		List<PickListCsv> PickListOrderCsvList = pickListMapper.findPickListArea29OrderCsv(pickList);
		return PickListOrderCsvList;
		
	}
	public List<PickListCsv> findPickListArea29TotalCsv(PickList pickList ){
		logger.info("--- PickListService.PickList findPickListArea2TotalCsv() start ---");
		List<PickListCsv> PickListTotalCsvList = pickListMapper.findPickListArea29TotalCsv(pickList);
		return PickListTotalCsvList;
		
	}
	public List<PickListCsv> findPickListArea1030OrderCsv(PickList pickList ){
		logger.info("--- PickListService.PickList findPickListArea2OrderCsv() start ---");
		List<PickListCsv> PickListOrderCsvList = pickListMapper.findPickListArea1030OrderCsv(pickList);
		return PickListOrderCsvList;
		
	}
	public List<PickListCsv> findPickListArea1030TotalCsv(PickList pickList ){
		logger.info("--- PickListService.PickList findPickListArea2TotalCsv() start ---");
		List<PickListCsv> PickListTotalCsvList = pickListMapper.findPickListArea1030TotalCsv(pickList);
		return PickListTotalCsvList;
		
	}
	
	public List<PickListCsv> findPickListAllMissingCsv(String processSequence ){
		logger.info("--- PickListService.PickList findPickListArea2TotalCsv() start ---");
		List<PickListCsv> findPickListAllMissingCsv = pickListMapper.findPickListAllMissingCsv(processSequence);
		return findPickListAllMissingCsv;
		
	}
	
	public void insertPrintLog(PickList pickList ){
		logger.info("--- PickListService.insertPrintLog() start ---");
		pickListMapper.insertPrintLog(pickList);
		
	}
	
}
package jp.co.groundinc.convertor.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.groundinc.convertor.domain.ManualPickInstruction;
import jp.co.groundinc.convertor.domain.ManualPickInstructionReports;

@Mapper
public interface ManualPickInstructionMapper {
	List<ManualPickInstruction> selectPickInquiryInfo(ManualPickInstruction manualPickInstruction);
	String selectOrderSeqence();
	String selectOrderProcessSeqence();
	void update(ManualPickInstruction manualPickInstruction);
	int insertOrderManual(ManualPickInstruction manualPickInstruction);
	int selectCountt(ManualPickInstruction manualPickInstruction);
	List<ManualPickInstructionReports> selectManualPickInstructionReports(
			@Param("orderId") String orderId);
}

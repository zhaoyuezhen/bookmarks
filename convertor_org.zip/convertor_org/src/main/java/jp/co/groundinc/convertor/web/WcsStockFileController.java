package jp.co.groundinc.convertor.web;

import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import jp.co.groundinc.convertor.service.WcsStockfileService;
import jp.co.groundinc.convertor.web.form.WcsStockForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class WcsStockFileController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	WcsStockfileService wcsStockfileService;
	
	@ModelAttribute("wcsStockForm")
	public WcsStockForm wcsStockForm() {
		logger.info("--- WcsStockFileController.wcsStockForm() start ---");
		return new WcsStockForm();
	}

	@RequestMapping("/wcs_stock_file")
	public ModelAndView wcsStockFile(ModelAndView modelView) {
		logger.info("--- WcsStockFileController.wcsStockFile() start ---");
		return modelView;
	}
	
	@RequestMapping(value = "/wcs_stock_file", params = "action=output")
	public ModelAndView outputStockFile(ModelAndView modelView) {
		modelView.setViewName("/wcs_stock_file");
		
		String message = "";
		if (wcsStockfileService.outputStockFile()) {
			message = messageSource.getMessage("wcsStockFile.success.message", null, Locale.JAPAN);
		} else {
			message = messageSource.getMessage("wcsStockFile.fail.message", null, Locale.JAPAN);
		}
		modelView.addObject("validationMessage", message);
		
		return modelView;
	}
}

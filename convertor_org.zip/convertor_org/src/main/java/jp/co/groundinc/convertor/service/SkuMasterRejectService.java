package jp.co.groundinc.convertor.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.SkuMasterReject;
import jp.co.groundinc.convertor.mapper.SkuMasterRejectMapper;
@Service
public class SkuMasterRejectService {

	@Autowired
	SkuMasterRejectMapper skuMasterRejectMapper;
	@Autowired
	CommonUtility commonUtility;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<SkuMasterReject> selectSkuMasterReject(SkuMasterReject skuMasterReject) {

		String receiveddateStart = CommonUtility.dateFomat(skuMasterReject.getDataReceivedDateStart());
		skuMasterReject.setDataReceivedDateStart(receiveddateStart);
		String receiveddateEnd = CommonUtility.dateFomat(skuMasterReject.getDataReceivedDateEnd());
		skuMasterReject.setDataReceivedDateEnd(receiveddateEnd);
		
		List<SkuMasterReject> list = skuMasterRejectMapper.selectSkuMasterReject(skuMasterReject);
		return list;

	}
	
	public int selectCount(SkuMasterReject skuMasterReject) {

		String receiveddateStart = CommonUtility.dateFomat(skuMasterReject.getDataReceivedDateStart());
		skuMasterReject.setDataReceivedDateStart(receiveddateStart);
		String receiveddateEnd = CommonUtility.dateFomat(skuMasterReject.getDataReceivedDateEnd());
		skuMasterReject.setDataReceivedDateEnd(receiveddateEnd);
		
		int count = skuMasterRejectMapper.selectCount(skuMasterReject);
		return count;

	}
	

}

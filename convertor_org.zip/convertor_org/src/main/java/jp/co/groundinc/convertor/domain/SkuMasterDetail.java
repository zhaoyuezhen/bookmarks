package jp.co.groundinc.convertor.domain;

public class SkuMasterDetail {

	private String sku;
	
	private String skuName;
	
	private String cbm;
	
	private String skuKind;
	
	/** 梱包幅*/
	private int skuWidth;
	
	/** 梱包奥行*/
	private int skuDepth;
	
	/** 梱包高さ*/
	private int skuHeight;
	
	/** 重量*/
	private int skuWeight;
	
	/** スキャニングコード*/
	private String scanningCode;

	private String skuImageUrl;
	
    private String logisticsSkuName;
	
	private String logisticsCbm;
	
	private String logisticsSkuKind;
	
	private int logisticsSkuWidth;
	
	private int logisticsSkuDepth;
	
	private int logisticsSkuHeight;
	
	private int logisticsSkuWeight;
	
	private String logisticsScanningCode;
	
	private String logisticsSkuImageUrl;
	
	
	public String getLogisticsSkuName() {
		return logisticsSkuName;
	}
	public void setLogisticsSkuName(String logisticsSkuName) {
		this.logisticsSkuName = logisticsSkuName;
	}
	public String getLogisticsCbm() {
		return logisticsCbm;
	}
	public void setLogisticsCbm(String logisticsCbm) {
		this.logisticsCbm = logisticsCbm;
	}
	public String getLogisticsSkuKind() {
		return logisticsSkuKind;
	}
	public void setLogisticsSkuKind(String logisticsSkuKind) {
		this.logisticsSkuKind = logisticsSkuKind;
	}
	public int getLogisticsSkuWidth() {
		return logisticsSkuWidth;
	}
	public void setLogisticsSkuWidth(int logisticsSkuWidth) {
		this.logisticsSkuWidth = logisticsSkuWidth;
	}
	public int getLogisticsSkuDepth() {
		return logisticsSkuDepth;
	}
	public void setLogisticsSkuDepth(int logisticsSkuDepth) {
		this.logisticsSkuDepth = logisticsSkuDepth;
	}
	public int getLogisticsSkuHeight() {
		return logisticsSkuHeight;
	}
	public void setLogisticsSkuHeight(int logisticsSkuHeight) {
		this.logisticsSkuHeight = logisticsSkuHeight;
	}
	public int getLogisticsSkuWeight() {
		return logisticsSkuWeight;
	}
	public void setLogisticsSkuWeight(int logisticsSkuWeight) {
		this.logisticsSkuWeight = logisticsSkuWeight;
	}
	public String getLogisticsScanningCode() {
		return logisticsScanningCode;
	}
	public void setLogisticsScanningCode(String logisticsScanningCode) {
		this.logisticsScanningCode = logisticsScanningCode;
	}
	public String getLogisticsSkuImageUrl() {
		return logisticsSkuImageUrl;
	}
	public void setLogisticsSkuImageUrl(String logisticsSkuImageUrl) {
		this.logisticsSkuImageUrl = logisticsSkuImageUrl;
	}
	
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSkuImageUrl() {
		return skuImageUrl;
	}
	public void setSkuImageUrl(String skuImageUrl) {
		this.skuImageUrl = skuImageUrl;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public int getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(int skuWidth) {
		this.skuWidth = skuWidth;
	}
	public int getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(int skuDepth) {
		this.skuDepth = skuDepth;
	}
	public int getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(int skuHeight) {
		this.skuHeight = skuHeight;
	}
	public int getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(int skuWeight) {
		this.skuWeight = skuWeight;
	}
}

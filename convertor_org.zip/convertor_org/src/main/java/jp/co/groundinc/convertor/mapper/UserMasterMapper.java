package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.domain.UserMasterCsv;

@Mapper
public interface UserMasterMapper {
	UserMaster findByUserCd(String userCd);
	int countAll(UserMaster user);
	int selectCountt(UserMaster user);
	List<UserMaster> findAll(UserMaster user);
	void insert(UserMaster user);
	void update(UserMaster user);
	void delete(UserMaster user);
	void resetPwd(UserMaster user);
	List<UserMasterCsv> selectUserMasterCsv(
 			@Param("userCode") String userCode,
 			@Param("userName") String userName,
 			@Param("authorityKind") String authorityKind);
}

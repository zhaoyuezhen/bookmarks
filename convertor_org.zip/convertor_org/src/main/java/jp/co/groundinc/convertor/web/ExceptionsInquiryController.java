package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.ExceptionsInquiry;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.ExceptionsInquiryService;
import jp.co.groundinc.convertor.web.form.ExceptionsInquiryForm;
@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = {"exceptionsInquiryForm"}) 
public class ExceptionsInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	ExceptionsInquiryService exceptionsInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

    @ModelAttribute("exceptionsInquiryForm")
	public ExceptionsInquiryForm exceptionsInquiryForm() {
		logger.info("--- ExceptionsInquiryController.exceptionsInquiryForm() start ---");
		
		return new ExceptionsInquiryForm();
	}

    @ModelAttribute("exceptionDateStart")
	public String exceptionDateStart() throws ParseException {
		logger.info("--- ExceptionsInquiryController.exceptionDateStart() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("exceptionDateEnd")
	public String exceptionDateEnd() throws ParseException {
		logger.info("--- ExceptionsInquiryController.exceptionDateEnd() start ---");
		return commonService.getOperationDate();
	}
	
	@RequestMapping("/exceptions_inquiry")
	public String exceptionsInquiry(Model model, HttpServletRequest request) {
		logger.info("--- ExceptionsInquiryController.exceptionsInquiry() start ---");
		ExceptionsInquiryForm exceptionsInquiryForm = new ExceptionsInquiryForm();
		model.addAttribute("exceptionsInquiryForm", exceptionsInquiryForm);
		return "exceptions_inquiry";
	}


	@RequestMapping(value = "/exceptions_inquiry", params = "action=clear")
	public String exceptionsInquiryClear(HttpServletRequest request, Model model) throws ParseException {
		logger.info("--- exceptionsInquiryClear() start ---");
		ExceptionsInquiryForm exceptionsInquiryForm = new ExceptionsInquiryForm();
		model.addAttribute("ExceptionsInquiry",exceptionsInquiryForm);
		return "exceptions_inquiry";
	}

	@RequestMapping(value = "/exceptions_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("exceptionsInquiryForm") ExceptionsInquiryForm exceptionsInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- search() start ---");
		modelView.setViewName("/exceptions_inquiry");
		
		String exceptionDateStart = exceptionsInquiryForm.getExceptionDateStart();
		String exceptionDateEnd = exceptionsInquiryForm.getExceptionDateEnd();
		modelView.addObject("exceptionDateStart", exceptionDateStart);
		modelView.addObject("exceptionDateEnd", exceptionDateEnd);
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String sku = exceptionsInquiryForm.getSku();
		String skuName = exceptionsInquiryForm.getSkuName();
		if (!StringUtils.isEmpty(exceptionDateStart) && !StringUtils.isEmpty(exceptionDateEnd)) {
			if (CommonUtility.comparedateStartafterEnd(exceptionDateStart, exceptionDateEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("ExceptionsInquiry.exceptionDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
		 }
		
		ExceptionsInquiry exceptionsInquiry = new ExceptionsInquiry();
		exceptionsInquiry.setExceptionDateStart(exceptionDateStart);
		exceptionsInquiry.setExceptionDateEnd(exceptionDateEnd);
		exceptionsInquiry.setSku(sku);
		exceptionsInquiry.setSkuName(skuName);
		
		if (!StringUtils.isEmpty(exceptionsInquiryForm.getExceptionDateStart())
				&& StringUtils.isEmpty(exceptionsInquiryForm.getExceptionDateEnd())) {

			String exceptiondateStart = exceptionsInquiry.getExceptionDateStart();

			exceptionsInquiry.setExceptionDateEnd(exceptiondateStart);
		}
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = exceptionsInquiryService.selectCountt(exceptionsInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<ExceptionsInquiry> exceptionsInquiryList = exceptionsInquiryService.selectExceptionsInquiry(exceptionsInquiry);
		
		if (CollectionUtils.isEmpty(exceptionsInquiryList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		    }
		modelView.addObject("exceptionsInquiryList", exceptionsInquiryList);
		return modelView;
  }

	@RequestMapping(value = "/exceptions_inquiry/{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getSkuName(@PathVariable String skuCode) {
		logger.info("--- ExceptionsInquiryController.getSkuName() start ---");
		
		String skuName = "";
		
		if (!StringUtils.isEmpty(skuCode)) {
			skuName = commonService.getSkuName(skuCode);
		} 

		return skuName;
	}
}

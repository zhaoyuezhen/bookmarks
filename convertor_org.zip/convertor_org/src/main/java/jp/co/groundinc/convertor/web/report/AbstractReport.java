package jp.co.groundinc.convertor.web.report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;

public abstract class AbstractReport{
	private String reportName;
	
	private String reportFilePath;

	private String reportFileName;
	
	private String reportFileNameLog;
	
	

	private String[] reportHeaderCode;
	
	private String[] reportHeaderName;
	
	private List<?> documentDataList;
	
	private String clientHostName;
	
	public String getReportFileNameLog() {
		return reportFileNameLog;
	}

	public void setReportFileNameLog(String reportFileNameLog) {
		this.reportFileNameLog = reportFileNameLog;
	}

    public String getClientHostName() {
		return clientHostName;
	}

	public void setClientHostName(String clientHostName) {
		this.clientHostName = clientHostName;
	}

	public void setReportFileName(String fileName) {
        this.reportFileName = fileName;
    }
    
    public void setReportHeaderCode(String[] reportHeaderCode) {
        this.reportHeaderCode = reportHeaderCode;
    }
    
    public void setReportHeaderName(String[] reportHeaderName) {
        this.reportHeaderName = reportHeaderName;
    }
    
	public String getReportFilePath() {
		return reportFilePath;
	}

	public void setReportFilePath(String reportFilePath) {
		this.reportFilePath = reportFilePath;
	}
	
    public String getReportFileName() {
    	return this.reportFileName;
    }
    
    public String[] getReportHeaderCode() {
    	return this.reportHeaderCode;
    }
    
    public String[] getReportHeaderName() {
        return this.reportHeaderName;
    }
    
	public List<?> getDocumentDataList() {
		return documentDataList;
	}
	
	public AbstractReport(String reportName) {
		this.reportName = reportName;
	}

	public void setDocumentDataList(List<?> documentDataList, HttpServletRequest request) {
		this.documentDataList = documentDataList;
		this.clientHostName = request.getRemoteHost();
	}
	
	public void exportReport(String printerCode) throws Exception {
		Resource resource = new ClassPathResource("/reports.properties");
		Properties props = PropertiesLoaderUtils.loadProperties(resource);
		setReportFilePath(props.getProperty(reportName + ".reportFilePath"));
		setReportFileName(props.getProperty(reportName + ".reportFileName"));
		String filePath = new String(getReportFilePath().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName1 = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String timeStemp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String fileType = props.getProperty(reportName + ".reportFileType");
		String fileExtension = "";
		if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
			fileName = fileName + "_" + timeStemp + "_" + printerCode;
			reportFileNameLog = fileName;
			fileExtension = ".csv";
		} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
			fileName = fileName + timeStemp;
			fileExtension = ".txt";
		} else {
			throw new IOException("Invalid report file type!");
		}
		
		PrintWriter writer = null;
		try {
			Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
			writer = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(path), Charset.forName("Shift_JIS"))));
			setReportHeaderCode(props.getProperty(reportName + ".reportHeaderCode").split(",", 0));
			setReportHeaderName(props.getProperty(reportName + ".reportHeaderName").split(",", 0));
			if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
				CommonUtility.WriteCsvFile(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
			} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
				if(fileName1.equals("MS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}
				if(fileName1.equals("MM")){
					CommonUtility.WriteTsvFilehead(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("TS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("AS")){
					CommonUtility.createCtlFile(filePath, fileName);
				}
				if(fileName1.equals("RS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}
				
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}

	}
	
	
	public void exportReport1(String printerCode) throws Exception {
		Resource resource = new ClassPathResource("/reports.properties");
		Properties props = PropertiesLoaderUtils.loadProperties(resource);
		setReportFilePath(props.getProperty(reportName + ".reportFilePath"));
		setReportFileName(props.getProperty(reportName + ".reportFileName"));
		String filePath = new String(getReportFilePath().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName1 = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String timeStemp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String fileType = props.getProperty(reportName + ".reportFileType");
		String fileExtension = "";
		if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
			fileName = fileName + "_" + timeStemp + "_" + printerCode;
			fileExtension = ".csv";
		} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
			fileName = fileName + timeStemp;
			fileExtension = ".txt";
		} else {
			throw new IOException("Invalid report file type!");
		}
		
		PrintWriter writer = null;
		try {
			//Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
			
			setReportHeaderCode(props.getProperty(reportName + ".reportHeaderCode").split(",", 0));
			setReportHeaderName(props.getProperty(reportName + ".reportHeaderName").split(",", 0));
			if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
				CommonUtility.WriteCsvFile(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
			} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
				if(fileName1.equals("MS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}
				if(fileName1.equals("MM")){
					CommonUtility.WriteTsvFilehead(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("TS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("AS")){
					CommonUtility.createCtlFile(filePath, fileName);
				}
				
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}

	}
	
	public void exportReport2(String sysDate) throws Exception {
		Resource resource = new ClassPathResource("/reports.properties");
		Properties props = PropertiesLoaderUtils.loadProperties(resource);
		setReportFilePath(props.getProperty(reportName + ".reportFilePath")+sysDate+"\\");
		String pathtt = props.getProperty(reportName + ".reportFilePath")+sysDate+"\\";
		boolean folart = this.createDir(pathtt);
		if(!folart){
		return;
		}
		setReportFileName(props.getProperty(reportName + ".reportFileName"));
		String filePath = new String(getReportFilePath().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String fileName1 = new String(getReportFileName().getBytes("Shift_JIS"), "ISO-8859-1");
		String timeStemp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String fileType = props.getProperty(reportName + ".reportFileType");
		String fileExtension = "";
		if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
			fileName = fileName + timeStemp;
			reportFileNameLog = fileName;
			fileExtension = ".csv";
		} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
			fileName = fileName + timeStemp;
			fileExtension = ".txt";
		} else {
			throw new IOException("Invalid report file type!");
		}
		
		PrintWriter writer = null;
		try {
			Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
			writer = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(path), Charset.forName("Shift_JIS"))));
			setReportHeaderCode(props.getProperty(reportName + ".reportHeaderCode").split(",", 0));
			setReportHeaderName(props.getProperty(reportName + ".reportHeaderName").split(",", 0));
			if (CommonConstant.REPORT_TYPE_CSV.equals(fileType)) {
				CommonUtility.WriteCsvFile(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
			} else if (CommonConstant.REPORT_TYPE_TSV.equals(fileType)) {
				if(fileName1.equals("MS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}
				if(fileName1.equals("MM")){
					CommonUtility.WriteTsvFilehead(writer, getDocumentDataList(), getReportHeaderCode(), getReportHeaderName());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("TS")){
					CommonUtility.WriteTsvFile(writer, getDocumentDataList(), getReportHeaderCode());
					CommonUtility.createCtlFile(filePath, fileName);
				}if(fileName1.equals("AS")){
					CommonUtility.createCtlFile(filePath, fileName);
				}
				
			}
		} finally {
			if (writer != null) {
				writer.close();
			}
		}

	}
	
	public  boolean createDir(String destDirName) {  
        File dir = new File(destDirName);  
        if (dir.exists()) {   
            return true;  
        }  
        if (!destDirName.endsWith(File.separator)) {  
            destDirName = destDirName + File.separator;  
        }  
        //フォルダー作成  
        if (dir.mkdirs()) {  
            return true;  
        } else {  
            return false;  
        }  
    }  
	protected abstract void buildDocument(
			List<?> documentDataList, HttpServletRequest request) throws Exception;

}

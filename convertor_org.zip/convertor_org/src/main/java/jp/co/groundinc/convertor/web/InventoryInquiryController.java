package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.InventoryInquiry;
import jp.co.groundinc.convertor.domain.InventoryInquiryCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.InventoryInquiryService;
import jp.co.groundinc.convertor.web.form.InventoryInquiryForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class InventoryInquiryController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	InventoryInquiryService inventoryInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("inventoryInquiryForm")
	public InventoryInquiryForm inventoryInquiryForm() {
		logger.info("--- InventoryInquiryController.inventoryInquiryForm() start ---");
		return new InventoryInquiryForm();
	}
	
	@ModelAttribute("ppsNo")
	public List<Translate> ppsNo() {
		logger.info("--- InventoryInquiryController.ppsNo() start ---");
		return commonService.getTranslateList("PpsNo");
	}

	@RequestMapping("/inventory_inquiry")
	public ModelAndView viewPut(ModelAndView modelView) throws ParseException {
		logger.info("--- InventoryInquiryController.inventoryInquiry() start ---");
		String operationDate = commonService.getOperationDate();
		String start = operationDate + "T00:00";
		String end = operationDate + "T23:59";
		InventoryInquiryForm form = new InventoryInquiryForm();
		form.setOperatedDateStart(start);
		form.setOperatedDateEnd(end);
		modelView.addObject("inventoryInquiryForm", form);
		return modelView;
	}

	@RequestMapping(value = "/inventory_inquiry", params = "action=back")
	public String InventoryInquiryBack(HttpServletRequest request, Model model) {
		logger.info("--- InventoryInquiryBack() start ---");
		return "stock_menu";
	}
	
	@RequestMapping(value = "/inventory_inquiry", params = "action=clear")
	public String inventoryInquiryClear(HttpServletRequest request, Model model) throws ParseException {
		logger.info("--- inventoryInquiryClear() start ---");
		String operationDate = commonService.getOperationDate();
		String start = operationDate + "T00:00";
		String end = operationDate + "T23:59";
		InventoryInquiryForm form = new InventoryInquiryForm();
		form.setOperatedDateStart(start);
		form.setOperatedDateEnd(end);
		model.addAttribute("inventoryInquiryForm", form);
		return "inventory_inquiry";
	}

	@RequestMapping(value = "/inventory_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("inventoryInquiryForm") InventoryInquiryForm inventoryInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- search() start ---");
		
		int flag = 1;
		modelView.addObject("flag", flag);
		modelView.setViewName("/inventory_inquiry");

		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String operatedDateStart = inventoryInquiryForm.getOperatedDateStart();
		String operatedDateEnd = inventoryInquiryForm.getOperatedDateEnd();
		String ppsId = inventoryInquiryForm.getPpsId();
		String ppsName = inventoryInquiryForm.getPpsName();
		String location = inventoryInquiryForm.getLocation();
		String sku = inventoryInquiryForm.getSku();
		String skuName = inventoryInquiryForm.getSkuName();
		String keyId = inventoryInquiryForm.getKeyId();
		String operationKindCode = inventoryInquiryForm.getOperationKindCode();
		String operationKindName = inventoryInquiryForm.getOperationKindName();
		String userCode = inventoryInquiryForm.getUserCode();
		String operatedTime = inventoryInquiryForm.getOperatedTime();
		String qty = inventoryInquiryForm.getQty();
		String msuId = inventoryInquiryForm.getMsuId();
		String msuSide = inventoryInquiryForm.getMsuSide();
		String msuStep = inventoryInquiryForm.getMsuStep();
		String msuSlot = inventoryInquiryForm.getMsuSlot();
		String Put = inventoryInquiryForm.getPut();
		String Pick = inventoryInquiryForm.getPick();
		String ManualPick = inventoryInquiryForm.getManualPick();
		String ManualPut = inventoryInquiryForm.getManualPut();
		String Audit = inventoryInquiryForm.getAudit();
		String StockAdjust = inventoryInquiryForm.getStockAdjust();
		String PickExceptions  = inventoryInquiryForm.getPickExceptions();
		String AuditExceptions = inventoryInquiryForm.getAuditExceptions();
		
		
		InventoryInquiry inventoryInquiry = new InventoryInquiry();
		String  operatedDateTimeStart = "";
		String operatedDateTimeEnd = "";
		
		if (!StringUtils.isEmpty(operatedDateStart)) {
			String[] operatedDateStartTimeList = operatedDateStart.split("T");
			operatedDateStart = operatedDateStartTimeList[0];
			operatedDateTimeStart = operatedDateStartTimeList[1];
		}
		if (!StringUtils.isEmpty(operatedDateEnd)) {
			String[] operatedDateEndTimeList = operatedDateEnd.split("T");
			operatedDateEnd = operatedDateEndTimeList[0];
			operatedDateTimeEnd = operatedDateEndTimeList[1];

		}
		
		if (!StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {

			 if (CommonUtility.compareDateTimeStartafterEnd(operatedDateStart+" "+operatedDateTimeStart, operatedDateEnd+" "+operatedDateTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("inventoryInquiry.operatedDate.Datecomparison.message",
						null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
				inventoryInquiry.setOperatedDateStart(operatedDateStart);
				inventoryInquiry.setOperatedTimeStart(operatedDateTimeStart);
				inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
				inventoryInquiry.setOperatedTimeEnd(operatedDateTimeEnd);
		 } else if (!StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateStart()) 
					&& StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateEnd())) {
			 
				inventoryInquiry.setOperatedDateStart(operatedDateStart);
				inventoryInquiry.setOperatedTimeStart(operatedDateTimeStart);
				inventoryInquiry.setOperatedDateEnd(operatedDateStart);
				inventoryInquiry.setOperatedTimeEnd("23:59");
		 }else if (StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateStart()) 
					&& !StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateEnd())) {
			    inventoryInquiry.setOperatedDateStart(operatedDateEnd);
				inventoryInquiry.setOperatedTimeStart("00:00");
				inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
				inventoryInquiry.setOperatedTimeEnd(operatedDateTimeEnd);
		 }else{
			    inventoryInquiry.setOperatedDateStart(null);
				inventoryInquiry.setOperatedTimeStart(null);
				inventoryInquiry.setOperatedDateEnd(null);
				inventoryInquiry.setOperatedTimeEnd(null);
		 }
	     inventoryInquiry.setKeyId(keyId);
		 inventoryInquiry.setLocation(location);
		 inventoryInquiry.setSku(sku);
		 inventoryInquiry.setSkuName(skuName);
		 inventoryInquiry.setOperationKindCode(operationKindCode);
		 inventoryInquiry.setUserCode(userCode);
		 inventoryInquiry.setMsuSlot(msuSlot);
		 inventoryInquiry.setMsuSide(msuSide);
		 inventoryInquiry.setMsuStep(msuStep);
         inventoryInquiry.setMsuId(msuId);
		 inventoryInquiry.setPpsName(ppsName);
		 inventoryInquiryForm.setMsuSlot(msuSlot);
		 inventoryInquiryForm.setMsuId(msuId);
		 inventoryInquiryForm.setMsuStep(msuStep);
		 inventoryInquiryForm.setMsuSide(msuSide);
		 inventoryInquiryForm.setAudit(Audit);
		 inventoryInquiryForm.setPick(Pick);
		 inventoryInquiryForm.setPut(Put);
		 inventoryInquiryForm.setManualPick(ManualPick);
		 inventoryInquiryForm.setManualPut(ManualPut);
		 inventoryInquiryForm.setStockAdjust(StockAdjust);
		 inventoryInquiryForm.setPickExceptions(PickExceptions);
		 inventoryInquiryForm.setAuditExceptions(AuditExceptions);
		 inventoryInquiry.setOperatedDateTime(operatedTime);
		 inventoryInquiry.setPpsId(ppsId);
		 inventoryInquiry.setOperationKindName(operationKindName);
		 inventoryInquiry.setQty(qty);
		 inventoryInquiry.setAudit(Audit);
		 inventoryInquiry.setPick(Pick);
		 inventoryInquiry.setPut(Put);
		 inventoryInquiry.setManualPut(ManualPut);
		 inventoryInquiry.setManualPick(ManualPick);
		 inventoryInquiry.setStockAdjust(StockAdjust);
		 inventoryInquiry.setPickExceptions(PickExceptions);
		 inventoryInquiry.setAuditExceptions(AuditExceptions);
		
		if (StringUtils.isEmpty(inventoryInquiry.getPut()) 
				&& StringUtils.isEmpty(inventoryInquiry.getPick()) 
				&& StringUtils.isEmpty(inventoryInquiry.getAudit()) 
				&& StringUtils.isEmpty(inventoryInquiry.getManualPut())
				&& StringUtils.isEmpty(inventoryInquiry.getManualPick())
				&& StringUtils.isEmpty(inventoryInquiry.getStockAdjust())
				&& StringUtils.isEmpty(inventoryInquiry.getPickExceptions())
				&& StringUtils.isEmpty(inventoryInquiry.getAuditExceptions())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationKind = messageSource.getMessage("inventoryInquiry.search.checkBox.message", null, Locale.JAPAN);
				modelView.addObject("operationKind", operationKind);
				
				return modelView;
	    }
		
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			    String str = inventoryInquiry.getMsuId() +"."+ inventoryInquiry.getMsuSide() +"."+ inventoryInquiry.getMsuStep() +"."+ inventoryInquiry.getMsuSlot();
			    inventoryInquiry.setLocation(str);
	    }
		
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			    String str = inventoryInquiry.getMsuId();
			    inventoryInquiry.setLocation(str);
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			    String str = inventoryInquiry.getMsuId()+"."+ inventoryInquiry.getMsuSide();
			    inventoryInquiry.setLocation(str);
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			    String str = inventoryInquiry.getMsuId()+"."+ inventoryInquiry.getMsuSide() +"."+ inventoryInquiry.getMsuStep();
			    inventoryInquiry.setLocation(str);
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = inventoryInquiryService.selectCount(inventoryInquiry);
		if(count<=countManual){
				String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
		}
		
		List<InventoryInquiry> inventoryList = inventoryInquiryService.selectInventoryInquiry(inventoryInquiry);
		
		if (CollectionUtils.isEmpty(inventoryList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
		    }

		for (int i = 0; i < inventoryList.size(); i++) {
			if (!StringUtils.isEmpty(inventoryList.get(i).getOperatedDate())
					&& !StringUtils.isEmpty(inventoryList.get(i).getOperatedTime())) {
				String str = inventoryList.get(i).getOperatedDate() + inventoryList.get(i).getOperatedTime();
				String newstr = CommonUtility.getDateTime(str);
				inventoryList.get(i).setOperatedDateTime(newstr);
			}
	    }
				modelView.addObject("inventoryList", inventoryList);
				return modelView;
	}
	
	@RequestMapping(value = "/inventory_inquiry", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("inventoryInquiryForm") InventoryInquiryForm inventoryInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- AuditInquiryController.download() start ---");
				int flag = 1;
				modelView.addObject("flag", flag);
				modelView.setViewName("/inventory_inquiry");
				String operatedDateStart = inventoryInquiryForm.getOperatedDateStart();
				String operatedDateEnd = inventoryInquiryForm.getOperatedDateEnd();
				String operationKindCode = inventoryInquiryForm.getOperationKindCode();
				String ppsId = inventoryInquiryForm.getPpsId();
				String location = inventoryInquiryForm.getLocation();
				String sku = inventoryInquiryForm.getSku();
				String keyId = inventoryInquiryForm.getKeyId();
				String userCode = inventoryInquiryForm.getUserCode();
				String msuId = inventoryInquiryForm.getMsuId();
				String msuSide = inventoryInquiryForm.getMsuSide();
				String msuStep = inventoryInquiryForm.getMsuStep();
				String msuSlot = inventoryInquiryForm.getMsuSlot();
				String Put = inventoryInquiryForm.getPut();
				String Pick = inventoryInquiryForm.getPick();
				String ManualPick = inventoryInquiryForm.getManualPick();
				String ManualPut = inventoryInquiryForm.getManualPut();
				String Audit = inventoryInquiryForm.getAudit();
				String StockAdjust = inventoryInquiryForm.getStockAdjust();
				String PickExceptions  = inventoryInquiryForm.getPickExceptions();
				String AuditExceptions = inventoryInquiryForm.getAuditExceptions();
		
				InventoryInquiry inventoryInquiry = new InventoryInquiry();
				String  operatedDateTimeStart = "";
				String operatedDateTimeEnd = "";
		
		if (!StringUtils.isEmpty(operatedDateStart)) {
				String[] operatedDateStartTimeList = operatedDateStart.split("T");
				operatedDateStart = operatedDateStartTimeList[0];
				operatedDateTimeStart = operatedDateStartTimeList[1];
		}
		if (!StringUtils.isEmpty(operatedDateEnd)) {
				String[] operatedDateEndTimeList = operatedDateEnd.split("T");
	
				operatedDateEnd = operatedDateEndTimeList[0];
				operatedDateTimeEnd = operatedDateEndTimeList[1];
		}
		if (!StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {

			 if (CommonUtility.compareDateTimeStartafterEnd(operatedDateStart+" "+operatedDateTimeStart, operatedDateEnd+" "+operatedDateTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("inventoryInquiry.operatedDate.Datecomparison.message",
						null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
				inventoryInquiry.setOperatedDateStart(operatedDateStart);
				inventoryInquiry.setOperatedTimeStart(operatedDateTimeStart);
				inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
				inventoryInquiry.setOperatedTimeEnd(operatedDateTimeEnd);
		 } else if (!StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateStart()) 
					&& StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateEnd())) {
				inventoryInquiry.setOperatedDateStart(operatedDateStart);
				inventoryInquiry.setOperatedTimeStart(operatedDateTimeStart);
				inventoryInquiry.setOperatedDateEnd(operatedDateStart);
				inventoryInquiry.setOperatedTimeEnd("23:59");
				operatedDateEnd = operatedDateStart;
				operatedDateTimeEnd = "23:59";
			 
		 }else if (StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateStart()) 
					&& !StringUtils.isEmpty(inventoryInquiryForm.getOperatedDateEnd())) {
			    inventoryInquiry.setOperatedDateStart(operatedDateEnd);
				inventoryInquiry.setOperatedTimeStart("00:00");
				inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
				inventoryInquiry.setOperatedTimeEnd(operatedDateTimeEnd);
				operatedDateStart = operatedDateEnd;
				operatedDateTimeStart = "00:00";
		 }else{ 
				inventoryInquiry.setOperatedDateStart(null);
				inventoryInquiry.setOperatedTimeStart(null);
				inventoryInquiry.setOperatedDateEnd(null);
				inventoryInquiry.setOperatedTimeEnd(null);
		 }
			
		inventoryInquiry.setKeyId(keyId);
		inventoryInquiry.setLocation(location);
		inventoryInquiry.setSku(sku);
		inventoryInquiry.setPpsId(ppsId);
		inventoryInquiry.setOperationKindCode(operationKindCode);
		inventoryInquiry.setUserCode(userCode);
		inventoryInquiry.setMsuSlot(msuSlot);
		inventoryInquiry.setMsuSide(msuSide);
		inventoryInquiry.setMsuStep(msuStep);
		inventoryInquiry.setMsuId(msuId);
		inventoryInquiry.setAudit(Audit);
		inventoryInquiry.setPick(Pick);
		inventoryInquiry.setPut(Put);
		inventoryInquiry.setManualPut(ManualPut);
		inventoryInquiry.setManualPick(ManualPick);
		inventoryInquiry.setStockAdjust(StockAdjust);
		inventoryInquiry.setPickExceptions(PickExceptions);
		inventoryInquiry.setAuditExceptions(AuditExceptions);
		
		if (StringUtils.isEmpty(inventoryInquiry.getPut()) 
				&& StringUtils.isEmpty(inventoryInquiry.getPick()) 
				&& StringUtils.isEmpty(inventoryInquiry.getAudit()) 
				&& StringUtils.isEmpty(inventoryInquiry.getManualPut())
				&& StringUtils.isEmpty(inventoryInquiry.getManualPick())
				&& StringUtils.isEmpty(inventoryInquiry.getStockAdjust())
				&& StringUtils.isEmpty(inventoryInquiry.getPickExceptions())
				&& StringUtils.isEmpty(inventoryInquiry.getAuditExceptions())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationKind = messageSource.getMessage("inventoryInquiry.search.checkBox.message", null, Locale.JAPAN);
				modelView.addObject("operationKind", operationKind);
				
			return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String str = inventoryInquiry.getMsuId() +"."+ inventoryInquiry.getMsuSide() +"."+ inventoryInquiry.getMsuStep() +"."+ inventoryInquiry.getMsuSlot();
				location = str;
	    }
		
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String str = inventoryInquiry.getMsuId();
				location = str;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String str = inventoryInquiry.getMsuId()+"."+ inventoryInquiry.getMsuSide();
				location = str;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String str = inventoryInquiry.getMsuId()+"."+ inventoryInquiry.getMsuSide() +"."+ inventoryInquiry.getMsuStep();
				location = str;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.msuId.empty.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
	    }
		if (!StringUtils.isEmpty(inventoryInquiry.getMsuId()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuSide()) 
				&& StringUtils.isEmpty(inventoryInquiry.getMsuStep()) 
				&& !StringUtils.isEmpty(inventoryInquiry.getMsuSlot())){
			
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String slot = messageSource.getMessage("inventoryInquiry.search.location.message", null, Locale.JAPAN);
				modelView.addObject("slot", slot);
				return modelView;
		}

		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual = inventoryInquiryService.selectCount(inventoryInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
	
		List<InventoryInquiryCsv> inventoryInquiryCsvList = 
				inventoryInquiryService.findInventoryInquiryCsv(
						operatedDateStart,operatedDateEnd,operatedDateTimeStart,operatedDateTimeEnd,sku,keyId,location,
						userCode,ppsId,Put,Pick,ManualPick,ManualPut,Audit,StockAdjust,operationKindCode,PickExceptions,AuditExceptions);
		
		if (CollectionUtils.isEmpty(inventoryInquiryCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/inventory_inquiry");
			return modelView;
		}
		
			modelView.addObject("inventoryInquiryCsvList", inventoryInquiryCsvList);
			modelView.setViewName("InventoryInquiryCsvView");
		    return modelView;
	}

	@RequestMapping(value = "/inventory_inquiry/skuName{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getSkuName(@PathVariable String skuCode) {
		logger.info("--- InventoryInquiryController.getSkuName() start ---");
		String skuName = "";
		if (!StringUtils.isEmpty(skuCode)) {
			skuName = commonService.getSkuName(skuCode);
		}
		return skuName;
	}

	@RequestMapping(value = "/inventory_inquiry/userName/{userCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getUserName(@PathVariable String userCode) {
		logger.info("--- InventoryInquiryController.getUserName() start ---");
		String userName = "";
		if (!StringUtils.isEmpty(userCode)) {
			userName = commonService.getUserName(userCode);
		}
		return userName;
	}
}

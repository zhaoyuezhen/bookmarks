package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class AuthorityMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	private String menuTabName;
	private String menuButtonCode;
	private String menuButtonName;
	private String authorityKind;
	private String authorityKindName;
	private String permissionFlag;
	private String updateUser;
	private String updateDate;
	private String updateTime;
	private String authorityKinds;
	
	public String getMenuTabName() {
		return menuTabName;
	}
	public String getMenuButtonCode() {
		return menuButtonCode;
	}
	public String getMenuButtonName() {
		return menuButtonName;
	}
	public String getAuthorityKind() {
		return authorityKind;
	}
	public String getAuthorityKindName() {
		return authorityKindName;
	}
	public String getPermissionFlag() {
		return permissionFlag;
	}
	public void setMenuTabName(String menuTabName) {
		this.menuTabName = menuTabName;
	}
	public void setMenuButtonCode(String menuButtonCode) {
		this.menuButtonCode = menuButtonCode;
	}
	public void setMenuButtonName(String menuButtonName) {
		this.menuButtonName = menuButtonName;
	}
	public void setAuthorityKind(String authorityKind) {
		this.authorityKind = authorityKind;
	}
	public void setAuthorityKindName(String authorityKindName) {
		this.authorityKindName = authorityKindName;
	}
	public void setPermissionFlag(String permissionFlag) {
		this.permissionFlag = permissionFlag;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getAuthorityKinds() {
		return authorityKinds;
	}
	public void setAuthorityKinds(String authorityKinds) {
		this.authorityKinds = authorityKinds;
	}
}

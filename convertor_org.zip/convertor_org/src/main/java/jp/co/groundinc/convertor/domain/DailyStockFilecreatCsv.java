package jp.co.groundinc.convertor.domain;

public class DailyStockFilecreatCsv {
	
	private String sku;
	private String skuKind;
	private String stockQty;
	private String area;
    private String csvExportDate;
	private String csvExportTime;
	
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getStockQty() {
		return stockQty;
	}
	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
}

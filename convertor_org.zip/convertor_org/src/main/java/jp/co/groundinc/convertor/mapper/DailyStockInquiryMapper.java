package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.DailyStockFileInquiry;

@Mapper
public interface DailyStockInquiryMapper {

	List<DailyStockFileInquiry> findAll(DailyStockFileInquiry dailyStockFileInquiry);
	int selectCountt(DailyStockFileInquiry dailyStockFileInquiry);
}

package jp.co.groundinc.convertor.web.view;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import jp.co.groundinc.convertor.CommonUtility;

public class InventoryInquiryCsvView extends AbstractCsvView {
	@Override
	public void buildCsvDocument(Map<String, Object> model, HttpServletRequest request, PrintWriter writer)
			throws Exception {
		@SuppressWarnings("unchecked")
		ArrayList<Object> inventoryInquiryCsvList = (ArrayList<Object>)model.get("inventoryInquiryCsvList");

		CommonUtility.WriteCsvFile(writer, inventoryInquiryCsvList, getCsvHeaderCode(), getCsvHeaderName());
	}

}

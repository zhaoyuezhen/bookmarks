package jp.co.groundinc.convertor.web;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.ExceptionsInquiry;
import jp.co.groundinc.convertor.domain.ExceptionsInquiryDetail;
import jp.co.groundinc.convertor.service.ExceptionsInquiryService;
import jp.co.groundinc.convertor.web.form.ExceptionsInquiryForm;

@Controller
@EnableAutoConfiguration
@SessionAttributes
public class ExceptionsInquiryDetailController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ExceptionsInquiryService exceptionsInquiryService;
	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@RequestMapping("/exceptionsInquiryDetail")
	public ModelAndView expressPick(@RequestParam("sku") String sku,@RequestParam("exceptionDate") String exceptionDate, ModelAndView modelView, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("--- ExceptionsInquiryDetailController.expressPick() start ---");
		ExceptionsInquiryDetail exceptionsDetail = new ExceptionsInquiryDetail();
		exceptionsDetail.setExceptionDate(exceptionDate);
		exceptionsDetail.setSku(sku);
		List<ExceptionsInquiryDetail> exceptionsInquiryDetail = exceptionsInquiryService.selectExceptionsInquiryDetail(exceptionsDetail);
		for(int i=0;i<exceptionsInquiryDetail.size();i++){
			if (!StringUtils.isEmpty(exceptionsInquiryDetail.get(i).getExceptionTimestamp())) {
				String str = exceptionsInquiryDetail.get(i).getExceptionTimestamp();
				String newstr = CommonUtility.getDateTime(str);
				exceptionsInquiryDetail.get(i).setExceptionTimestamp(newstr);
			}
		}
		modelView.setViewName("/exceptions_inquiry_detail");
		modelView.addObject("exceptionsInquiryDetail", exceptionsInquiryDetail);
		return modelView;
	}
	
	@RequestMapping(value = "/exceptionsInquiryDetail", params = "action=back")
	public ModelAndView exceptionsInquiryBack(HttpServletRequest request,ModelAndView modelView) throws ParseException {
		logger.info("--- search() start ---");
		modelView.setViewName("/exceptions_inquiry");
		ExceptionsInquiryForm exceptionsInquiryForm = (ExceptionsInquiryForm)request.getSession().getAttribute("exceptionsInquiryForm");
		String exceptionDateStart = exceptionsInquiryForm.getExceptionDateStart();
		String exceptionDateEnd = exceptionsInquiryForm.getExceptionDateEnd();
		modelView.addObject("exceptionDateStart", exceptionDateStart);
		modelView.addObject("exceptionDateEnd", exceptionDateEnd);
		String sku = exceptionsInquiryForm.getSku();
		String skuName = exceptionsInquiryForm.getSkuName();
		ExceptionsInquiry exceptionsInquiry = new ExceptionsInquiry();
		exceptionsInquiry.setExceptionDateStart(exceptionDateStart);
		exceptionsInquiry.setExceptionDateEnd(exceptionDateEnd);
		exceptionsInquiry.setSku(sku);
		exceptionsInquiry.setSkuName(skuName);
		if (!StringUtils.isEmpty(exceptionsInquiry.getExceptionDateStart()) && StringUtils.isEmpty(exceptionsInquiry.getExceptionDateEnd())) {
			
			String exceptiondateStart = exceptionsInquiry.getExceptionDateStart();
			
			exceptionsInquiry.setExceptionDateEnd(exceptiondateStart);
		}
		List<ExceptionsInquiry> exceptionsInquiryList = exceptionsInquiryService.selectExceptionsInquiry(exceptionsInquiry);
		modelView.addObject("exceptionsInquiryList", exceptionsInquiryList);
		modelView.addObject("exceptionsInquiryForm", exceptionsInquiryForm);
		return modelView;
		

	}
}

package jp.co.groundinc.convertor.web.form;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class StowInquiryForm  implements Serializable{
	private static final long serialVersionUID = 1L;

	/**データ受信Start日*/
	@NotEmpty(message = "{stowInquiry.dataReceivedDateStart.empty.message}")
	private String dataReceivedDateStart;
	
	/**データ受信End日*/
	
	private String dataReceivedDateEnd;
	
	@NotEmpty(message = "{stowInquiry.dataReceivedDateStart.empty.message}")
	private String dataReceivedTimeStart;

	private String dataReceivedTimeEnd;
	
	/**作業状態*/
	private String workingStatus;
	
	/**作業実績Start日*/
	private String operatedDateStart;
	
	/**作業実績End日*/
	private String operatedDateEnd;
	
	private String operatedTimeStart;

	private String operatedTimeEnd;
	
	/**ステーション*/
	private String ppsId;
	
	private String ppsBinId;
	
	/**コンテナID*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{stowInquiry.container.Halfangle.message}")
	private String containerId;
	
	/**伝票番号*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{stowInquiry.ticket.Halfangle.message}")
	private String expectedPutId;
	
	/**商品コード*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{stowInquiry.product.Halfangle.message}")
	private String sku;
	
	/**商品名*/
	private String skuName;
	
	/** イレギュラーフラグ 予実差異 */
	private String irregularKindName;
	
	private String irregularKind;
	
	/** 予定数  */
	private String expectedQty;
	
	/** 実績数  */
	private String resultQty;
	
    private String putKind;
	
	private String putKindName;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPpsBinId() {
		return ppsBinId;
	}

	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}

	public String getPutKind() {
		return putKind;
	}

	public void setPutKind(String putKind) {
		this.putKind = putKind;
	}

	public String getPutKindName() {
		return putKindName;
	}

	public void setPutKindName(String putKindName) {
		this.putKindName = putKindName;
	}

	
	public String getExpectedQty() {
		return expectedQty;
	}

	public void setExpectedQty(String expectedQty) {
		this.expectedQty = expectedQty;
	}

	public String getResultQty() {
		return resultQty;
	}

	public void setResultQty(String resultQty) {
		this.resultQty = resultQty;
	}

	public String getDataReceivedDateStart() {
		return dataReceivedDateStart;
	}

	public void setDataReceivedDateStart(String dataReceivedDateStart) {
		this.dataReceivedDateStart = dataReceivedDateStart;
	}

	public String getDataReceivedDateEnd() {
		return dataReceivedDateEnd;
	}

	public void setDataReceivedDateEnd(String dataReceivedDateEnd) {
		this.dataReceivedDateEnd = dataReceivedDateEnd;
	}
	public String getDataReceivedTimeStart() {
		return dataReceivedTimeStart;
	}

	public void setDataReceivedTimeStart(String dataReceivedTimeStart) {
		this.dataReceivedTimeStart = dataReceivedTimeStart;
	}

	public String getDataReceivedTimeEnd() {
		return dataReceivedTimeEnd;
	}

	public void setDataReceivedTimeEnd(String dataReceivedTimeEnd) {
		this.dataReceivedTimeEnd = dataReceivedTimeEnd;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}

	public String getOperatedDateStart() {
		return operatedDateStart;
	}

	public void setOperatedDateStart(String operatedDateStart) {
		this.operatedDateStart = operatedDateStart;
	}

	public String getOperatedDateEnd() {
		return operatedDateEnd;
	}

	public void setOperatedDateEnd(String operatedDateEnd) {
		this.operatedDateEnd = operatedDateEnd;
	}
	public String getOperatedTimeStart() {
		return operatedTimeStart;
	}

	public void setOperatedTimeStart(String operatedTimeStart) {
		this.operatedTimeStart = operatedTimeStart;
	}

	public String getOperatedTimeEnd() {
		return operatedTimeEnd;
	}

	public void setOperatedTimeEnd(String operatedTimeEnd) {
		this.operatedTimeEnd = operatedTimeEnd;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getExpectedPutId() {
		return expectedPutId;
	}

	public void setExpectedPutId(String expectedPutId) {
		this.expectedPutId = expectedPutId;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

}

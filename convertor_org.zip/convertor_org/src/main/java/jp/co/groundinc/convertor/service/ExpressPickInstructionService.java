package jp.co.groundinc.convertor.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import jp.co.groundinc.convertor.domain.ExpressPickInstruction;
import jp.co.groundinc.convertor.mapper.ExpressPickInstructionMapper;

@Service
@EnableAutoConfiguration
public class ExpressPickInstructionService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ExpressPickInstructionMapper expressPickInstructionMapper;

	@Autowired
	private OAuth2RestTemplate restTemplate;

	@Value("${webapi.service-request.url}")
	private String apiUrl;
	
	public List<ExpressPickInstruction> findExpressPickInstruction(ExpressPickInstruction expressPickInstruction) {
		logger.info("--- ExpressPickInstructionService.findExpressPickInstruction() start ---");

		List<ExpressPickInstruction> expressPickInstructionList = expressPickInstructionMapper.findExpressPickInstruction(expressPickInstruction);
		return expressPickInstructionList;
	}
	
	public int selectCountt(ExpressPickInstruction expressPickInstruction) {
		logger.info("--- ExpressPickInstructionService.selectCountt() start ---");
		
		int count = expressPickInstructionMapper.selectCountt(expressPickInstruction);
		return count;

	}

	public boolean registerPickOrder(String orderId) {
		boolean result = true;

		try {
			String url = apiUrl + "/cancel/{serviceRequestId}";
			logger.info("--- ExpressPickInstructionService.registerPickOrder() Call webapi start(" + orderId + ") ---");
			restTemplate.delete(url, orderId);
			logger.info("--- ExpressPickInstructionService.registerPickOrder() Call webapi end ---");
		} catch(RestClientException e) {
			logger.error("--- ExpressPickInstructionService.registerPickOrder()" + e.getMessage());
			result = false;
		}
		
		return result;
	}
	
	public  List<ExpressPickInstruction> findOrderId(String orderId){
		logger.info("--- ExpressPickInstructionService.findOrderId() start ---");
		List<ExpressPickInstruction> expressList = expressPickInstructionMapper.selectOrderId(orderId);
		return expressList;
	}
	
	public int insertOrderInterface(ExpressPickInstruction expressPickInstruction) {
		logger.info("--- ExpressPickInstructionService.insertOrderInterface() start ---");
		 int count  = expressPickInstructionMapper.insertOrderInterface(expressPickInstruction);
		 return count;
	}
	
	public int selectProductCount(ExpressPickInstruction expressPickInstruction) {
		logger.info("--- ExpressPickInstructionService.selectProductCount() start ---");
		
		int count = expressPickInstructionMapper.selectProductCount(expressPickInstruction);
		return count;
	}
}

package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.PickProgress;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.PickProgressService;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class PickProgressController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	PickProgressService pickService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("expecteddatestart")
	public String dataReceivedDate() throws ParseException {
		logger.info("--- PickProgressController.dataReceivedDate() start ---");
		String newExpecteddatestart =null;
		String expecteddatestart = commonService.getOperationDate();
		if(!StringUtils.isEmpty(expecteddatestart)){
			newExpecteddatestart = this.DateFomat(expecteddatestart);
		}
		 
		return newExpecteddatestart;
	}

	@ModelAttribute("expecteddateend")
	public String nextdataReceivedDate() throws ParseException {
		logger.info("--- PickProgressController.nextdataReceivedDate() start ---");
		String newExpecteddateend =null;
		String expecteddateend = commonService.getOperationDate();
		if(!StringUtils.isEmpty(expecteddateend)){
			newExpecteddateend = this.DateFomat(expecteddateend);
		}
		return newExpecteddateend;
	}
	
	@ModelAttribute("orderKind")
	public List<Translate> orderKind() {
		logger.info("--- PickInquiryController.orderKind() start ---");
		return commonService.getTranslateList("OrderKind");
	}

	@RequestMapping(value = "/pick_progress")
	public ModelAndView pickProgress(ModelAndView modelView) throws ParseException {
		logger.info("--- PickProgressController.pick() start ---");
		PickProgress pickProgress = new PickProgress();
       String expecteddatestart = commonService.getOperationDate(); 
       String expecteddateend = commonService.getOperationDate();
       String newExpecteddatestart = this.DateFomat(expecteddatestart);
       String newExpecteddateend = this.DateFomat(expecteddateend);
       List<Translate> List  = commonService.getTranslateList("OrderKind");
       Translate translate  = List.get(3);
       pickProgress.setExpecteddatestart(newExpecteddatestart);
       pickProgress.setExpecteddateend(newExpecteddateend);
       pickProgress.setOrderKind(translate.getTranslate_code());
        List<PickProgress> pickListA = pickService.findPickProgressA(pickProgress);
		List<PickProgress> pickListB = pickService.findPickProgressB(pickProgress);
		List<PickProgress> pickList = pickService.findPickProgress(pickProgress);
		List<PickProgress> butlerList = pickService.findButler(pickProgress);
		String defTranslateCode = pickService.getDefTranslateCode();
		modelView.addObject("resultA", pickListA);
		modelView.addObject("resultB", pickListB);
		modelView.addObject("result", pickList);
		modelView.addObject("resultButler", butlerList);
		modelView.addObject("translate_code", defTranslateCode);
		modelView.addObject(pickProgress);
		modelView.setViewName("/pick_progress");
		return modelView;
	}	
	@RequestMapping(value = "/pick_progress", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("pickProgress") PickProgress pickProgress,
			BindingResult result, ModelAndView modelView) {
		logger.info("--- PickProgressController.search() start ---");
		modelView.addObject("expecteddatestart", pickProgress.getExpecteddatestart());
		modelView.addObject("expecteddateend", pickProgress.getExpecteddateend());
		modelView.setViewName("/pick_progress");
		modelView.addObject("translate_code",pickProgress.getOrderKind());
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String expecteddatestart = pickProgress.getExpecteddatestart();
		String expecteddateend = pickProgress.getExpecteddateend();
		if (!StringUtils.isEmpty(expecteddatestart) && !StringUtils.isEmpty(expecteddateend)) {
			if (CommonUtility.comparedateStartafterEnd(expecteddatestart, expecteddateend)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String expecteddate = messageSource.getMessage("Pick.search.dataReceivedDate.Datecomparison.message",
						null, Locale.JAPAN);
				modelView.addObject("expecteddate", expecteddate);
				return modelView;
			}
		}
		if (!StringUtils.isEmpty(expecteddatestart) && StringUtils.isEmpty(expecteddateend)) {
			String dataStart = pickProgress.getExpecteddatestart();
			pickProgress.setExpecteddateend(dataStart);
		}
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=pickService.selectCountt(pickProgress);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<PickProgress> pickListA = pickService.findPickProgressA(pickProgress);
		List<PickProgress> pickListB = pickService.findPickProgressB(pickProgress);
		List<PickProgress> pickList = pickService.findPickProgress(pickProgress);
		List<PickProgress> butlerList = pickService.findButler(pickProgress);
		if (CollectionUtils.isEmpty(pickListA)&&CollectionUtils.isEmpty(pickListB)
				&&CollectionUtils.isEmpty(pickList)&&CollectionUtils.isEmpty(butlerList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		modelView.addObject("resultA", pickListA);
		modelView.addObject("resultB", pickListB);
		modelView.addObject("result", pickList);
		modelView.addObject("resultButler", butlerList);
		return modelView;
	}
	private String DateFomat(String dateTime ) throws ParseException{
		
		SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date date = sdf.parse(dateTime);
		 Calendar calendar = Calendar.getInstance();  
		 calendar.setTime(date);  
		 calendar.add(Calendar.DAY_OF_MONTH, 1);
		 Date tomrow = calendar.getTime();
		 sdf.format(tomrow);
		 String newDateTime = sdf.format(tomrow);
		return newDateTime;
	}
}

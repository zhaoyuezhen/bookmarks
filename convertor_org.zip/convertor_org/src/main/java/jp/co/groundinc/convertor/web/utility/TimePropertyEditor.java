package jp.co.groundinc.convertor.web.utility;

import java.beans.PropertyEditorSupport;

public class TimePropertyEditor extends PropertyEditorSupport {
    @Override
    public void setAsText(String text) {
        if (text == null || text.length() == 0) {
            return;
        }
        setValue(text.replaceAll(":", ""));
    }

    @Override
    public String getAsText() {
        String value = (String) getValue();
        if (value == null || value.trim().length() == 0) {
        	value = "";
        } else {
        	value = value.trim();
        	value = value.substring(0, 2) + ":" + value.substring(2, 4);
        }
        
        return value;
    }
}

package jp.co.groundinc.convertor.web.form;

public class DailyStockFilecreatForm {
  private String sku;

public String getSku() {
	return sku;
}

public void setSku(String sku) {
	this.sku = sku;
}
  
  
}

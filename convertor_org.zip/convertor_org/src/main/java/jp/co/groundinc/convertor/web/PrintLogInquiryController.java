package jp.co.groundinc.convertor.web;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.PrintLogInquiry;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.PrintLogInquiryService;
import jp.co.groundinc.convertor.web.form.PrintLogInquiryForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class PrintLogInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	PrintLogInquiryService printLogInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("printLogInquiryForm")
	public PrintLogInquiryForm printLogInquiryForm() {
		logger.info("--- PrintLogInquiryController.printLogInquiryForm() start ---");
		return new PrintLogInquiryForm();
	}

	@ModelAttribute("operationDateStart")
	public String printDateStart() throws ParseException {
		logger.info("--- PrintLogInquiryController.printDateStart() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("printTimeStart")
	public String printTimeStart() throws ParseException {
		logger.info("--- PrintLogInquiryController.printTimeStart() start ---");
		return commonService.getPrintTimeStart();
	}

	@ModelAttribute("printTimeEnd")
	public String printTimeEnd() throws ParseException {
		logger.info("--- PrintLogInquiryController.printTimeEnd() start ---");
		return commonService.getPrintTimeEnd();
	}

	@ModelAttribute("formName")
	public List<Translate> formName() {
		logger.info("--- PrintLogInquiryController.formName() start ---");
		return commonService.getTranslateList("FormName");
	}

	@ModelAttribute("printer")
	public List<Translate> printer() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@RequestMapping("/print_log_inquiry")
	public String viewPrint(Model model, HttpServletRequest request) {
		logger.info("--- PrintLogInquiryController.printLogInquiry() start ---");
		return "print_log_inquiry";
	}

	@RequestMapping(value = "/print_log_inquiry", params = "action=clear")
	public String printLogInquiryClear(HttpServletRequest request, HttpServletResponse resp, Model model)
			throws ParseException, IOException {
		logger.info("--- printLogInquiryClear() start ---");
		PrintLogInquiryForm form = new PrintLogInquiryForm();
		model.addAttribute("printLogInquiry", form);
		return "print_log_inquiry";

	}

	@RequestMapping(value = "/print_log_inquiry", params = "action=back")
	public String printLogInquiryBack(HttpServletRequest request, Model model) {
		logger.info("--- printLogInquiryBack() start ---");
		return "manage_menu";
	}

	@RequestMapping(value = "/print_log_inquiry", params = "action=search")
	public ModelAndView search(
			@Validated @ModelAttribute("printLogInquiryForm") PrintLogInquiryForm printLogInquiryForm,
			BindingResult result, ModelAndView modelView) throws ParseException {

		logger.info("--- search() start ---");
		modelView.setViewName("/print_log_inquiry");
		String printDateStart = printLogInquiryForm.getPrintDateStart();
		String printTimeStart = printLogInquiryForm.getPrintTimeStart();
		String printTimeEnd = printLogInquiryForm.getPrintTimeEnd();
		
		modelView.addObject("operationDateStart", printDateStart);
		modelView.addObject("printTimeEnd", printTimeEnd);
		modelView.addObject("printTimeStart", printTimeStart);

		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String userCode = printLogInquiryForm.getUserCode();
		String filePath = printLogInquiryForm.getFilePath();
		String formName = printLogInquiryForm.getFormName();
		String printer = printLogInquiryForm.getPrinter();

		if (!StringUtils.isEmpty(printTimeStart) && !StringUtils.isEmpty(printTimeEnd)) {

			if (CommonUtility.compareTimeStartafterEnd(printTimeStart, printTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String printTime = messageSource.getMessage("printLogInquiry.printTime.Datecomparison.message", null,
						Locale.JAPAN);
				modelView.addObject("printTime", printTime);
				return modelView;
			}
		}
		PrintLogInquiry printLogInquiry = new PrintLogInquiry();
		if(!StringUtils.isEmpty(printTimeStart)){
			String newPrintDateStart = this.startTimeFomat(printTimeStart);
			printLogInquiry.setPrintTimeStart(newPrintDateStart);
		}
		if(!StringUtils.isEmpty(printTimeEnd)){
			String newPrintDateEnd = this.EndTimeFomat(printTimeEnd);
			printLogInquiry.setPrintTimeEnd(newPrintDateEnd);
		}
		printLogInquiry.setPrintDateStart(CommonUtility.dateFomat(printDateStart));
		printLogInquiry.setUserCode(userCode);
		printLogInquiry.setFormName(formName);
		printLogInquiry.setFilePath(filePath);		
		printLogInquiry.setPrinter(printer);
		printLogInquiryForm.setPrintDateStart(printDateStart);
		printLogInquiryForm.setPrintTimeStart(printTimeStart);
		printLogInquiryForm.setPrintTimeEnd(printTimeEnd);
		printLogInquiryForm.setFilePath(filePath);
		printLogInquiryForm.setFormName(formName);
		printLogInquiryForm.setUserCode(userCode);
		printLogInquiryForm.setPrinter(printer);
		int count = commonService.selectTableUpperLimitCount();
		int countManual = printLogInquiryService.selectCountt(printLogInquiry);
		if (count <= countManual) {
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<PrintLogInquiry> printLogList = printLogInquiryService.findPrintLog(printLogInquiry);
		if (CollectionUtils.isEmpty(printLogList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		for (int i = 0; i < printLogList.size(); i++) {
			if (!StringUtils.isEmpty(printLogList.get(i).getPrintDate())
					&& !StringUtils.isEmpty(printLogList.get(i).getPrintTime())) {
				String str = printLogList.get(i).getPrintDate() + printLogList.get(i).getPrintTime();
				String newstr = CommonUtility.getDateTime(str);
				printLogList.get(i).setPrintLogDateTime(newstr);
				
				String pathNew = commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint") + printLogList.get(i).getFilePath();
				String fileName = printLogList.get(i).getFilePath();
				printLogList.get(i).setFileName(fileName);
				printLogList.get(i).setFilePath(pathNew);

			}
		}
		modelView.addObject("printLogList", printLogList);
		return modelView;
	}

	private String EndTimeFomat(String printTimeEnd ) throws ParseException{
		String newhour =  printTimeEnd.substring(0,printTimeEnd.lastIndexOf(":"));
		 int i = Integer.parseInt(newhour);
		 String end =null;
		 if(i>9){ 
			 end =  CommonUtility.timeFomat(printTimeEnd)+"00";
		 }
		 else{
			 end = "0"+newhour+printTimeEnd.substring(printTimeEnd.indexOf(":") + 1)+"00";
		 }
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
        java.util.Date dateutil = sdf.parse(end);
        long  sttt = dateutil.getTime()-1;
        Date d = new Date(sttt);
        SimpleDateFormat sdf1 = new SimpleDateFormat("HHmmss");
        String newPrintTimeEnd = sdf1.format(d);
        
		return newPrintTimeEnd;
	}
	
	private String startTimeFomat(String printTimeStart ){
		String newhour =  printTimeStart.substring(0,printTimeStart.lastIndexOf(":"));
		 int i = Integer.parseInt(newhour);
		 String newPrintTimeStart =null;
		 if(i>9){
			 newPrintTimeStart =  CommonUtility.timeFomat(printTimeStart)+"00";
		 }
		 else{
			 newPrintTimeStart = "0"+newhour+printTimeStart.substring(printTimeStart.indexOf(":") + 1)+"00";
		 }
 
		return newPrintTimeStart;
	}
}

package jp.co.groundinc.convertor;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

@Configuration
public class CommonUtility {
	public static Map<String, String> getSysDateTime() {
		HashMap<String, String> sysDateTimeMap = new HashMap<String, String>();

		Date dateTime = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
		String[] sysDateTime = formatter.format(dateTime).split("-");
		sysDateTimeMap.put("DATE", sysDateTime[0]);
		sysDateTimeMap.put("TIME", sysDateTime[1]);

		return sysDateTimeMap;
	}

	public static boolean compareDateTimeStartafterEnd(String startdate, String enddate) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date receiveddateStart = null;
		Date receiveddateEnd = null;
		try {
			receiveddateStart = df.parse(startdate);
			receiveddateEnd = df.parse(enddate);
			if (receiveddateStart.after(receiveddateEnd)) {
				return true;
			}
			return false;
		} catch (ParseException e) {
			return false;
		}
	}
	public static boolean comparedateStartafterEnd(String startdate, String enddate) {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date receiveddateStart = null;
		Date receiveddateEnd = null;
		try {
			receiveddateStart = df.parse(startdate);
			receiveddateEnd = df.parse(enddate);
			if (receiveddateStart.after(receiveddateEnd)) {
				return true;
			}
			return false;
		} catch (ParseException e) {
			return false;
		}

	}
	
	public static boolean compareDateTime(String startdate, String enddate) {
		DateFormat df = new SimpleDateFormat("yyyyMMdd HHmmss");
		Date receiveddateStart = null;
		Date receiveddateEnd = null;
		try {
			receiveddateStart = df.parse(startdate);
			receiveddateEnd = df.parse(enddate);
			if (receiveddateStart.after(receiveddateEnd)) {
				return true;
			}
			return false;
		} catch (ParseException e) {
			return false;
		}
	}
	public static boolean compareDate(String startdate, String enddate) {

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Date receiveddateStart = null;
		Date receiveddateEnd = null;
		try {
			receiveddateStart = df.parse(startdate);
			receiveddateEnd = df.parse(enddate);
			if (receiveddateStart.after(receiveddateEnd)) {
				return true;
			}
			return false;
		} catch (ParseException e) {
			return false;
		}

	}

	public static boolean compareTimeStartafterEnd(String startTime, String endTime) {

		DateFormat df = new SimpleDateFormat("HH:mm");
		Date receivedTimeStart = null;
		Date receivedTimeEnd = null;
		try {
			receivedTimeStart = df.parse(startTime);
			receivedTimeEnd = df.parse(endTime);
			if (receivedTimeStart.after(receivedTimeEnd)) {
				return true;
			}
			return false;
		} catch (ParseException e) {
			return false;
		}

	}
	
	public static String systemDate(){
		Date dt = new Date();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String temp_str= df.format(dt);
		return temp_str;
	}
	
	public static String getDateTime(String oldDateTime) {
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		String newDateTime = oldDateTime.replaceAll(reg, "$1/$2/$3 $4:$5:$6");	
		return newDateTime;
	}
	
	public static String getDateTime1(String oldDateTime) {
		String reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
		String newDateTime = oldDateTime.replaceAll(reg, "$1/$2/$3 $4:$5:$6");	
		return newDateTime;
	}
	public static String systemTime(){
		Date dt = new Date();
		DateFormat df = new SimpleDateFormat("hhmmss");
		String temp_str= df.format(dt);
		return temp_str;
	}
	public static String dateFomat(String date) {

		return date.replaceAll("-", "");
	}

	public static String timeFomat(String time) {
	
		return time.replaceAll(":", "");
	}
	
	public static <T> void WriteCsvFile(PrintWriter writer, List<T> rows, 
			String[] csvHeaderCode, String[] csvHeaderName) throws IOException {
		ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);
		csvWriter.writeHeader(csvHeaderName);
		for(Object row : rows){
	        csvWriter.write(row, csvHeaderCode);
	    }
		csvWriter.close();
	}
	
	public static <T> void WriteTsvFile(PrintWriter writer, List<T> rows, 
			String[] csvHeaderCode) throws IOException {
		ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, new CsvPreference.Builder('"', '\t', "\r\n").build());
		//csvWriter.writeHeader(csvHeaderName);
		for(Object row : rows){
	        csvWriter.write(row, csvHeaderCode);
	    }
		csvWriter.close();
	}
	
	public static <T> void WriteTsvFilehead(PrintWriter writer, List<T> rows, 
			String[] csvHeaderCode,String[] csvHeaderName) throws IOException {
		ICsvBeanWriter csvWriter = new CsvBeanWriter(writer, new CsvPreference.Builder('"', '\t', "\r\n").build());
		csvWriter.writeHeader(csvHeaderName);
		for(Object row : rows){
	        csvWriter.write(row, csvHeaderCode);
	    }
		csvWriter.close();
	}
	
	public static void createCtlFile(String filePath, String fileName) throws IOException {
		String fileExtension = ".CTL";
		Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
		Files.createFile(path);
	}
	
	public static void saveImageFile(String filePath, String fileName, MultipartFile file) throws IOException {
		String fileExtension = ".jpg";
		Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
		Files.write(path, file.getBytes());
	}
	
	public static byte[] getImageFile(String filePath, String fileName) throws IOException {
		String fileExtension = ".jpg";
		Path path = Paths.get(filePath + File.separator + fileName + fileExtension);
		return Files.readAllBytes(path);
	}
}

package jp.co.groundinc.convertor.domain;

import java.math.BigDecimal;

public class SkuMaster {

	private String sku;
	
	private String skuName;
	
	private String updateUser;

	private String updateDate;
	
	private String updateTime;
	
	private String updateDateTime;
	
	private String stockStatus;
	
	private String stockStatusName;
	
	private String cbm;
	
	private String deletionKind;
	
	private String deletionKindName;
	
	private String checkStatus;
	
	private String checkStatusName;
	
	private String checkFlag;
	
	private String status;
	
	private String skuKind;
	
	/** スキャニングコード*/
	private String scanningCode;

	private String skuImageUrl;
	
	/** 梱包幅*/
	private int skuWidth;
	
	/** 梱包奥行*/
	private int skuDepth;
	
	/** 梱包高さ*/
	private int skuHeight;
	
	/** 重量*/
	private String skuWeight;
	
	private String  logisticsCbm1;
	
	private int logisticsSkuWidth;
	
	private int logisticsSkuDepth;
	
	private int logisticsSkuHeight;
	
	private BigDecimal logisticsSkuWeight;
	
	private BigDecimal logisticsSkuWidtht;
	
	private BigDecimal logisticsSkuDeptht;
	
	private BigDecimal logisticsSkuHeightt;
	
	private double  logisticsSkuWeightd;
	
    private String logisticsSkuName;
	
	private String logisticsSkuKind;
	
	private double logisticsCbm;
	
	private BigDecimal logisticsCbmtt;
	
	private String logisticsScanningCode;
	
	private String logisticsSkuImageUrl;
	/**割れ物*/
	private String fragileFlag;
	/**保管方向*/
	private String stockDirection;
	/**スタック可否*/
	private String stackingFlag;
	/**ネスト可否*/
	private String nestingFlag;
	/**ネスト方向*/
	private String nestingDirection;
	/**ストレージタイプ*/
	private String slotType;
	
	/**最大スタック数*/
	private String maxStacableCount;
	
	/**最大ネスト数*/
	private BigDecimal maxNestingCount;
	/**ネスト増数*/
	private String nestingIncrementCount;
	/**論理削除*/
	private String logicalDeletionFlag;
	
    private String sendStatus;
	
	private String updatedKind;
	
	public BigDecimal getLogisticsSkuWidtht() {
		return logisticsSkuWidtht;
	}
	public void setLogisticsSkuWidtht(BigDecimal logisticsSkuWidtht) {
		this.logisticsSkuWidtht = logisticsSkuWidtht;
	}
	public BigDecimal getLogisticsSkuDeptht() {
		return logisticsSkuDeptht;
	}
	public void setLogisticsSkuDeptht(BigDecimal logisticsSkuDeptht) {
		this.logisticsSkuDeptht = logisticsSkuDeptht;
	}
	public BigDecimal getLogisticsSkuHeightt() {
		return logisticsSkuHeightt;
	}
	public void setLogisticsSkuHeightt(BigDecimal logisticsSkuHeightt) {
		this.logisticsSkuHeightt = logisticsSkuHeightt;
	}
	public double getLogisticsSkuWeightd() {
		return logisticsSkuWeightd;
	}
	public void setLogisticsSkuWeightd(double logisticsSkuWeightd) {
		this.logisticsSkuWeightd = logisticsSkuWeightd;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public String getUpdatedKind() {
		return updatedKind;
	}
	public void setUpdatedKind(String updatedKind) {
		this.updatedKind = updatedKind;
	}
	public String getFragileFlag() {
		return fragileFlag;
	}
	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}
	public String getStockDirection() {
		return stockDirection;
	}
	public void setStockDirection(String stockDirection) {
		this.stockDirection = stockDirection;
	}
	public String getStackingFlag() {
		return stackingFlag;
	}
	public void setStackingFlag(String stackingFlag) {
		this.stackingFlag = stackingFlag;
	}
	public String getNestingFlag() {
		return nestingFlag;
	}
	public void setNestingFlag(String nestingFlag) {
		this.nestingFlag = nestingFlag;
	}
	public String getNestingDirection() {
		return nestingDirection;
	}
	public void setNestingDirection(String nestingDirection) {
		this.nestingDirection = nestingDirection;
	}
	public String getSlotType() {
		return slotType;
	}
	public void setSlotType(String slotType) {
		this.slotType = slotType;
	}
	public String getMaxStacableCount() {
		return maxStacableCount;
	}
	public void setMaxStacableCount(String maxStacableCount) {
		this.maxStacableCount = maxStacableCount;
	}
	public String getLogisticsCbm1() {
		return logisticsCbm1;
	}
	public void setLogisticsCbm1(String logisticsCbm1) {
		this.logisticsCbm1 = logisticsCbm1;
	}
	
	public BigDecimal getMaxNestingCount() {
		return maxNestingCount;
	}
	public void setMaxNestingCount(BigDecimal maxNestingCount) {
		this.maxNestingCount = maxNestingCount;
	}
	public String getNestingIncrementCount() {
		return nestingIncrementCount;
	}
	public void setNestingIncrementCount(String nestingIncrementCount) {
		this.nestingIncrementCount = nestingIncrementCount;
	}
	public String getLogicalDeletionFlag() {
		return logicalDeletionFlag;
	}
	public void setLogicalDeletionFlag(String logicalDeletionFlag) {
		this.logicalDeletionFlag = logicalDeletionFlag;
	}	
	public String getStockStatusName() {
		return stockStatusName;
	}
	public void setStockStatusName(String stockStatusName) {
		this.stockStatusName = stockStatusName;
	}
	public String getDeletionKindName() {
		return deletionKindName;
	}
	public void setDeletionKindName(String deletionKindName) {
		this.deletionKindName = deletionKindName;
	}
	public String getCheckStatusName() {
		return checkStatusName;
	}
	public void setCheckStatusName(String checkStatusName) {
		this.checkStatusName = checkStatusName;
	}
	public String getLogisticsSkuName() {
		return logisticsSkuName;
	}
	public void setLogisticsSkuName(String logisticsSkuName) {
		this.logisticsSkuName = logisticsSkuName;
	}
	public String getLogisticsSkuKind() {
		return logisticsSkuKind;
	}
	public void setLogisticsSkuKind(String logisticsSkuKind) {
		this.logisticsSkuKind = logisticsSkuKind;
	}
	public int getLogisticsSkuWidth() {
		return logisticsSkuWidth;
	}
	public void setLogisticsSkuWidth(int logisticsSkuWidth) {
		this.logisticsSkuWidth = logisticsSkuWidth;
	}
	public int getLogisticsSkuDepth() {
		return logisticsSkuDepth;
	}
	public void setLogisticsSkuDepth(int logisticsSkuDepth) {
		this.logisticsSkuDepth = logisticsSkuDepth;
	}
	public int getLogisticsSkuHeight() {
		return logisticsSkuHeight;
	}
	public void setLogisticsSkuHeight(int logisticsSkuHeight) {
		this.logisticsSkuHeight = logisticsSkuHeight;
	}
	public String getLogisticsScanningCode() {
		return logisticsScanningCode;
	}
	public void setLogisticsScanningCode(String logisticsScanningCode) {
		this.logisticsScanningCode = logisticsScanningCode;
	}
	public String getLogisticsSkuImageUrl() {
		return logisticsSkuImageUrl;
	}
	public void setLogisticsSkuImageUrl(String logisticsSkuImageUrl) {
		this.logisticsSkuImageUrl = logisticsSkuImageUrl;
	}
	
	public BigDecimal getLogisticsSkuWeight() {
		return logisticsSkuWeight;
	}
	public void setLogisticsSkuWeight(BigDecimal logisticsSkuWeight) {
		this.logisticsSkuWeight = logisticsSkuWeight;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSkuImageUrl() {
		return skuImageUrl;
	}
	public void setSkuImageUrl(String skuImageUrl) {
		this.skuImageUrl = skuImageUrl;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCheckFlag() {
		return checkFlag;
	}
	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}
	public String getDeletionKind() {
		return deletionKind;
	}
	public void setDeletionKind(String deletionKind) {
		this.deletionKind = deletionKind;
	}
	public String getCheckStatus() {
		return checkStatus;
	}
	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(String updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public String getStockStatus() {
		return stockStatus;
	}
	public void setStockStatus(String stockStatus) {
		this.stockStatus = stockStatus;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public double getLogisticsCbm() {
		return logisticsCbm;
	}
	public void setLogisticsCbm(double logisticsCbm) {
		this.logisticsCbm = logisticsCbm;
	}
	public int getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(int skuWidth) {
		this.skuWidth = skuWidth;
	}
	public int getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(int skuDepth) {
		this.skuDepth = skuDepth;
	}
	public int getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(int skuHeight) {
		this.skuHeight = skuHeight;
	}
	public String getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(String skuWeight) {
		this.skuWeight = skuWeight;
	}
	
	public BigDecimal getLogisticsCbmtt() {
		return logisticsCbmtt;
	}
	public void setLogisticsCbmtt(BigDecimal logisticsCbmtt) {
		this.logisticsCbmtt = logisticsCbmtt;
	}
}

package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class StockAdjustIndicationForm {
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.productCode.message}")
	private String skuStart;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.productCode.message}")
	private String skuEnd;
	
	@NotNull(message = "{stowInquiry.dataReceivedDateStart.empty.message}")
	private String classification;
	
	private String [] skus;
	
	private String slotCounts;
	
	private String [] locations;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuIdStart;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuSideStart;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuStepStart;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuIdEnd;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuSideEnd;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{InventoriesInstructionForm.message}")
    private String msuStepEnd;
	
	
	public String[] getLocations() {
		return locations;
	}
	public void setLocations(String[] locations) {
		this.locations = locations;
	}
	public String getMsuIdStart() {
		return msuIdStart;
	}
	public void setMsuIdStart(String msuIdStart) {
		this.msuIdStart = msuIdStart;
	}
	public String getMsuSideStart() {
		return msuSideStart;
	}
	public void setMsuSideStart(String msuSideStart) {
		this.msuSideStart = msuSideStart;
	}
	public String getMsuStepStart() {
		return msuStepStart;
	}
	public void setMsuStepStart(String msuStepStart) {
		this.msuStepStart = msuStepStart;
	}
	
	public String getMsuIdEnd() {
		return msuIdEnd;
	}
	public void setMsuIdEnd(String msuIdEnd) {
		this.msuIdEnd = msuIdEnd;
	}
	public String getMsuSideEnd() {
		return msuSideEnd;
	}
	public void setMsuSideEnd(String msuSideEnd) {
		this.msuSideEnd = msuSideEnd;
	}
	public String getMsuStepEnd() {
		return msuStepEnd;
	}
	public void setMsuStepEnd(String msuStepEnd) {
		this.msuStepEnd = msuStepEnd;
	}
	
	public String[] getSkus() {
		return skus;
	}
	public void setSkus(String[] skus) {
		this.skus = skus;
	}

	public String getSlotCounts() {
		return slotCounts;
	}
	public void setSlotCounts(String slotCounts) {
		this.slotCounts = slotCounts;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getSkuStart() {
		return skuStart;
	}
	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}
	public String getSkuEnd() {
		return skuEnd;
	}
	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}
    
}

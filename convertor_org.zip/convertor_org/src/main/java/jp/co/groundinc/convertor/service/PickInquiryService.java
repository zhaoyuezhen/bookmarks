package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.PickInquiry;
import jp.co.groundinc.convertor.domain.PickInquiryCsv;
import jp.co.groundinc.convertor.mapper.PickInquiryMapper;

@Service
@EnableAutoConfiguration
public class PickInquiryService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PickInquiryMapper pickInquiryMapper;
	
	@Autowired
	CommonUtility commonUtility;

	public List<PickInquiry> selectSyukokensakuinfo(PickInquiry pickInquiry) {
		logger.info("--- PickInquiryService.selectSyukokensakuinfo() start ---");
		/*String receiveddateStart = CommonUtility.dateFomat(pickInquiry.getDatareceiveddateStart());
		pickInquiry.setDatareceiveddateStart(receiveddateStart);
		String receiveddateEnd = CommonUtility.dateFomat(pickInquiry.getDatareceiveddateEnd());
		pickInquiry.setDatareceiveddateEnd(receiveddateEnd);

		if (!StringUtils.isEmpty(pickInquiry.getOperateddateStart())) {
			String OperateddateStart = CommonUtility.dateFomat(pickInquiry.getOperateddateStart());
			pickInquiry.setOperateddateStart(OperateddateStart);
		}

		if (!StringUtils.isEmpty(pickInquiry.getOperateddateEnd())) {
			String OperateddateEnd = CommonUtility.dateFomat(pickInquiry.getOperateddateEnd());
			pickInquiry.setOperateddateEnd(OperateddateEnd);
		}
		if (!StringUtils.isEmpty(pickInquiry.getExpecteddateStart())) {
			String expecteddateStart = CommonUtility.dateFomat(pickInquiry.getExpecteddateStart());
			pickInquiry.setExpecteddateStart(expecteddateStart);
		}*/
		if (!StringUtils.isEmpty(pickInquiry.getExpecteddateEnd())) {
			String expected_dateEnd = CommonUtility.dateFomat(pickInquiry.getExpecteddateEnd());
			pickInquiry.setExpecteddateEnd(expected_dateEnd);
		}
		return  pickInquiryMapper.selectSyukoinfo(pickInquiry);
	}
	public int selectCountt(PickInquiry pickInquiry) {
        logger.info("--- PickInquiryService.selectCountt() start ---");
      /*  String receiveddateStart = CommonUtility.dateFomat(pickInquiry.getDatareceiveddateStart());
        pickInquiry.setDatareceiveddateStart(receiveddateStart);
        String receiveddateEnd = CommonUtility.dateFomat(pickInquiry.getDatareceiveddateEnd());
        pickInquiry.setDatareceiveddateEnd(receiveddateEnd);

        if (!StringUtils.isEmpty(pickInquiry.getOperateddateStart())) {
            String OperateddateStart = CommonUtility.dateFomat(pickInquiry.getOperateddateStart());
            pickInquiry.setOperateddateStart(OperateddateStart);
        }

        if (!StringUtils.isEmpty(pickInquiry.getOperateddateEnd())) {
            String OperateddateEnd = CommonUtility.dateFomat(pickInquiry.getOperateddateEnd());
            pickInquiry.setOperateddateEnd(OperateddateEnd);
        }*/
        if (!StringUtils.isEmpty(pickInquiry.getExpecteddateStart())) {
            String expecteddateStart = CommonUtility.dateFomat(pickInquiry.getExpecteddateStart());
            pickInquiry.setExpecteddateStart(expecteddateStart);
        }
        if (!StringUtils.isEmpty(pickInquiry.getExpecteddateEnd())) {
            String expected_dateEnd = CommonUtility.dateFomat(pickInquiry.getExpecteddateEnd());
            pickInquiry.setExpecteddateEnd(expected_dateEnd);
        }
        
        return pickInquiryMapper.selectCountt(pickInquiry);

    }
	
	public List<PickInquiryCsv> findPickInquiryCsv(
			String datareceiveddateStart, String datareceiveddateEnd, 
			String datareceivedtimeStart, String datareceivedtimeEnd, 
			String expecteddateStart, String expecteddateEnd,
			String operateddateStart, String operateddateEnd,
			String operatedTimeStart,String operatedTimeEnd,
			String orderid,String workingstatus, String ppsid,
			String ppsbinid, String irregularKind,
			String irregularKindName, String orderKind,
			String orderKindName, String sku,
			String allMissingFlag) {
		logger.info("--- PickInquiryService.findPickInquiryCsv() start ---");
		
		List<PickInquiryCsv> pickInquiryCsvList = 
				    pickInquiryMapper.selectPickInquiryCsv(datareceiveddateStart,datareceiveddateEnd,
				    	datareceivedtimeStart,datareceivedtimeEnd,
						expecteddateStart, expecteddateEnd,operateddateStart,operateddateEnd,operatedTimeStart
						,operatedTimeEnd,
						orderid,workingstatus,ppsid,ppsbinid,irregularKind,irregularKindName,orderKind,orderKindName,sku,allMissingFlag);
		return pickInquiryCsvList;
	}

	public String productName(String productCoder) {
		String productname = pickInquiryMapper.selectproductName(productCoder);
		return productname;
	}
	
	public String  getDefTranslateCode(){
		String TranslateCode =  pickInquiryMapper.getDefTranslateCode();
		return TranslateCode;
	}

}
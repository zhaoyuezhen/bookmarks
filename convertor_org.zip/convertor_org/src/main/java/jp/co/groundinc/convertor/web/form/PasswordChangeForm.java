package jp.co.groundinc.convertor.web.form;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class PasswordChangeForm implements Serializable {
	private static final long serialVersionUID = 1L;

	@NotNull
	@Size(max = 13)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{Common.Pattern.AlphaNumeric.message}")
	private String userCode;
	
	private String userName;
	
	@NotNull
	@Size(max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{Common.Pattern.AlphaNumeric.message}")
	private String password;
	
	private String passwordChangeDate;
	
	@NotNull
	@Size(max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{Common.Pattern.AlphaNumeric.message}")
	private String oldPassword;
	
	private String lockFlag;
	
	private String authorityKind;
	
	@NotNull
	@Size(max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{Common.Pattern.AlphaNumeric.message}")
	private String verifyPassword;
	
	public String getVerifyPassword() {
		return verifyPassword;
	}
	public void setVerifyPassword(String verifyPassword) {
		this.verifyPassword = verifyPassword;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPasswordChangeDate() {
		return passwordChangeDate;
	}
	public void setPasswordChangeDate(String passwordChangeDate) {
		this.passwordChangeDate = passwordChangeDate;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getLockFlag() {
		return lockFlag;
	}
	public void setLockFlag(String lockFlag) {
		this.lockFlag = lockFlag;
	}
	public String getAuthorityKind() {
		return authorityKind;
	}
	public void setAuthorityKind(String authorityKind) {
		this.authorityKind = authorityKind;
	}
}

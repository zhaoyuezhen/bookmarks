package jp.co.groundinc.convertor.web;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.domain.StockInquiry;
import jp.co.groundinc.convertor.domain.StockInquiryCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.StockInquiryService;
import jp.co.groundinc.convertor.web.form.StockInquiryForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "stockInquiryForm" })
public class StockInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CommonService commonService;
	
	@Autowired
	MessageSource messageSource;

	@Autowired
	StockInquiryService stockInquiryService;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("stockInquiryForm")
	public StockInquiryForm stockInquiryForm() {
		logger.info("--- StockInquiryController.stockInquiryForm() start ---");
		return new StockInquiryForm();
	}

	@RequestMapping(value = "/view_stock", params = "action=clear")
	public String viewStockClear(HttpServletRequest request, Model model, SessionStatus status) throws ParseException {
		logger.info("--- viewStockClear() start ---");
		StockInquiryForm form = new StockInquiryForm();
		model.addAttribute("stockInquiryForm", form);
		status.setComplete();
		return "stock_inquiry";
	}

	@RequestMapping(value = "/view_stock", params = "action=back")
	public String cviewStockBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- cviewStockBack() start ---");
		return "stock_menu";
	}

	@RequestMapping("/view_stock")
	public String viewStrock(Model model, HttpServletRequest request) {
		logger.info("--- StrockInquiryController.viewStock() start ---");
		StockInquiryForm form = new StockInquiryForm();
		model.addAttribute("stockInquiryForm", form);
		return "stock_inquiry";
	}

	@RequestMapping(value = "/view_stock", params = "action=search")
	public ModelAndView selectStrockInquiryInfo(
			@Validated @ModelAttribute("stockInquiryForm") StockInquiryForm stockInquiryForm, BindingResult result,
			ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- selectStockInquiryInfo() start ---");
		modelView.setViewName("/stock_inquiry");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		int sumPiece = 0;
		float sumCbm = 0.0f;
		String skuStart = stockInquiryForm.getSkuStart();
		String skuEnd = stockInquiryForm.getSkuEnd();
		
		if (!StringUtils.isEmpty(skuStart) && StringUtils.isEmpty(skuEnd)) {
			skuEnd = skuStart;
		}
		if (StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
			skuStart = skuEnd;
		}
		if (!StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
			String regex=".*[a-zA-Z]+.*"; 
			Matcher skuStartm=Pattern.compile(regex).matcher(skuStart); 
			Matcher skuEndm=Pattern.compile(regex).matcher(skuEnd); 
			if (!skuStartm.matches() && !skuEndm.matches()) {
				if (Integer.valueOf(skuStart).intValue() > Integer.valueOf(skuEnd).intValue()) {
					String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
					modelView.addObject("validationMessage", message);
					String skuerror = messageSource.getMessage("stockInquiry.sku.message", null, Locale.JAPAN);
					modelView.addObject("skuerror", skuerror);
					return modelView;
				}
			}
		}
		
		String skuName = stockInquiryForm.getSkuName();
		String totalCbmUnder = stockInquiryForm.getTotalCbmUnder();
		String totalCbmAbove = stockInquiryForm.getTotalCbmAbove();
		if (!StringUtils.isEmpty(totalCbmUnder)) {
			if (Math.abs(Float.valueOf(totalCbmUnder) - 0.0f) <= 0) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String totalCbmAboveerror = messageSource.getMessage("stockInquiry.CBM.Toa.message", null,
						Locale.JAPAN);
				modelView.addObject("totalCbmAboverror", totalCbmAboveerror);
				return modelView;
			}
		}
		if (!StringUtils.isEmpty(totalCbmUnder) && !StringUtils.isEmpty(totalCbmAbove)) {
			if (Float.valueOf(totalCbmAbove) > Float.valueOf(totalCbmUnder)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String totalCbmerror = messageSource.getMessage("stockInquiry.CBM.message", null, Locale.JAPAN);
				modelView.addObject("totalCbm", totalCbmerror);
				return modelView;
			}

		}
		String retentionDays = stockInquiryForm.getRetentionDays();
		StockInquiry stockInquiry = new StockInquiry();
		stockInquiry.setSkuStart(skuStart);
		stockInquiry.setSkuEnd(skuEnd);
		stockInquiry.setSkuName(skuName);
		if (!StringUtils.isEmpty(totalCbmUnder)) {
			BigDecimal totalCbmUnders = new BigDecimal(totalCbmUnder);
			stockInquiry.setTotalCbmUnder(totalCbmUnders);

		}
		if (!StringUtils.isEmpty(totalCbmAbove)) {
			BigDecimal totalCbmAboves = new BigDecimal(totalCbmAbove);
			stockInquiry.setTotalCbmAbove(totalCbmAboves);
		}
		stockInquiry.setRetentionDays(retentionDays);
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=stockInquiryService.selectCountt(stockInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<StockInquiry> stockInquirylist = stockInquiryService.findStockInquiryInfo(stockInquiry);
		if (CollectionUtils.isEmpty(stockInquirylist)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;

		}
		for (int i = 0; i < stockInquirylist.size(); i++) {
			if (!StringUtils.isEmpty(stockInquirylist.get(i).getStockQty())
					&& !StringUtils.isEmpty(stockInquirylist.get(i).getTotalCbm())) {
				sumPiece = sumPiece + Integer.valueOf(stockInquirylist.get(i).getStockQty()).intValue();
				sumCbm = sumCbm + Float.parseFloat(stockInquirylist.get(i).getTotalCbm());
			}

		}
		modelView.addObject("sumPiece", sumPiece);
		modelView.addObject("sumCbm", sumCbm);
		modelView.addObject("sumCommodity", stockInquirylist.size());
		modelView.addObject("stockInquirylist", stockInquirylist);
		return modelView;
	}
	
	@RequestMapping(value = "/view_stock", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("stockInquiryForm") StockInquiryForm stockInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- StockInquiryController.download() start ---");
		
		String skuStart = stockInquiryForm.getSkuStart();
		String skuEnd = stockInquiryForm.getSkuEnd();
		String skuName = stockInquiryForm.getSkuName();
		String totalCbmUnder = stockInquiryForm.getTotalCbmUnder();
		String totalCbmAbove = stockInquiryForm.getTotalCbmAbove();
		String retentionDays = stockInquiryForm.getRetentionDays();
		
		if (!StringUtils.isEmpty(skuStart) || !StringUtils.isEmpty(skuEnd)) {
			if (StringUtils.isEmpty(skuStart)) {
				skuStart = skuEnd;
			}
			
			if (StringUtils.isEmpty(skuEnd)) {
				skuEnd = skuStart;
			}
		}
		StockInquiry stockInquiry = new StockInquiry();
		
		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual=stockInquiryService.selectCountt(stockInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/stock_inquiry");
			return modelView;
		}
		List<StockInquiryCsv> stockInquiryCsvList = 
				stockInquiryService.findStockInquiryCsv(
						skuStart, skuEnd, skuName, totalCbmUnder,totalCbmAbove,retentionDays);
		
		if (CollectionUtils.isEmpty(stockInquiryCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/stock_inquiry");
			return modelView;
		}
		
		modelView.addObject("stockInquiryCsvList", stockInquiryCsvList);
		modelView.setViewName("StockInquiryCsvView");
		return modelView;
	}
}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.domain.AuthorityMaster;
import jp.co.groundinc.convertor.mapper.AuthorityMasterMapper;

@Service
public class AuthorityMasterService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	AuthorityMasterMapper authorityMasterMapper;
	
	public List<AuthorityMaster> findByAuthoritykind(String authoritykind) {
		logger.info("--- AuthorityMasterService.findByAuthoritykind() start ---");
		
		List<AuthorityMaster> authorityMasterList = authorityMasterMapper.findByAuthorityKind(authoritykind);
		
		return authorityMasterList;
	}

	public void updateAuthorityMaster(AuthorityMaster authority) {
		logger.info("--- AuthorityMasterService.updateAuthorityMaster() start ---");
		
		authorityMasterMapper.update(authority);
	}
}

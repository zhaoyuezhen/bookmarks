package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.domain.InventoriesInstruction;
import jp.co.groundinc.convertor.domain.InventoriesInstructionReports;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.InventoriesInstructionService;
import jp.co.groundinc.convertor.web.form.InventoriesInstructionForm;
import jp.co.groundinc.convertor.web.report.InventoriesInstructionReport;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class InventoriesInstructionController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CommonConstant commonConstant;

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	InventoriesInstructionService inventoriesInstructionService;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("inventoriesInstructionForm")
	public InventoriesInstructionForm inventoriesInstructionForm() {
		logger.info("--- InventoryInquiryController.inventoryInquiryForm() start ---");
		return new InventoriesInstructionForm();
	}

	@RequestMapping("/inventoriesInstruction")
	public String inventoriesInstruction(Model model, HttpServletRequest request, SessionStatus status) {
		logger.info("--- InventoriesInstructionController.inventoriesInstruction() start ---");
		InventoriesInstructionForm form = new InventoriesInstructionForm();
		status.setComplete();
		model.addAttribute("inventoriesInstructionForm", form);
		return "Inventories_instruction";
	}

	@RequestMapping(value = "/inventoriesInstruction", params = "action=back")
	public String viewPickInstructionBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- viewPickInstructionBack() start ---");
		status.setComplete();
		return "audit_menu";
	}

	@RequestMapping(value = "/inventoriesInstruction", params = "action=clear")
	public String inventoriesInstructionClear(Model model, SessionStatus status,
			@Validated @ModelAttribute("inventoriesInstructionForm") InventoriesInstructionForm inventoriesInstructionForm)
			throws ParseException {
		logger.info("--- inventoriesInstructionClear() start ---");
		status.setComplete();
		String deClassification = inventoriesInstructionForm.getClassification();
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			model.addAttribute("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			model.addAttribute("Classification", CommonConstant.SLOT);
		}
		return "Inventories_instruction";
	}

	@RequestMapping(value = "/inventoriesInstruction", params = "action=search")
	public ModelAndView selectInventoriesInstructionInfo(
			@Validated @ModelAttribute("inventoriesInstructionForm") InventoriesInstructionForm inventoriesInstructionForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- selectInventoriesInstructionInfo() start ---");
		modelView.setViewName("/Inventories_instruction");
		String deClassification = inventoriesInstructionForm.getClassification();
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			modelView.addObject("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			modelView.addObject("Classification", CommonConstant.SLOT);
		}
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		if (inventoriesInstructionForm.getClassification().equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			String skuStart = inventoriesInstructionForm.getSkuStart();
			String skuEnd = inventoriesInstructionForm.getSkuEnd();

			if (!StringUtils.isEmpty(skuStart) && StringUtils.isEmpty(skuEnd)) {
				skuEnd = skuStart;
			}
			if (StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {
				skuStart = skuEnd;
			}
			if (!StringUtils.isEmpty(skuStart) && !StringUtils.isEmpty(skuEnd)) {

				Matcher skuStartm = Pattern.compile(CommonConstant.REGEX).matcher(skuStart);
				Matcher skuEndm = Pattern.compile(CommonConstant.REGEX).matcher(skuEnd);
				if (!skuStartm.matches() && !skuEndm.matches()) {
					if (Integer.valueOf(skuStart).intValue() > Integer.valueOf(skuEnd).intValue()) {
						String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
						modelView.addObject("validationMessage", message);
						String skuerror = messageSource.getMessage("InventoriesInstruction.sku.message", null,
								Locale.JAPAN);
						modelView.addObject("skuerror", skuerror);
						return modelView;
					}
				}
			}

			InventoriesInstruction inventoriesInstruction = new InventoriesInstruction();
			inventoriesInstruction.setSkuStart(skuStart);
			inventoriesInstruction.setSkuEnd(skuEnd);
			int count = commonService.selectTableUpperLimitCount();
			int ProductCount = inventoriesInstructionService.selectProductCount(inventoriesInstruction);
			if (count <= ProductCount) {
				String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			List<InventoriesInstruction> productInfolist = inventoriesInstructionService
					.findProductInfo(inventoriesInstruction);
			if (CollectionUtils.isEmpty(productInfolist)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			modelView.addObject("inventoriesInstructionList", productInfolist);
		} else {
			String msuIdStart = inventoriesInstructionForm.getMsuIdStart();
			String msuSideStart = inventoriesInstructionForm.getMsuSideStart();
			String msuStepStart = inventoriesInstructionForm.getMsuStepStart();
			String msuIdEnd = inventoriesInstructionForm.getMsuIdEnd();
			String msuSideEnd = inventoriesInstructionForm.getMsuSideEnd();
			String msuStepEnd = inventoriesInstructionForm.getMsuStepEnd();
			String slotErrorStart = this.slotCheck(msuIdStart, msuSideStart, msuStepStart);
			String slotErrorEnd = this.slotCheck(msuIdEnd, msuSideEnd, msuStepEnd);
			if (slotErrorStart != null) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.addObject("sloterror", slotErrorStart);
				return modelView;
			}
			if (slotErrorEnd != null) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.addObject("sloterror", slotErrorEnd);
				return modelView;
			}

			InventoriesInstruction inventoriesInstruction = new InventoriesInstruction();
			inventoriesInstruction.setMsuIdStart(msuIdStart);
			inventoriesInstruction.setMsuIdEnd(msuIdEnd);
			inventoriesInstruction.setMsuSideStart(msuSideStart);
			inventoriesInstruction.setMsuSideEnd(msuSideEnd);
			inventoriesInstruction.setMsuStepStart(msuStepStart);
			inventoriesInstruction.setMsuStepEnd(msuStepEnd);
			/*
			 * String locationStart = this.getLocitionStart(msuIdStart,
			 * msuSideStart, msuStepStart); String locationEnd =
			 * this.getLocitionEnd(msuIdEnd, msuSideEnd, msuStepEnd);
			 */
			/*
			 * inventoriesInstruction.setLocationEnd(locationEnd);
			 * inventoriesInstruction.setLocationStart(locationStart);
			 */

			int count = commonService.selectTableUpperLimitCount();
			int slotCount = inventoriesInstructionService.selectSlotCountt(inventoriesInstruction);
			if (count <= slotCount) {
				String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			List<InventoriesInstruction> Locationlist = inventoriesInstructionService
					.findLocationInfo(inventoriesInstruction);
			if (CollectionUtils.isEmpty(Locationlist)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			modelView.addObject("inventoriesInstructionList", Locationlist);
		}
		return modelView;
	}

	@RequestMapping(value = "/inventoriesInstruction", params = "action=inventoriesInstruction")
	public ModelAndView insertInventoriesInstruction(
			@Validated @ModelAttribute("inventoriesInstructionForm") InventoriesInstructionForm inventoriesInstructionForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) throws Exception {
		logger.info("--- selectInventoriesInstructionInfo() start ---");
		String deClassification = inventoriesInstructionForm.getClassification();
		modelView.setViewName("/Inventories_instruction");
		if (deClassification.equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			modelView.addObject("Classification", CommonConstant.CLASSI_FICATION_PRODUCTCODE);
		} else {
			modelView.addObject("Classification", CommonConstant.SLOT);
		}
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		String Seqence = inventoriesInstructionService.selectAuditSeqence().trim();
		if (inventoriesInstructionForm.getClassification().equals(CommonConstant.CLASSI_FICATION_PRODUCTCODE)) {
			String[] skuCode = inventoriesInstructionForm.getSkus();
			if (skuCode == null || skuCode.length == 0) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			InventoriesInstruction inventoriesInstruction = new InventoriesInstruction();
			inventoriesInstruction.setAuditNo(Seqence);
			inventoriesInstruction.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
			inventoriesInstruction.setAuditParamValueFrom(skuCode[0]);
			inventoriesInstruction.setAuditParamValueTo(skuCode[skuCode.length - 1]);
			inventoriesInstruction.setTargetSlotCount(inventoriesInstructionForm.getSlotCounts());
			inventoriesInstruction.setAuditStockKind(CommonConstant.AUDIT_STOCK_KIND);
			inventoriesInstruction.setStartDate(sysDate);
			inventoriesInstruction.setStartTime(sysTime);
			inventoriesInstruction.setUpdateUser(userDetails.getUsername());
			inventoriesInstruction.setUpdateDate(sysDate);
			inventoriesInstruction.setUpdateTime(sysTime);
			inventoriesInstruction.setCreateUser(userDetails.getUsername());
			inventoriesInstruction.setCreateDate(sysDate);
			inventoriesInstruction.setCreateTime(sysTime);
			inventoriesInstructionService.insertauditException(inventoriesInstruction);
			for (int i = 0; i < skuCode.length; i++) {
				/*List<InventoriesInstruction> ViewstockDetailList = inventoriesInstructionService
						.selectViewStockDetail(skuCode[i]);
				for (int j = 0; j < ViewstockDetailList.size(); j++) {
					InventoriesInstruction inventoriesInstructiond = new InventoriesInstruction();
					inventoriesInstructiond.setAuditNo(Seqence);
					inventoriesInstructiond.setAuditParamValue(ViewstockDetailList.get(j).getSkuDetail());
					inventoriesInstructiond.setLocation(ViewstockDetailList.get(j).getLocation());
					inventoriesInstructiond.setStockQty(ViewstockDetailList.get(j).getStockQty());
					inventoriesInstructiond.setSku(ViewstockDetailList.get(j).getSkuDetail());
					inventoriesInstructiond.setUpdateUser(userDetails.getUsername());
					inventoriesInstructiond.setUpdateDate(sysDate);
					inventoriesInstructiond.setUpdateTime(sysTime);
					inventoriesInstructiond.setCreateUser(userDetails.getUsername());
					inventoriesInstructiond.setCreateDate(sysDate);
					inventoriesInstructiond.setCreateTime(sysTime);
					inventoriesInstructionService.insertAuditStock(inventoriesInstructiond);

				}
*/
				InventoriesInstruction AuditExceptionDetailSku = new InventoriesInstruction();
				AuditExceptionDetailSku.setAuditNo(Seqence);
				AuditExceptionDetailSku.setAuditType(CommonConstant.AUDIT_TYPE_SKU);
				AuditExceptionDetailSku.setAuditParamValue(skuCode[i]);
				AuditExceptionDetailSku.setSendStatus(CommonConstant.SEND_STATUS);
				AuditExceptionDetailSku.setUpdateUser(userDetails.getUsername());
				AuditExceptionDetailSku.setUpdateDate(sysDate);
				AuditExceptionDetailSku.setUpdateTime(sysTime);
				AuditExceptionDetailSku.setCreateUser(userDetails.getUsername());
				AuditExceptionDetailSku.setCreateDate(sysDate);
				AuditExceptionDetailSku.setCreateTime(sysTime);
				inventoriesInstructionService.insertAuditExceptionDetail(AuditExceptionDetailSku);
			}

			List<InventoriesInstructionReports> inventoriesInstructionReportsList = inventoriesInstructionService
					.findInventoriesInstructionReports(Seqence);

			if (CollectionUtils.isEmpty(inventoriesInstructionReportsList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.setViewName("/Inventories_instruction");
				return modelView;
			}
			
			// Reports
			InventoriesInstructionReport reprot = new InventoriesInstructionReport("InventoriesInstructionReport");
			reprot.buildDocument(inventoriesInstructionReportsList, request);
			reprot.exportReport(Seqence);
			modelView.setViewName("/Inventories_instruction");
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;

		} else {
			String[] locations = inventoriesInstructionForm.getLocations();
			if (locations == null || locations.length == 0) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			InventoriesInstruction inventoriesInstruction = new InventoriesInstruction();
			inventoriesInstruction.setAuditNo(Seqence);
			inventoriesInstruction.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
			inventoriesInstruction.setAuditParamValueFrom(locations[0]);
			inventoriesInstruction.setAuditParamValueTo(locations[locations.length - 1]);
			inventoriesInstruction.setTargetSlotCount(Integer.toString(locations.length));
			inventoriesInstruction.setAuditStockKind(CommonConstant.AUDIT_STOCK_KIND);
			inventoriesInstruction.setStartDate(sysDate);
			inventoriesInstruction.setStartTime(sysTime);
			inventoriesInstruction.setUpdateUser(userDetails.getUsername());
			inventoriesInstruction.setUpdateDate(sysDate);
			inventoriesInstruction.setUpdateTime(sysTime);
			inventoriesInstruction.setCreateUser(userDetails.getUsername());
			inventoriesInstruction.setCreateDate(sysDate);
			inventoriesInstruction.setCreateTime(sysTime);
			inventoriesInstructionService.insertauditException(inventoriesInstruction);

			for (int i = 0; i < locations.length; i++) {
			/*	List<InventoriesInstruction>ViewstockDetailLocation = inventoriesInstructionService
						.selectViewStockDetailLocation(locations[i]);
				
				if (!CollectionUtils.isEmpty(ViewstockDetailLocation)) {
					for (int j = 0; j < ViewstockDetailLocation.size(); j++) {
						InventoriesInstruction euditStock = new InventoriesInstruction();
						euditStock.setAuditNo(Seqence);
						euditStock.setLocation(locations[i]);
						euditStock.setSku(ViewstockDetailLocation.get(j).getSkuDetail());
						euditStock.setStockQty(ViewstockDetailLocation.get(j).getStockQty());
						euditStock.setUpdateUser(userDetails.getUsername());
						euditStock.setUpdateDate(sysDate);
						euditStock.setUpdateTime(sysTime);
						euditStock.setCreateUser(userDetails.getUsername());
						euditStock.setCreateDate(sysDate);
						euditStock.setCreateTime(sysTime);
						inventoriesInstructionService.insertAuditStock(euditStock);
					}
				} else {
					InventoriesInstruction euditStock1 = new InventoriesInstruction();
					euditStock1.setAuditNo(Seqence);
					euditStock1.setLocation(locations[i]);
					euditStock1.setSku(null);
					euditStock1.setUpdateUser(userDetails.getUsername());
					euditStock1.setUpdateDate(sysDate);
					euditStock1.setUpdateTime(sysTime);
					euditStock1.setCreateUser(userDetails.getUsername());
					euditStock1.setCreateDate(sysDate);
					euditStock1.setCreateTime(sysTime);
					inventoriesInstructionService.insertAuditStock(euditStock1);

				}*/
				InventoriesInstruction uditExceptionDetialslot = new InventoriesInstruction();
				uditExceptionDetialslot.setAuditNo(Seqence);
				uditExceptionDetialslot.setAuditType(CommonConstant.AUDIT_TYPE_LOCATION);
				uditExceptionDetialslot.setAuditParamValue(locations[i]);
				uditExceptionDetialslot.setSendStatus(CommonConstant.SEND_STATUS);
				uditExceptionDetialslot.setUpdateUser(userDetails.getUsername());
				uditExceptionDetialslot.setUpdateDate(sysDate);
				uditExceptionDetialslot.setUpdateTime(sysTime);
				uditExceptionDetialslot.setCreateUser(userDetails.getUsername());
				uditExceptionDetialslot.setCreateDate(sysDate);
				uditExceptionDetialslot.setCreateTime(sysTime);
				inventoriesInstructionService.insertAuditExceptionDetail(uditExceptionDetialslot);

			}
			// Reports
			List<InventoriesInstructionReports> inventoriesInstructionReportsList = inventoriesInstructionService
					.findInventoriesInstructionReports(Seqence);

			if (CollectionUtils.isEmpty(inventoriesInstructionReportsList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				modelView.setViewName("/Inventories_instruction");
				return modelView;
			}

			InventoriesInstructionReport reprot = new InventoriesInstructionReport("InventoriesInstructionReport");
			reprot.buildDocument(inventoriesInstructionReportsList, request);
			reprot.exportReport(Seqence);
			modelView.setViewName("/Inventories_instruction");
			String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
	}

	private String slotCheck(String msuId, String msuSide, String msuStep) {

		String slotrror = null;
		if (!StringUtils.isEmpty(msuId) && StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {

			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;

		}

		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {

			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && !StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}
		if (StringUtils.isEmpty(msuId) && StringUtils.isEmpty(msuSide) && !StringUtils.isEmpty(msuStep)) {
			slotrror = messageSource.getMessage("InventoriesInstruction.location.message", null, Locale.JAPAN);
			return slotrror;
		}

		return slotrror;
	}

}

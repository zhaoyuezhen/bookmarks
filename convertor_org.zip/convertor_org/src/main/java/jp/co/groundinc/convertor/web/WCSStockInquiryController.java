package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.WCSStockInquiry;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.WCSStockInquiryService;

@Controller
@EnableAutoConfiguration
@SessionAttributes

public class WCSStockInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	WCSStockInquiryService wCSStockInquiryService;
	
	@Autowired
	CommonUtility commonUtility;
	
	@InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
        }
	
	@ModelAttribute("requestDateStart")
	public String requestDateStart()throws ParseException{
		logger.info("--- WCSStockInquiryController.WCSStockInquiry() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("requestDateEnd")
	public String requestDateEnd() throws ParseException {
		logger.info("--- WCSStockInquiryController.WCSStockInquiry() start ---");
		return commonService.getOperationDate();
	}
	
	 @ModelAttribute("wCSStockInquiry")
	public WCSStockInquiry wCSStockInquiry() {
		logger.info("--- WCSStockInquiryController.wCSStockInquiry() start ---");
		return new WCSStockInquiry();
	}
	   
	@RequestMapping(value = "/wcs_stock_inquiry")
	public ModelAndView wCSStockInquiry(ModelAndView modelView) throws ParseException {
		logger.info("--- WCSStockInquiryController.WCSStockInquiry() start ---");
		WCSStockInquiry wCSStockInquiry = new WCSStockInquiry();
		modelView.addObject("wCSStockInquiry", wCSStockInquiry);
		return modelView;

	}
	
	@RequestMapping(value = "/wcs_stock_inquiry", params = "action=clear")
	public String wCSStockInquiryClear(HttpServletRequest request, ModelAndView modelView) throws ParseException {
		logger.info("--- WCSStockInquiryController.wCSStockInquiryClear() start ---");
		
		WCSStockInquiry wCSStockInquiry = new WCSStockInquiry();
		modelView.addObject("wCSStockInquiry", wCSStockInquiry);

		return "wcs_stock_inquiry";
	}

	@RequestMapping(value = "/wcs_stock_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("wCSStockInquiry") WCSStockInquiry wCSStockInquiry, BindingResult result, ModelAndView modelView){
		logger.info("--- WCSStockInquiryController.search() start ---");
		modelView.addObject("requestDateStart", wCSStockInquiry.getRequestDateStart());
		modelView.addObject("requestDateEnd", wCSStockInquiry.getRequestDateEnd());
		modelView.setViewName("/wcs_stock_inquiry");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String requestDateStart = wCSStockInquiry.getRequestDateStart();
		String requestDateEnd = wCSStockInquiry.getRequestDateEnd();  
		
        if(!StringUtils.isEmpty(requestDateStart) && !StringUtils.isEmpty(requestDateEnd)){
            if (CommonUtility.comparedateStartafterEnd(requestDateStart, requestDateEnd)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationDate = messageSource.getMessage("WCSStockInquiry.search.requestDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("operationDate", operationDate);
				return modelView;
		     }
	     }
        if (!StringUtils.isEmpty(requestDateStart) && StringUtils.isEmpty(requestDateEnd)) {
        	String dateStart = wCSStockInquiry.getRequestDateStart();
        	wCSStockInquiry.setRequestDateEnd(dateStart);
        	
		}
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = wCSStockInquiryService.selectCountt(wCSStockInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
			List<WCSStockInquiry> wCSStockInquiryList = wCSStockInquiryService.findWCSStockInquiry(wCSStockInquiry);
		
			if (CollectionUtils.isEmpty(wCSStockInquiryList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			for(int i=0;i < wCSStockInquiryList.size();i++){
			    if (!StringUtils.isEmpty(wCSStockInquiryList.get(i).getRequestDate())
					&& !StringUtils.isEmpty(wCSStockInquiryList.get(i).getRequestTime())) {
					String str = wCSStockInquiryList.get(i).getRequestDate() + wCSStockInquiryList.get(i).getRequestTime();
					String newstr = CommonUtility.getDateTime(str);
					wCSStockInquiryList.get(i).setRequestDateTime(newstr);
			    }
			    if (!StringUtils.isEmpty(wCSStockInquiryList.get(i).getGenerateDate())
						&& !StringUtils.isEmpty(wCSStockInquiryList.get(i).getGenerateTime())) {
						String str = wCSStockInquiryList.get(i).getGenerateDate() + wCSStockInquiryList.get(i).getGenerateTime();
						String newstr = CommonUtility.getDateTime(str);
						wCSStockInquiryList.get(i).setGenerateDateTime(newstr);;
				}
		     }
		modelView.addObject("wCSStockInquiryList", wCSStockInquiryList);
		return modelView;
	}
}

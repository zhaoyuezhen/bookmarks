package jp.co.groundinc.convertor.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.AuditInquiry;
import jp.co.groundinc.convertor.domain.AuditInquiryDetail;
import jp.co.groundinc.convertor.domain.AuditInquiryDetailCsv;
import jp.co.groundinc.convertor.domain.AuditInquiryReports;
@Mapper
public interface AuditInquiryMapper {
	List<AuditInquiry> selectAuditInquiry(AuditInquiry auditInquiry);
	int selectCountt(AuditInquiry auditInquiry);
	AuditInquiry selectAuditInquiryInfo(String auditNo);
	List<AuditInquiryDetail> selectAuditInquiryDetail(String auditNo);
	List<AuditInquiryDetailCsv> selectAuditInquiryDetailCsv(List<String> orderIdList);
	
	List<AuditInquiryReports> selectAuditInquiryReport(String auditNo);
	
	List<AuditInquiryReports> selectAuditInquiryExpectReport(String auditNo);
	
	String selectPrintLogSeqence();
	void insertPrintLog(AuditInquiry auditInquiry);
	void insertAuditExpectationDetail(AuditInquiryDetail auditInquiryDetail);
}

package jp.co.groundinc.convertor.web.form;

import java.io.Serializable;
import java.util.List;

import jp.co.groundinc.convertor.domain.AuthorityMaster;

public class AuthorityMasterForm implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String authoritykind;
	private List<AuthorityMaster> authorityList;
	
	public String getAuthoritykind() {
		return authoritykind;
	}
	public void setAuthoritykind(String authoritykind) {
		this.authoritykind = authoritykind;
	}
	public List<AuthorityMaster> getAuthorityList() {
		return authorityList;
	}
	public void setAuthorityList(List<AuthorityMaster> authorityList) {
		this.authorityList = authorityList;
	}

}

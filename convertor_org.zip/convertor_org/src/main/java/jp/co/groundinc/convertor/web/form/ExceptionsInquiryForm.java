package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class ExceptionsInquiryForm {
	
	@NotNull(message = "{ExceptionsInquiry.search.exceptionDateStart.empty.message}")
	private String exceptionDateStart;
	
	private String exceptionDateEnd;
	
	private String exceptionDate;

	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{ExceptionsInquiry.sku.message}")
	private String sku;

	private String skuName;

	public String getExceptionDateStart() {
		return exceptionDateStart;
	}

	public void setExceptionDateStart(String exceptionDateStart) {
		this.exceptionDateStart = exceptionDateStart;
	}

	public String getExceptionDateEnd() {
		return exceptionDateEnd;
	}

	public void setExceptionDateEnd(String exceptionDateEnd) {
		this.exceptionDateEnd = exceptionDateEnd;
	}

	public String getExceptionDate() {
		return exceptionDate;
	}

	public void setExceptionDate(String exceptionDate) {
		this.exceptionDate = exceptionDate;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

}

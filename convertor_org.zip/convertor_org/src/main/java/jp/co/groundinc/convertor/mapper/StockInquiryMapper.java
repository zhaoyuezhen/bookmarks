package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.StockInquiry;
import jp.co.groundinc.convertor.domain.StockInquiryCsv;
import jp.co.groundinc.convertor.domain.StockInquiryDetail;

@Mapper
public interface StockInquiryMapper {
	List<StockInquiry> selectStockInquiryInfo(StockInquiry stockInquiry);
	int selectCountt(StockInquiry stockInquiry);
	List<StockInquiryDetail> selectStockInquiryDetailInfo(String sku);
	String selectproductName(String productcoder);
	StockInquiry selectStockInquiryInfos(String sku);
	List<StockInquiryCsv> selectStockInquiryCsv(
			@Param("skuStart") String skuStart,
			@Param("skuEnd") String skuEnd,
			@Param("skuName") String skuName,
			@Param("totalCbmUnder") String totalCbmUnder,
			@Param("totalCbmAbove") String totalCbmAbove,
			@Param("retentionDays") String retentionDays);
}

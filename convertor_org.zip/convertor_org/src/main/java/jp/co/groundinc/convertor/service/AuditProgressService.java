package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuditProgress;
import jp.co.groundinc.convertor.mapper.AuditProgressMapper;

@Service
public class AuditProgressService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	AuditProgressMapper auditProgressMapper;
	@Autowired
	CommonUtility commonUtility;
	public List<AuditProgress> findAuditProgress(AuditProgress auditProgress) {

		logger.info("--- AuditProgress.findAuditProgress() start ---");

			String startDate = CommonUtility.dateFomat(auditProgress.getStartDate());
			String endDate = CommonUtility.dateFomat(auditProgress.getNextStartDate());
			auditProgress.setStartDate(startDate);;
			auditProgress.setNextStartDate(endDate);
			List<AuditProgress> auditProgressList = auditProgressMapper.findByDate(auditProgress);

			return auditProgressList;
	}
	public int selectCountt(AuditProgress auditProgress) {
		String startDate = CommonUtility.dateFomat(auditProgress.getStartDate());
		String endDate = CommonUtility.dateFomat(auditProgress.getNextStartDate());
		auditProgress.setStartDate(startDate);;
		auditProgress.setNextStartDate(endDate);
		
		int count = auditProgressMapper.selectCountt(auditProgress);
		return count;

	}
}


package jp.co.groundinc.convertor.web;

import java.security.Principal;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuthorityMaster;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.AuthorityMasterService;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.web.form.AuthorityMasterForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "authorityKinds", "authorityMasterForm"}) 
public class AuthorityMasterController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CommonService commonService ;
	
	@Autowired
	AuthorityMasterService authorityMasterService ;

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }
    
	@ModelAttribute("authorityKinds")
	public List<Translate> authorityKinds() {
		logger.info("--- AuthorityMasterController.authorityKinds() start ---");
		return commonService.getTranslateList("AuthorityKind");
	}
	
	@ModelAttribute("authorityMasterForm")
	public AuthorityMasterForm AuthorityMasterForm() {
		logger.info("--- AuthorityMasterController.AuthorityMasterForm() start ---");
		return new AuthorityMasterForm();
	}

    @RequestMapping("/authority_master")
    public String AuthorityMaster(Model model) {
    	logger.info("--- AuthorityMasterController.AuthorityMaster() start ---");
        return "authority_master";
    }

    @RequestMapping(value="/authority_master", params="action=search")
    public ModelAndView search(@Validated @ModelAttribute AuthorityMasterForm form, ModelAndView modelView) {
    	logger.info("--- AuthorityMasterController.search() start ---");
    	
		modelView.setViewName("/authority_master");
		
    	String authoritykind = form.getAuthoritykind();
    	if (StringUtils.isEmpty(authoritykind) ) {
            String message = messageSource.getMessage("Common.Search.Message.E002", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
            
            return modelView;
    	}
    	
    	List<AuthorityMaster> authorityMasterList = authorityMasterService.findByAuthoritykind(authoritykind);
		if (CollectionUtils.isEmpty(authorityMasterList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);

			return modelView;
		}
    	
    	AuthorityMasterForm newForm = new AuthorityMasterForm();
    	newForm.setAuthoritykind(form.getAuthoritykind());
    	newForm.setAuthorityList(authorityMasterList);
    	modelView.addObject("authorityMasterForm", newForm);
        modelView.addObject("authorityList", authorityMasterList);
    	
        return modelView;
    }

    @RequestMapping(value="/authority_master", params="action=update")
    public ModelAndView update(Principal principal, @Validated @ModelAttribute AuthorityMasterForm form, ModelAndView modelView) {
    	logger.info("--- AuthorityMasterController.update() start ---");

    	modelView.setViewName("/authority_master");

    	List<AuthorityMaster> authorityList = form.getAuthorityList();
		if (CollectionUtils.isEmpty(authorityList)) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);

			return modelView;
		}
    	
		for (AuthorityMaster authority : authorityList) {
			if (StringUtils.isEmpty(authority.getPermissionFlag())) {
				authority.setPermissionFlag(CommonConstant.FLAG_OFF);
			}
	    	String logInUser = principal.getName();
	    	authority.setUpdateUser(logInUser);
	    	authority.setUpdateDate(CommonUtility.getSysDateTime().get("DATE"));
	    	authority.setUpdateTime(CommonUtility.getSysDateTime().get("TIME"));
	    	
			authorityMasterService.updateAuthorityMaster(authority);
		}
		

        String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
        modelView.addObject("validationMessage", message);
        return modelView;
    }
    
    @RequestMapping(value="/authority_master", params="action=clear")
    public String clearAuthorityMaster(Model model, SessionStatus status) {
    	logger.info("--- AuthorityMasterController.clearAuthorityMaster() start ---");
    	
    	status.setComplete();
    	
    	AuthorityMasterForm form = new AuthorityMasterForm();
		model.addAttribute("authorityMasterForm", form);

		return AuthorityMaster(model);
    }
}

package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.DailyStockFileInquiry;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.DailyStockInquiryService;

@Controller
@EnableAutoConfiguration
@SessionAttributes

public class DailyStockFileInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	DailyStockInquiryService dailyStockInquiryService;
	
	@Autowired
	CommonUtility commonUtility;
	
	@InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
        }
	
	@ModelAttribute("processedDateStart")
	public String processedDateStart()throws ParseException{
		logger.info("--- DailyStockFileInquiryController.DailyStockFileInquiry() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("processedDateEnd")
	public String processedDateEnd() throws ParseException {
		logger.info("--- DailyStockFileInquiryController.DailyStockFileInquiry() start ---");
		return commonService.getOperationDate();
	}
	
	 @ModelAttribute("dailyStockFileInquiry")
		public DailyStockFileInquiry dailyStockFileInquiry() {
			logger.info("--- DailyStockFileInquiryController.dailyStockFileInquiry() start ---");
			return new DailyStockFileInquiry();
		}
	   
	@RequestMapping(value = "/daily_stock_inquiry")
	public ModelAndView DailyStockFileInquiry(ModelAndView modelView) throws ParseException {
		logger.info("--- DailyStockFileInquiryController.WCSStockInquiry() start ---");
		DailyStockFileInquiry dailyStockFileInquiry = new DailyStockFileInquiry();
		modelView.addObject("dailyStockFileInquiry", dailyStockFileInquiry);
		return modelView;

	}
	
	@RequestMapping(value = "/daily_stock_inquiry", params = "action=clear")
	public String dailyStockFileInquiryClear(HttpServletRequest request, ModelAndView modelView) throws ParseException {
		logger.info("--- DailyStockFileInquiryController.DailyStockFileInquiryClear() start ---");
		
		DailyStockFileInquiry dailyStockFileInquiry = new DailyStockFileInquiry();
		modelView.addObject("dailyStockFileInquiry", dailyStockFileInquiry);

		return "daily_stock_inquiry";
	}
	

	@RequestMapping(value = "/daily_stock_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("dailyStockFileInquiry") DailyStockFileInquiry dailyStockFileInquiry, BindingResult result, ModelAndView modelView){
		logger.info("--- DailyStockFileInquiryController.search() start ---");
		modelView.addObject("processedDateStart", dailyStockFileInquiry.getProcessedDateStart());
		modelView.addObject("processedDateEnd", dailyStockFileInquiry.getProcessedDateEnd());
		modelView.setViewName("/daily_stock_inquiry");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String processedDateStart = dailyStockFileInquiry.getProcessedDateStart();
		String processedDateEnd = dailyStockFileInquiry.getProcessedDateEnd();  
		
        if(!StringUtils.isEmpty(processedDateStart) && !StringUtils.isEmpty(processedDateEnd)){
            if (CommonUtility.comparedateStartafterEnd(processedDateStart, processedDateEnd)) {

				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operationDate = messageSource.getMessage("DailyStockFileInquiry.search.processedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("operationDate", operationDate);
				return modelView;
		     }
	     }
        if (!StringUtils.isEmpty(processedDateStart) && StringUtils.isEmpty(processedDateEnd)) {
        	String dateStart = dailyStockFileInquiry.getProcessedDateStart();
        	dailyStockFileInquiry.setProcessedDateEnd(dateStart);
        	
		}
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = dailyStockInquiryService.selectCountt(dailyStockFileInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
			List<DailyStockFileInquiry> dailyStockFileInquiryList = dailyStockInquiryService.findDailyStockFileInquiry(dailyStockFileInquiry);
		
			if (CollectionUtils.isEmpty(dailyStockFileInquiryList)) {
				String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				return modelView;
			}
			for(int i=0;i < dailyStockFileInquiryList.size();i++){
			    if (!StringUtils.isEmpty(dailyStockFileInquiryList.get(i).getProcessedDate())
					&& !StringUtils.isEmpty(dailyStockFileInquiryList.get(i).getProcessedTime())) {
					String str = dailyStockFileInquiryList.get(i).getProcessedDate() + dailyStockFileInquiryList.get(i).getProcessedTime();
					String newstr = CommonUtility.getDateTime(str);
					dailyStockFileInquiryList.get(i).setProcessedDateTime(newstr);
			    }
			    
		     }
		modelView.addObject("dailyStockFileInquiryList", dailyStockFileInquiryList);
		return modelView;
	}
}

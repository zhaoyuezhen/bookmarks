package jp.co.groundinc.convertor.domain;

public class DailyStockFilecreatReports {
	
	private String auditNoStart;
	
	private String auditNoEnd;
	
	private String auditNo;
	
	private String startDateStart;
	
	private String startDateEnd;
	
	private String startDate;
	
	private String auditId;
	
	private String auditTypeName;
	
	private String auditParamValueFrom;
	
	private String auditParamValueTo;
	
	private String auditParamValue;
	
	private String expectedSkuCount;
	
	private String resultSkuCount;
	
	private String startTime;
	
	private String expectedQty;
	
	private String resultQty;
	
	private String startDateTime;
	
	private String irregularKindName;
	
	private String targetCount;
	
	public String getTargetCount() {
		return targetCount;
	}
	public void setTargetCount(String targetCount) {
		this.targetCount = targetCount;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditTypeName() {
		return auditTypeName;
	}
	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}
	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}
	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}
	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}
	public String getAuditParamValue() {
		return auditParamValue;
	}
	public void setAuditParamValue(String auditParamValue) {
		this.auditParamValue = auditParamValue;
	}
	public String getExpectedSkuCount() {
		return expectedSkuCount;
	}
	public void setExpectedSkuCount(String expectedSkuCount) {
		this.expectedSkuCount = expectedSkuCount;
	}
	public String getResultSkuCount() {
		return resultSkuCount;
	}
	public void setResultSkuCount(String resultSkuCount) {
		this.resultSkuCount = resultSkuCount;
	}
	public String getIrregularKindName() {
		return irregularKindName;
	}
	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getAuditNoStart() {
		return auditNoStart;
	}
	public void setAuditNoStart(String auditNoStart) {
		this.auditNoStart = auditNoStart;
	}
	public String getAuditNoEnd() {
		return auditNoEnd;
	}
	public void setAuditNoEnd(String auditNoEnd) {
		this.auditNoEnd = auditNoEnd;
	}
	public String getAuditNo() {
		return auditNo;
	}
	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}
	public String getStartDateStart() {
		return startDateStart;
	}
	public void setStartDateStart(String startDateStart) {
		this.startDateStart = startDateStart;
	}
	public String getStartDateEnd() {
		return startDateEnd;
	}
	public void setStartDateEnd(String startDateEnd) {
		this.startDateEnd = startDateEnd;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(String expectedQty) {
		this.expectedQty = expectedQty;
	}
	public String getResultQty() {
		return resultQty;
	}
	public void setResultQty(String resultQty) {
		this.resultQty = resultQty;
	}
	
}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.InventoryInquiry;
import jp.co.groundinc.convertor.domain.InventoryInquiryCsv;
import jp.co.groundinc.convertor.mapper.InventoryInquiryMapper;

@Service
public class InventoryInquiryService {
	@Autowired
	InventoryInquiryMapper inventoryInquiryMapper;
	@Autowired
	CommonUtility commonUtility;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public List<InventoryInquiry> selectInventoryInquiry(InventoryInquiry inventoryInquiry) {

		if (!StringUtils.isEmpty(inventoryInquiry.getOperatedDateStart())) {
			String operatedDateStart = CommonUtility.dateFomat(inventoryInquiry.getOperatedDateStart());
			inventoryInquiry.setOperatedDateStart(operatedDateStart);
		}
		if (!StringUtils.isEmpty(inventoryInquiry.getOperatedDateEnd())) {
			String operatedDateEnd = CommonUtility.dateFomat(inventoryInquiry.getOperatedDateEnd());
			inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
		}
		if(!StringUtils.isEmpty(inventoryInquiry.getOperatedTimeStart())){
		 String operatedTimeStart  = CommonUtility.timeFomat(inventoryInquiry.getOperatedTimeStart());
		 inventoryInquiry.setOperatedTimeStart(operatedTimeStart);
		}
		if(!StringUtils.isEmpty(inventoryInquiry.getOperatedTimeEnd())){
	     String operatedTimeEnd = CommonUtility.timeFomat(inventoryInquiry.getOperatedTimeEnd());
	     inventoryInquiry.setOperatedTimeEnd(operatedTimeEnd);
		}
		List<InventoryInquiry> list = inventoryInquiryMapper.selectInventoryInquiry(inventoryInquiry);
		return list;

	}
	
	public int selectCount(InventoryInquiry inventoryInquiry) {

		if (!StringUtils.isEmpty(inventoryInquiry.getOperatedDateStart())) {
			String operatedDateStart = CommonUtility.dateFomat(inventoryInquiry.getOperatedDateStart());
			inventoryInquiry.setOperatedDateStart(operatedDateStart);
		}
		if (!StringUtils.isEmpty(inventoryInquiry.getOperatedDateEnd())) {
			String operatedDateEnd = CommonUtility.dateFomat(inventoryInquiry.getOperatedDateEnd());
			inventoryInquiry.setOperatedDateEnd(operatedDateEnd);
		}
		if(!StringUtils.isEmpty(inventoryInquiry.getOperatedTimeStart())){
		 String operatedTimeStart  = CommonUtility.timeFomat(inventoryInquiry.getOperatedTimeStart());
		 inventoryInquiry.setOperatedTimeStart(operatedTimeStart +"00");
		}
		if(!StringUtils.isEmpty(inventoryInquiry.getOperatedTimeEnd())){
	     String operatedTimeEnd = CommonUtility.timeFomat(inventoryInquiry.getOperatedTimeEnd());
	     inventoryInquiry.setOperatedTimeEnd(operatedTimeEnd +"59");
		}
		
		int count = inventoryInquiryMapper.selectCount(inventoryInquiry);
		return count;

	}
	
	public List<InventoryInquiryCsv> findInventoryInquiryCsv(
			String operatedDateStart,String operatedDateEnd,
			String operatedDateTimeStart,String operatedDateTimeEnd,
			String sku, String keyId,String location,String userCode, String ppsId,
			String Put, String Pick,String ManualPick, String ManualPut,String Audit,
			String StockAdjust, String operationKindCode,String PickExceptions,String AuditExceptions) {
		logger.info("--- InventoryInquiryService.findInventoryInquiryCsv() start ---");
		
		if (!StringUtils.isEmpty(operatedDateStart)) {
			 operatedDateStart = CommonUtility.dateFomat(operatedDateStart);
			 operatedDateEnd = CommonUtility.dateFomat(operatedDateEnd);
			 operatedDateTimeStart = CommonUtility.timeFomat(operatedDateTimeStart)+"00";
			 operatedDateTimeEnd = CommonUtility.timeFomat(operatedDateTimeEnd)+"59";
		}
		
		List<InventoryInquiryCsv> inventoryInquiryCsvList = inventoryInquiryMapper.selectInventoryInquiryCsv(
							operatedDateStart,operatedDateEnd,
							operatedDateTimeStart,operatedDateTimeEnd,
							sku, keyId, location,userCode,
							ppsId,Put,Pick,ManualPick,ManualPut,Audit,StockAdjust,operationKindCode,PickExceptions,AuditExceptions);
		
		return inventoryInquiryCsvList;
	}

}
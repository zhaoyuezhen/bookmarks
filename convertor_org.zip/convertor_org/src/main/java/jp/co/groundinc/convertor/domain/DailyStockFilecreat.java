package jp.co.groundinc.convertor.domain;

public class DailyStockFilecreat {
	
	private String sku;
	private String skuKind;
	private String stockQty;
	private String area;
	private String createKind;
	private String processedDate;
	private String processedTime;
	private int totalCount;
	private String filePath;
	private String createUser;
	private String createDate;
	private String createTime;
	private String updateUser;
	private String updateDate;
	private String updateTime;
	private String stockSendDate;
	private String stockSendStartTime;
	private String stockSendEndTime;
	private String fileName;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getCreateKind() {
		return createKind;
	}
	public void setCreateKind(String createKind) {
		this.createKind = createKind;
	}
	public String getProcessedDate() {
		return processedDate;
	}
	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}
	public String getProcessedTime() {
		return processedTime;
	}
	public void setProcessedTime(String processedTime) {
		this.processedTime = processedTime;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getStockSendDate() {
		return stockSendDate;
	}
	public void setStockSendDate(String stockSendDate) {
		this.stockSendDate = stockSendDate;
	}
	public String getStockSendStartTime() {
		return stockSendStartTime;
	}
	public void setStockSendStartTime(String stockSendStartTime) {
		this.stockSendStartTime = stockSendStartTime;
	}
	public String getStockSendEndTime() {
		return stockSendEndTime;
	}
	public void setStockSendEndTime(String stockSendEndTime) {
		this.stockSendEndTime = stockSendEndTime;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getStockQty() {
		return stockQty;
	}
	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
}

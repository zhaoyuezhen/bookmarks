package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.StowInquiry;
import jp.co.groundinc.convertor.domain.StowInquiryCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.StowInquiryService;
import jp.co.groundinc.convertor.web.form.StowInquiryForm;
import jp.co.groundinc.convertor.web.utility.DatePropertyEditor;
import jp.co.groundinc.convertor.web.utility.TimePropertyEditor;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "stowInquiryForm" }) 
public class StowInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	StowInquiryService stowInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		dataBinder.registerCustomEditor(String.class, "operatedDateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operatedDateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operatedTimeStart", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operatedTimeEnd", new TimePropertyEditor());
		
		dataBinder.registerCustomEditor(String.class, "dataReceivedDateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedDateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedTimeStart", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedTimeEnd", new TimePropertyEditor());
		
	}

	@ModelAttribute("stowInquiryForm")
	public StowInquiryForm stowInquiryForm() {
		logger.info("--- StowInquiryController.stowInquiryForm() start ---");
		return new StowInquiryForm();
	}

	@ModelAttribute("processingStatus")
	public List<Translate> processingStatus() {
		logger.info("--- StowInquiryController.processingStatus() start ---");
		return commonService.getTranslateList("ProcessingStatus");
	}

	@ModelAttribute("ppsNo")
	public List<Translate> ppsNos() {
		logger.info("--- StowInquiryController.ppsNos() start ---");
		return commonService.getTranslateList("PpsNo");
	}

	@ModelAttribute("irregularKind")
	public List<Translate> irregularKind() {
		logger.info("--- StowInquiryController.irregularKind() start ---");
		return commonService.getTranslateList("IrregularKind");
	}
	
	@ModelAttribute("putKind")
	public List<Translate> putKind() {
		logger.info("--- StowInquiryController.putKind() start ---");
		return commonService.getTranslateList("PutKind");
	}

	@RequestMapping("/stow_inquiry")
	public ModelAndView stowInquiry(ModelAndView modelView) throws ParseException {
		logger.info("--- StowInquiryController.stowInquiry() start ---");
		
		String operationDate = commonService.getOperationDate();
		StowInquiryForm form = new StowInquiryForm();
		form.setDataReceivedDateStart(operationDate);
		form.setDataReceivedDateEnd(operationDate);
		form.setDataReceivedTimeStart("0000");
		form.setDataReceivedTimeEnd("2359");
		modelView.addObject("stowInquiryForm", form);

		return modelView;
	}

	@RequestMapping(value = "/stow_inquiry", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("stowInquiryForm") StowInquiryForm stowInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request){

		logger.info("--- search() start ---");
		modelView.setViewName("/stow_inquiry");
		
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String dataReceivedDateStart = stowInquiryForm.getDataReceivedDateStart();
		String dataReceivedDateEnd = stowInquiryForm.getDataReceivedDateEnd();
		String dataReceivedTimeStart = stowInquiryForm.getDataReceivedTimeStart();
		String dataReceivedTimeEnd = stowInquiryForm.getDataReceivedTimeEnd();
		
		String operatedDateStart = stowInquiryForm.getOperatedDateStart();
		String operatedDateEnd = stowInquiryForm.getOperatedDateEnd();
		String operatedTimeStart = stowInquiryForm.getOperatedTimeStart();
		String operatedTimeEnd = stowInquiryForm.getOperatedTimeEnd();
		
		String containerId = stowInquiryForm.getContainerId();
		String expectedPutId = stowInquiryForm.getExpectedPutId();
		String workstatus = stowInquiryForm.getWorkingStatus();
		String ppsId = stowInquiryForm.getPpsId();
		String irregularKind = stowInquiryForm.getIrregularKind();
		String irregularKindName = stowInquiryForm.getIrregularKindName();
		String sku = stowInquiryForm.getSku();
		String expectedQty = stowInquiryForm.getExpectedQty();
		String resultQty = stowInquiryForm.getResultQty();
		String putKind = stowInquiryForm.getPutKind();
		String putKindName = stowInquiryForm.getPutKindName();

		if (StringUtils.isEmpty(dataReceivedTimeStart)) {
			dataReceivedTimeStart = "000000";
		} else {
			dataReceivedTimeStart = dataReceivedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(dataReceivedTimeEnd)) {
			dataReceivedTimeEnd = "235959";
		} else {
			dataReceivedTimeEnd = dataReceivedTimeEnd + "59";
		}
		
		if (StringUtils.isEmpty(dataReceivedDateEnd)) {
			dataReceivedDateEnd = dataReceivedDateStart;
		}
		if (!StringUtils.isEmpty(dataReceivedDateStart) && !StringUtils.isEmpty(dataReceivedDateEnd)) {
			
			if (CommonUtility.compareDateTime(dataReceivedDateStart + " "+ dataReceivedTimeStart, dataReceivedDateEnd + " "+ dataReceivedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String dataReceivedDate = messageSource.getMessage("stowInquiry.dataReceivedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("dataReceivedDate", dataReceivedDate);
				return modelView;
			}
		}
		
		
		if (StringUtils.isEmpty(operatedTimeStart)) {
			operatedTimeStart = "000000";
		} else {
			operatedTimeStart = operatedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(operatedTimeEnd)) {
			operatedTimeEnd = "235959";
		} else {
			operatedTimeEnd = operatedTimeEnd + "59";
		}
		if (!StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {
			
			if (CommonUtility.compareDateTime(operatedDateStart+" "+operatedTimeStart, operatedDateEnd+" "+operatedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("stowInquiry.operatedDate.message", null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
		} else if (!StringUtils.isEmpty(operatedDateStart) && StringUtils.isEmpty(operatedDateEnd)) {
			operatedDateEnd = operatedDateStart;
		} else if (StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {
			operatedDateStart = operatedDateEnd;
		} else {
			operatedDateStart = "";
			operatedDateEnd = "";
			
			operatedTimeStart = "";
			operatedTimeEnd = "";
		}

		StowInquiry stowInquiry = new StowInquiry();
		stowInquiry.setDataReceivedDateStart(dataReceivedDateStart);
		stowInquiry.setDataReceivedDateEnd(dataReceivedDateEnd);
		stowInquiry.setDataReceivedTimeStart(dataReceivedTimeStart);
		stowInquiry.setDataReceivedTimeEnd(dataReceivedTimeEnd);
					   
		stowInquiry.setOperatedDateStart(operatedDateStart);
		stowInquiry.setOperatedDateEnd(operatedDateEnd);
		stowInquiry.setOperatedDateTimeStart(operatedTimeStart);
		stowInquiry.setOperatedDateTimeEnd(operatedTimeEnd);
		
		
		stowInquiry.setWorkingStatus(workstatus);
		stowInquiry.setPpsId(ppsId);
		stowInquiry.setIrregularKind(irregularKind);
		stowInquiry.setIrregularKindName(irregularKindName);
		stowInquiry.setPutKind(putKind);
		stowInquiry.setPutKindName(putKindName);
		stowInquiry.setSku(sku);
		
		
		stowInquiry.setContainerId(containerId);
		stowInquiry.setExpectedPutId(expectedPutId);
		stowInquiryForm.setExpectedQty(expectedQty);
		stowInquiryForm.setResultQty(resultQty);
		
		stowInquiryForm.setDataReceivedDateStart(dataReceivedDateStart);
		stowInquiryForm.setDataReceivedDateEnd(dataReceivedDateEnd);
		stowInquiryForm.setDataReceivedTimeStart(dataReceivedTimeStart.length() >= 4 ? dataReceivedTimeStart.substring(0,4) : "");
		stowInquiryForm.setDataReceivedTimeEnd(dataReceivedTimeEnd.length() >= 4 ? dataReceivedTimeEnd.substring(0,4) : "");
		stowInquiryForm.setOperatedDateStart(operatedDateStart);
		stowInquiryForm.setOperatedDateEnd(operatedDateEnd);
		stowInquiryForm.setOperatedTimeStart(operatedTimeStart.length() >= 4 ? operatedTimeStart.substring(0,4) : "");
		stowInquiryForm.setOperatedTimeEnd(operatedTimeEnd.length() >= 4 ? operatedTimeEnd.substring(0,4) : "");
		
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual = stowInquiryService.selectCountt(stowInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<StowInquiry> putList = stowInquiryService.selectStowInquiry(stowInquiry);

		if (CollectionUtils.isEmpty(putList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		    }

		for (int i = 0; i < putList.size(); i++) {
			if(!StringUtils.isEmpty(putList.get(i).getDataReceivedDate())&&!StringUtils.isEmpty(putList.get(i).getCreateTime())){
				
				String oldDateTime1 = putList.get(i).getDataReceivedDate()+putList.get(i).getCreateTime();
				String dataReceivedDateTime=  CommonUtility.getDateTime1(oldDateTime1);
				String dataReceivedDateTime1 =  dataReceivedDateTime.substring(2, dataReceivedDateTime.length());
				putList.get(i).setDataReceivedDateTime(dataReceivedDateTime1);
				
			}
			if (StringUtils.isEmpty(putList.get(i).getExpectedQty())) {
				putList.get(i).setExpectedQty("");
			}
			if (StringUtils.isEmpty(putList.get(i).getResultQty())) {
				putList.get(i).setResultQty("");
			}
			if (!StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& !StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& !StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = putList.get(i).getDamagedQty() + "／" + putList.get(i).getExtraQty() + "／"
						+ putList.get(i).getMissingQty();
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (!StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = putList.get(i).getDamagedQty() + "／" + "／";
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (!StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& !StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = putList.get(i).getDamagedQty() + "／" + putList.get(i).getExtraQty() + "／";
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (!StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& !StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = putList.get(i).getDamagedQty() + "／" + "／" + putList.get(i).getMissingQty();
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& !StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& !StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = "／" + putList.get(i).getExtraQty() + "／" + putList.get(i).getMissingQty();
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (StringUtils.isEmpty(putList.get(i).getDamagedQty())
					&& !StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = "／" + putList.get(i).getExtraQty() + "／";
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}
			if (StringUtils.isEmpty(putList.get(i).getDamagedQty()) && StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& !StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				String str = "／" + "／" + putList.get(i).getMissingQty();
				putList.get(i).setDamagedQtyExtraQtyMissingQty(str);
			}

			if (StringUtils.isEmpty(putList.get(i).getDamagedQty()) && StringUtils.isEmpty(putList.get(i).getExtraQty())
					&& StringUtils.isEmpty(putList.get(i).getMissingQty())) {
				putList.get(i).setDamagedQtyExtraQtyMissingQty("");
			}
			if (!StringUtils.isEmpty(putList.get(i).getOperatedDate())
					&& !StringUtils.isEmpty(putList.get(i).getOperatedTime())) {
				String str = putList.get(i).getOperatedDate() + putList.get(i).getOperatedTime();
				String newstr = CommonUtility.getDateTime(str);
				putList.get(i).setOperatedDateTime(newstr);
			}
		}
		
		modelView.addObject("stowInquiryForm", stowInquiryForm);
		modelView.addObject("putList", putList);
		return modelView;
	}

	@RequestMapping(value = "/stow_inquiry", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("stowInquiryForm") StowInquiryForm stowInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- StowInquiryController.download() start ---");
		modelView.setViewName("/stow_inquiry");
		
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String dataReceivedDateStart = stowInquiryForm.getDataReceivedDateStart();
		String dataReceivedDateEnd = stowInquiryForm.getDataReceivedDateEnd();
		String dataReceivedTimeStart = stowInquiryForm.getDataReceivedTimeStart();
		String dataReceivedTimeEnd = stowInquiryForm.getDataReceivedTimeEnd();
		
		String operatedDateStart = stowInquiryForm.getOperatedDateStart();
		String operatedDateEnd = stowInquiryForm.getOperatedDateEnd();
		String operatedTimeStart = stowInquiryForm.getOperatedTimeStart();
		String operatedTimeEnd = stowInquiryForm.getOperatedTimeEnd();
		
		
		String containerId = stowInquiryForm.getContainerId();
		String expectedPutId = stowInquiryForm.getExpectedPutId();
		String workingStatus = stowInquiryForm.getWorkingStatus();
		String ppsId = stowInquiryForm.getPpsId();
		String irregularKind = stowInquiryForm.getIrregularKind();
		String irregularKindName = stowInquiryForm.getIrregularKindName();
		String sku = stowInquiryForm.getSku();
		String putKind = stowInquiryForm.getPutKind();
		String putKindName = stowInquiryForm.getPutKindName();

		if (StringUtils.isEmpty(dataReceivedTimeStart)) {
			dataReceivedTimeStart = "000000";
		} else {
			dataReceivedTimeStart = dataReceivedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(dataReceivedTimeEnd)) {
			dataReceivedTimeEnd = "235959";
		} else {
			dataReceivedTimeEnd = dataReceivedTimeEnd + "59";
		}
		
		if (StringUtils.isEmpty(dataReceivedDateEnd)) {
			dataReceivedDateEnd = dataReceivedDateStart;
		}
		if (!StringUtils.isEmpty(dataReceivedDateStart) && !StringUtils.isEmpty(dataReceivedDateEnd)) {
			
			if (CommonUtility.compareDateTime(dataReceivedDateStart + " "+ dataReceivedTimeStart, dataReceivedDateEnd + " "+ dataReceivedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String dataReceivedDate = messageSource.getMessage("stowInquiry.dataReceivedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("dataReceivedDate", dataReceivedDate);
				return modelView;
			}
		}
		
		if (StringUtils.isEmpty(operatedTimeStart)) {
			operatedTimeStart = "000000";
		} else {
			operatedTimeStart = operatedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(operatedTimeEnd)) {
			operatedTimeEnd = "235959";
		} else {
			operatedTimeEnd = operatedTimeEnd + "59";
		}
		if (!StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {
			
			if (CommonUtility.compareDateTime(operatedDateStart+" "+operatedTimeStart, operatedDateEnd+" "+operatedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("stowInquiry.operatedDate.message", null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
		} else if (!StringUtils.isEmpty(operatedDateStart) && StringUtils.isEmpty(operatedDateEnd)) {
			operatedDateEnd = operatedDateStart;
		} else if (StringUtils.isEmpty(operatedDateStart) && !StringUtils.isEmpty(operatedDateEnd)) {
			operatedDateStart = operatedDateEnd;
		} else {
			operatedDateStart = "";
			operatedDateEnd = "";
			
			operatedTimeStart = "";
			operatedTimeEnd = "";
		}
		
		StowInquiry stowInquiry = new StowInquiry();
		stowInquiry.setDataReceivedDateStart(dataReceivedDateStart);
		stowInquiry.setDataReceivedDateEnd(dataReceivedDateEnd);
		stowInquiry.setDataReceivedTimeStart(dataReceivedTimeStart);
		stowInquiry.setDataReceivedTimeEnd(dataReceivedTimeEnd);
					   
		stowInquiry.setOperatedDateStart(operatedDateStart);
		stowInquiry.setOperatedDateEnd(operatedDateEnd);
		stowInquiry.setOperatedDateTimeStart(operatedTimeStart);
		stowInquiry.setOperatedDateTimeEnd(operatedTimeEnd);
		
		stowInquiry.setContainerId(containerId);
		stowInquiry.setExpectedPutId(expectedPutId);
		stowInquiry.setSku(sku);
		stowInquiry.setWorkingStatus(workingStatus);
		stowInquiry.setPpsId(ppsId);
		stowInquiry.setIrregularKind(irregularKind);
		stowInquiry.setIrregularKindName(irregularKindName);
		stowInquiry.setPutKind(putKind);
		stowInquiry.setPutKindName(putKindName);
		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual=stowInquiryService.selectCountt(stowInquiry);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<StowInquiryCsv> stowInquiryCsvList = 
				stowInquiryService.findStowInquiryCsv(
						dataReceivedDateStart,dataReceivedDateEnd,
						dataReceivedTimeStart,dataReceivedTimeEnd,
						operatedDateStart, operatedDateEnd,
						operatedTimeStart,operatedTimeEnd,
						containerId,expectedPutId,workingStatus,
						ppsId,irregularKind,irregularKindName,
						sku,putKind,putKindName);
		
		if (CollectionUtils.isEmpty(stowInquiryCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/stow_inquiry");
			return modelView;
		}
		modelView.addObject("stowInquiryCsvList", stowInquiryCsvList);
		modelView.setViewName("StowInquiryCsvView");
		return modelView;
	}
	
	@RequestMapping(value = "/stow_inquiry", params = "action=clear")
	public String stowInquiryClear(Model model) throws ParseException {
		logger.info("--- stowInquiryClear() start ---");
		
		String operationDate = commonService.getOperationDate();
		StowInquiryForm form = new StowInquiryForm();
		form.setDataReceivedDateStart(operationDate);
		form.setDataReceivedDateEnd(operationDate);
		form.setDataReceivedTimeStart("0000");
		form.setDataReceivedTimeEnd("2359");
		model.addAttribute("stowInquiryForm", form);
		
		return "stow_inquiry";
	}

	@RequestMapping(value = "/stow_inquiry", params = "action=back")
	public String stowInquiryBack(Model model) {
		logger.info("--- stowInquiryBack() start ---");

		return "stow_menu";
	}

	
	@RequestMapping(value = "/stow_inquiry/{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getSkuName(@PathVariable String skuCode) {
		logger.info("--- StowInquiryController.getSkuName() start ---");
		
		String skuName = "";
		
		if (!StringUtils.isEmpty(skuCode)) {
			skuName = commonService.getSkuName(skuCode);
		} 

		return skuName;
	}

}
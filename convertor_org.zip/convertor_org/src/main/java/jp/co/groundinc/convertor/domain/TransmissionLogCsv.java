package jp.co.groundinc.convertor.domain;

public class TransmissionLogCsv {
	private String transmissionId;
	private String transmissionType;
	private String transmissionTypeName;
	private String transmissionTypeDetail;
	private String transmissionTypeDetailName;
	private String sendrecvKind;
	private String sendrecvKindName;
	private String processingStatus;
	private String processingStatusName;
	private String processedDate;
	private String processedTime;
	private String totalCount;
	private String errorCount;
	private String filePath;
	private String csvExportDate;
	private String csvExportTime;
	
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	public String getTransmissionId() {
		return transmissionId;
	}

	public void setTransmissionId(String transmissionId) {
		this.transmissionId = transmissionId;
	}

	public String getTransmissionTypeDetail() {
		return transmissionTypeDetail;
	}

	public void setTransmissionTypeDetail(String transmissionTypeDetail) {
		this.transmissionTypeDetail = transmissionTypeDetail;
	}

	public String getTransmissionType() {
		return transmissionType;
	}

	public void setTransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}

	public String getSendrecvKind() {
		return sendrecvKind;
	}

	public void setSendrecvKind(String sendrecvKind) {
		this.sendrecvKind = sendrecvKind;
	}

	public String getProcessingStatus() {
		return processingStatus;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getTransmissionTypeName() {
		return transmissionTypeName;
	}

	public void setTransmissionTypeName(String transmissionTypeName) {
		this.transmissionTypeName = transmissionTypeName;
	}

	public String getTransmissionTypeDetailName() {
		return transmissionTypeDetailName;
	}

	public void setTransmissionTypeDetailName(String transmissionTypeDetailName) {
		this.transmissionTypeDetailName = transmissionTypeDetailName;
	}

	public String getSendrecvKindName() {
		return sendrecvKindName;
	}

	public void setSendrecvKindName(String sendrecvKindName) {
		this.sendrecvKindName = sendrecvKindName;
	}

	public String getProcessingStatusName() {
		return processingStatusName;
	}

	public void setProcessingStatusName(String processingStatusName) {
		this.processingStatusName = processingStatusName;
	}

	public String getProcessedDate() {
		return processedDate;
	}

	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}

	public String getProcessedTime() {
		return processedTime;
	}

	public void setProcessedTime(String processedTime) {
		this.processedTime = processedTime;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}

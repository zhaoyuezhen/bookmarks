package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.StowInquiry;
import jp.co.groundinc.convertor.domain.StowInquiryCsv;
@Mapper
public interface StowInquiryMapper {

	List<StowInquiry> selectStowInquiry(StowInquiry stowInquiry);
	int selectCountt(StowInquiry stowInquiry);
	String selectproductName(String productcoder);
	List<StowInquiryCsv> selectStowInquiryCsv(
 			@Param("dataReceivedDateStart") String dataReceivedDateStart,
 			@Param("dataReceivedDateEnd") String dataReceivedDateEnd,
 			@Param("dataReceivedTimeStart") String dataReceivedTimeStart,
 			@Param("dataReceivedTimeEnd") String dataReceivedTimeEnd,
 			@Param("operatedDateStart") String operatedDateStart,
 			@Param("operatedDateEnd") String operatedDateEnd,
 			@Param("operatedDateTimeStart") String operatedDateTimeStart,
 			@Param("operatedDateTimeEnd") String operatedDateTimeEnd,
 			@Param("containerId") String containerId,
 			@Param("expectedPutId") String expectedPutId,
 			@Param("workingStatus") String workingStatus,
 			@Param("ppsId") String ppsId,
            @Param("irregularKind") String irregularKind,
            @Param("irregularKindName") String irregularKindName,
            @Param("sku") String sku,
            @Param("putKind") String putKind,
            @Param("putKindName") String putKindName);
}

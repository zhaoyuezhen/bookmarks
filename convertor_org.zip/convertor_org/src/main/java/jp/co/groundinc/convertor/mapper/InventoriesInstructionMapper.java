package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.groundinc.convertor.domain.InventoriesInstruction;
import jp.co.groundinc.convertor.domain.InventoriesInstructionReports;
@Mapper
public interface InventoriesInstructionMapper {
	String selectSlotCount(String sku);
	List<InventoriesInstruction> selectProductInfo(InventoriesInstruction inventoriesInstruction);
	String selectAuditSeqenceNext();
	String  selectAuditSeqence();
	void insertAuditExpectation(InventoriesInstruction inventoriesInstruction);
	void insertAuditExceptionDetail(InventoriesInstruction inventoriesInstruction);
	void insertAuditStock(InventoriesInstruction inventoriesInstruction);
	List<InventoriesInstruction> selectViewStockDetail(String sku);
	List<InventoriesInstruction> selectViewStockDetailLocation(String location);
	List<InventoriesInstruction> findLocationInfo(InventoriesInstruction inventoriesInstruction);
	int selectProductCount(InventoriesInstruction inventoriesInstruction);
	int selectSlotCountt(InventoriesInstruction inventoriesInstruction);
	
	List<InventoriesInstructionReports> selectInventoriesInstructionReports(
			@Param("Seqence") String Seqence);
	
}

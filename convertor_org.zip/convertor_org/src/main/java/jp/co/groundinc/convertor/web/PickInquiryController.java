package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.PickInquiry;
import jp.co.groundinc.convertor.domain.PickInquiryCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.PickInquiryService;
import jp.co.groundinc.convertor.web.form.PickInquiryForm;
import jp.co.groundinc.convertor.web.utility.DatePropertyEditor;
import jp.co.groundinc.convertor.web.utility.TimePropertyEditor;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class PickInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	PickInquiryService orderService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		
		dataBinder.registerCustomEditor(String.class, "datareceiveddateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "datareceiveddateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedTimeStart", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "dataReceivedTimeEnd", new TimePropertyEditor());
		
		dataBinder.registerCustomEditor(String.class, "expecteddateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "expecteddateEnd", new TimePropertyEditor());
		
		dataBinder.registerCustomEditor(String.class, "operateddateStart", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operateddateEnd", new DatePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operatedTimeStart", new TimePropertyEditor());
		dataBinder.registerCustomEditor(String.class, "operatedTimeEnd", new TimePropertyEditor());
	}

	@ModelAttribute("pickInquiryForm")
	public PickInquiryForm pickInquiryForm() {
		logger.info("--- PickInquiryController.pickInquiryForm() start ---");
		return new PickInquiryForm();
	}

	@ModelAttribute("binNo")
	public List<Translate> binNos() {
		logger.info("--- PickInquiryController.binNos() start ---");
		return commonService.getTranslateList("BinNo");
	}

	@ModelAttribute("ppsNo")
	public List<Translate> ppsNos() {
		logger.info("--- PickInquiryController.ppsNos() start ---");
		return commonService.getTranslateList("PpsNo");
	}

	@ModelAttribute("processingStatus")
	public List<Translate> processingStatus() {
		logger.info("--- PickInquiryController.processingStatus() start ---");
		return commonService.getTranslateList("ProcessingStatus");
	}

	@ModelAttribute("irregularKind")
	public List<Translate> irregularKind() {
		logger.info("--- PickInquiryController.irregularKind() start ---");
		return commonService.getTranslateList("IrregularKind");
	}
	
	@ModelAttribute("orderKind")
	public List<Translate> orderKind() {
		logger.info("--- PickInquiryController.orderKind() start ---");
		return commonService.getTranslateList("OrderKind");
	}

	@ModelAttribute("defaultArea")
	public List<Translate> defaultArea() {
		logger.info("--- PickInquiryController.defaultArea() start ---");
		return commonService.getTranslateList("DefaultArea");
	}

	@RequestMapping("/view_order")
	public ModelAndView viewOrder(ModelAndView modelView, HttpServletRequest request) throws ParseException {
		logger.info("--- PickInquiryController.vieworder() start ---");
		PickInquiryForm form = new PickInquiryForm();
		String operationDate = commonService.getOperationDate();
		
		form.setDatareceiveddateStart(operationDate);
		form.setDatareceiveddateEnd(operationDate);
		
		form.setDataReceivedTimeStart("0000");
		form.setDataReceivedTimeEnd("2359");
		
		
		List<Translate> List  = commonService.getTranslateList("OrderKind");
	    Translate translate  = List.get(3);
	    form.setOrderKind(translate.getTranslate_code());
	    String defTranslateCode = orderService.getDefTranslateCode(); 

		modelView.addObject("pickInquiryForm", form);
		modelView.addObject("translate_code", defTranslateCode);
		modelView.setViewName("/pick_inquiry");
		return modelView;
	}

	@RequestMapping(value = "/view_order", params = "action=clear")
	public ModelAndView viewOrderClear(HttpServletRequest request,ModelAndView modelView) throws ParseException {
		logger.info("--- viewOrderClear() start ---");
		PickInquiryForm form = new PickInquiryForm();
		String operationDate = commonService.getOperationDate();
		List<Translate> List  = commonService.getTranslateList("OrderKind");
	    Translate translate  = List.get(3);
	    form.setOrderKind(translate.getTranslate_code());
	    String defTranslateCode = orderService.getDefTranslateCode(); 
		modelView.addObject("translate_code", defTranslateCode);
		//カエン修正開始
		form.setDatareceiveddateStart(operationDate);
		form.setDatareceiveddateEnd(operationDate);
		form.setDataReceivedTimeStart("0000");
		form.setDataReceivedTimeEnd("2359");
		//カエン修正終了
		modelView.addObject("pickInquiryForm", form);
		modelView.setViewName("/pick_inquiry");
		return modelView;
	}

	@RequestMapping(value = "/view_order", params = "action=back")
	public String viewOrderBack(HttpServletRequest request, Model model) {
		logger.info("--- viewOrderBack() start ---");

		return "pick_menu";
	}

	@RequestMapping(value = "/view_order", params = "action=search")
	public ModelAndView selectPickinquiryInfo(
			@Validated @ModelAttribute("pickInquiryForm") PickInquiryForm pickInquiryForm, BindingResult result,
			ModelAndView modelView,HttpServletRequest request) {

		logger.info("--- selectPickinquiryInfo() start ---");
		modelView.setViewName("/pick_inquiry");
		modelView.addObject("translate_code",pickInquiryForm.getOrderKind());

		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String datareceivedateStart = pickInquiryForm.getDatareceiveddateStart();
		String datareceivedateEnd = pickInquiryForm.getDatareceiveddateEnd();
		String dataReceiveTimeStart = pickInquiryForm.getDataReceivedTimeStart();
		String dataReceiveTimeEnd = pickInquiryForm.getDataReceivedTimeEnd();
		
		String expectdateStart = pickInquiryForm.getExpecteddateStart();
		String expectdateEnd = pickInquiryForm.getExpecteddateEnd();
		
		String operateddateStart = pickInquiryForm.getOperateddateStart();
		String operateddateEnd = pickInquiryForm.getOperateddateEnd();
		String operatedTimeStart = pickInquiryForm.getOperatedTimeStart();
		String operatedTimeEnd = pickInquiryForm.getOperatedTimeEnd();
		
			
		String orderid = pickInquiryForm.getOrderid();
		String workstarts = pickInquiryForm.getWorkingstatus();
		String ppsid = pickInquiryForm.getPpsid();
		String ppsbinid = pickInquiryForm.getPpsbinid();
		String irregularKind = pickInquiryForm.getIrregularKind();
		String irregularKindName = pickInquiryForm.getIrregularKindName();
		String orderKind = pickInquiryForm.getOrderKind();
		String orderKindName = pickInquiryForm.getOrderKindName();
		String sku = pickInquiryForm.getSku();
        boolean allMissingFlag = pickInquiryForm.isAllMissingFlag();
        
        
		if (StringUtils.isEmpty(dataReceiveTimeStart)) {
			dataReceiveTimeStart = "000000";
		} else {
			dataReceiveTimeStart = dataReceiveTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(dataReceiveTimeEnd)) {
			dataReceiveTimeEnd = "235959";
		} else {
			dataReceiveTimeEnd = dataReceiveTimeEnd + "59";
		}
		
		if (StringUtils.isEmpty(datareceivedateEnd)) {
			datareceivedateEnd = datareceivedateStart;
		}
		if (!StringUtils.isEmpty(datareceivedateStart) && !StringUtils.isEmpty(datareceivedateEnd)) {

			if (CommonUtility.compareDateTime(datareceivedateStart + " "+ dataReceiveTimeStart, datareceivedateEnd + " "+ dataReceiveTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String datareceiveddateEnd = messageSource.getMessage("order.datareceiveddate.Datecomparison.message",
						null, Locale.JAPAN);
				modelView.addObject("datareceiveddateEnd", datareceiveddateEnd);
				return modelView;
			}
		}
		/***************************************************************************************/
		if (!StringUtils.isEmpty(expectdateStart) && !StringUtils.isEmpty(expectdateEnd)) {

			if (CommonUtility.comparedateStartafterEnd(expectdateStart, expectdateEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String expectdateEnds = messageSource.getMessage("order.expectdate.message", null, Locale.JAPAN);
				modelView.addObject("expectdateEnd", expectdateEnds);
				return modelView;
			}
		}
		
		if (!StringUtils.isEmpty(expectdateStart) || !StringUtils.isEmpty(expectdateEnd)) {			
			if (StringUtils.isEmpty(expectdateStart)) {
				expectdateEnd = CommonUtility.dateFomat(expectdateEnd);
				expectdateStart = expectdateEnd;
			}else if(StringUtils.isEmpty(expectdateEnd)){
				expectdateStart = CommonUtility.dateFomat(expectdateStart);
				expectdateEnd = expectdateStart;
			}else {
				expectdateStart = CommonUtility.dateFomat(expectdateStart);
				expectdateEnd = CommonUtility.dateFomat(expectdateEnd);
			}
		}
		/***************************************************************************************/
		if (StringUtils.isEmpty(operatedTimeStart)) {
			operatedTimeStart = "000000";
		} else {
			operatedTimeStart = operatedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(operatedTimeEnd)) {
			operatedTimeEnd = "235959";
		} else {
			operatedTimeEnd = operatedTimeEnd + "59";
		}
		if (!StringUtils.isEmpty(operateddateStart) && !StringUtils.isEmpty(operateddateEnd)) {
			
			if (CommonUtility.compareDateTime(operateddateStart+" "+operatedTimeStart, operateddateEnd+" "+operatedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatedDate = messageSource.getMessage("stowInquiry.operatedDate.message", null, Locale.JAPAN);
				modelView.addObject("operatedDate", operatedDate);
				return modelView;
			}
		} else if (!StringUtils.isEmpty(operateddateStart) && StringUtils.isEmpty(operateddateEnd)) {
			operateddateEnd = operateddateStart;
		} else if (StringUtils.isEmpty(operateddateStart) && !StringUtils.isEmpty(operateddateEnd)) {
			operateddateStart = operateddateEnd;
		} else {
			operateddateStart = "";
			operateddateEnd = "";
			
			operatedTimeStart = "";
			operatedTimeEnd = "";
		}
		PickInquiry pickInquiry = new PickInquiry();
		if(allMissingFlag){
			pickInquiry.setAllMissingFlag(CommonConstant.FLAG_ON);
		}
		else{
			pickInquiry.setAllMissingFlag(null);
		}
		pickInquiry.setDatareceiveddateStart(datareceivedateStart);
		pickInquiry.setDataReceivedtimeStart(dataReceiveTimeStart);
		pickInquiry.setDatareceiveddateEnd(datareceivedateEnd);
		pickInquiry.setDataReceivedtimeEnd(dataReceiveTimeEnd);		
		
		pickInquiry.setOperateddateStart(operateddateStart);
		pickInquiry.setOperatedTimeStart(operatedTimeStart);
		pickInquiry.setOperateddateEnd(operateddateEnd);
		pickInquiry.setOperatedTimeEnd(operatedTimeEnd);
		/***************************************************************************************/
		pickInquiry.setExpecteddateStart(expectdateStart);
		pickInquiry.setExpecteddateEnd(expectdateEnd);
		/***************************************************************************************/
		pickInquiry.setOrderid(orderid);
		pickInquiry.setWorkingstatus(workstarts);
		pickInquiry.setPpsid(ppsid);
		pickInquiry.setPpsbinid(ppsbinid);
		pickInquiry.setIrregularKind(irregularKind);
		pickInquiry.setIrregularKindName(irregularKindName);
		pickInquiry.setOrderKindName(orderKindName);
		pickInquiry.setSku(sku);
		
		pickInquiryForm.setDatareceiveddateStart(datareceivedateStart);
		pickInquiryForm.setDatareceiveddateEnd(datareceivedateEnd);
		pickInquiryForm.setDataReceivedTimeStart(dataReceiveTimeStart);
		pickInquiryForm.setDataReceivedTimeEnd(dataReceiveTimeEnd);
		
		pickInquiryForm.setOperateddateStart(operateddateStart);
		pickInquiryForm.setOperateddateEnd(operateddateEnd);
		pickInquiryForm.setOperatedTimeStart(operatedTimeStart);
		pickInquiryForm.setOperatedTimeEnd(operatedTimeEnd);
		
		if(!orderKind.equals("9")){
			pickInquiry.setOrderKind(orderKind);
		}
		
		int count  = commonService.selectTableUpperLimitCount();
		int countManual=orderService.selectCountt(pickInquiry);
		if(count <= countManual){	
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<PickInquiry> syukousyoulist = orderService.selectSyukokensakuinfo(pickInquiry);

		if (CollectionUtils.isEmpty(syukousyoulist)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;

		}
		for (int i = 0; i < syukousyoulist.size(); i++) {
           if(!StringUtils.isEmpty(syukousyoulist.get(i).getDatareceiveddate()) && !StringUtils.isEmpty(syukousyoulist.get(i).getCreateTime())){
				String oldDateTime = syukousyoulist.get(i).getDatareceiveddate() + syukousyoulist.get(i).getCreateTime();
				String newDateTime = CommonUtility.getDateTime(oldDateTime);
				String dataReceivedDateTime =  newDateTime.substring(2, newDateTime.length());
				syukousyoulist.get(i).setDataReceivedDateTime(dataReceivedDateTime);
				
			}
			if (!StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = syukousyoulist.get(i).getExpectedqty() + "／" + syukousyoulist.get(i).getResultqty() + "／"
						+ syukousyoulist.get(i).getMissingqty();
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (!StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = syukousyoulist.get(i).getExpectedqty() + "／" + "／";
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (!StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = syukousyoulist.get(i).getExpectedqty() + "／" + syukousyoulist.get(i).getResultqty() + "／";
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (!StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = syukousyoulist.get(i).getExpectedqty() + "／" + "／" + syukousyoulist.get(i).getMissingqty();
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = "／" + syukousyoulist.get(i).getResultqty() + "／" + syukousyoulist.get(i).getMissingqty();
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = "／" + syukousyoulist.get(i).getResultqty() + "／";
				syukousyoulist.get(i).setYjk(yjk);
			}
			if (StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				String yjk = "／" + "／" + syukousyoulist.get(i).getMissingqty();
				syukousyoulist.get(i).setYjk(yjk);
			}

			if (StringUtils.isEmpty(syukousyoulist.get(i).getExpectedqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getResultqty())
					&& StringUtils.isEmpty(syukousyoulist.get(i).getMissingqty())) {
				syukousyoulist.get(i).setYjk("");
			}

			if (!StringUtils.isEmpty(syukousyoulist.get(i).getOperateddate())
					&& !StringUtils.isEmpty(syukousyoulist.get(i).getOperatedtime())) {
				String str = syukousyoulist.get(i).getOperateddate() + syukousyoulist.get(i).getOperatedtime();
				String newstr = CommonUtility.getDateTime(str);
				syukousyoulist.get(i).setOperatedDateTime(newstr);
			}

		}
		modelView.addObject("pickInquiryForm", pickInquiryForm);
		modelView.addObject("syukousyoulist", syukousyoulist);
		return modelView;
	}
	
	@RequestMapping(value = "/view_order", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("pickInquiryForm") PickInquiryForm pickInquiryForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- PickInquiryController.download() start ---");
		modelView.addObject("translate_code",pickInquiryForm.getOrderKind());
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.setViewName("/pick_inquiry");
			modelView.addObject("validationMessage", message);
			return modelView;
		}		
		String datareceivedateStart = pickInquiryForm.getDatareceiveddateStart();
		String datareceivedateEnd = pickInquiryForm.getDatareceiveddateEnd();
		String dataReceiveTimeStart = pickInquiryForm.getDataReceivedTimeStart();
		String dataReceiveTimeEnd = pickInquiryForm.getDataReceivedTimeEnd();
		
		String expecteddateStart = pickInquiryForm.getExpecteddateStart();
		String expecteddateEnd = pickInquiryForm.getExpecteddateEnd();
		
		String operateddateStart = pickInquiryForm.getOperateddateStart();
		String operateddateEnd = pickInquiryForm.getOperateddateEnd();
		String operatedTimeStart = pickInquiryForm.getOperatedTimeStart();
		String operatedTimeEnd = pickInquiryForm.getOperatedTimeEnd();
		
		
		/*String datareceiveddateStart = pickInquiryForm.getDatareceiveddateStart();
		String datareceiveddateEnd = pickInquiryForm.getDatareceiveddateEnd();
		String expecteddateStart = pickInquiryForm.getExpecteddateStart();
		String expecteddateEnd = pickInquiryForm.getExpecteddateEnd();
		String operateddateStart = pickInquiryForm.getOperateddateStart();
		String operateddateEnd = pickInquiryForm.getOperateddateEnd();*/
		String orderid = pickInquiryForm.getOrderid();
		String workingstatus = pickInquiryForm.getWorkingstatus();
		String ppsid = pickInquiryForm.getPpsid();
		String ppsbinid = pickInquiryForm.getPpsbinid();
		String irregularKind = pickInquiryForm.getIrregularKind();
		String irregularKindName = pickInquiryForm.getIrregularKindName();
		String orderKind = pickInquiryForm.getOrderKind();
		String orderKindName = pickInquiryForm.getOrderKindName();
		String sku = pickInquiryForm.getSku();
		boolean allMissingFlag = pickInquiryForm.isAllMissingFlag();
		
		PickInquiry pickInquiry = new PickInquiry();
		
		
		if (StringUtils.isEmpty(dataReceiveTimeStart)) {
			dataReceiveTimeStart = "000000";
		} else {
			dataReceiveTimeStart = dataReceiveTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(dataReceiveTimeEnd)) {
			dataReceiveTimeEnd = "235959";
		} else {
			dataReceiveTimeEnd = dataReceiveTimeEnd + "59";
		}
		
		if (StringUtils.isEmpty(datareceivedateEnd)) {
			datareceivedateEnd = datareceivedateStart;
		}
		if (!StringUtils.isEmpty(datareceivedateStart) && !StringUtils.isEmpty(datareceivedateEnd)) {

			if (CommonUtility.compareDateTime(datareceivedateStart + " "+ dataReceiveTimeStart, datareceivedateEnd + " "+ dataReceiveTimeEnd)) {
				modelView.setViewName("/pick_inquiry");
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String dataReceivedDate = messageSource.getMessage("stowInquiry.dataReceivedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("datareceiveddateEnd", dataReceivedDate);

				return modelView;
			}
		}
		/**************************************************************************************************************/
		if (!StringUtils.isEmpty(expecteddateStart) && !StringUtils.isEmpty(expecteddateEnd)) {

			if (CommonUtility.comparedateStartafterEnd(expecteddateStart, expecteddateEnd)) {
				modelView.setViewName("/pick_inquiry");
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String expectdateEnds = messageSource.getMessage("order.expectdate.message", null, Locale.JAPAN);
				modelView.addObject("expectdateEnd", expectdateEnds);
				return modelView;
			}
		}
		
		if (!StringUtils.isEmpty(expecteddateStart) || !StringUtils.isEmpty(expecteddateEnd)) {			
			if (StringUtils.isEmpty(expecteddateStart)) {
				expecteddateEnd = CommonUtility.dateFomat(expecteddateEnd);
				expecteddateStart = expecteddateEnd;
			}else if(StringUtils.isEmpty(expecteddateEnd)){
				expecteddateStart = CommonUtility.dateFomat(expecteddateStart);
				expecteddateEnd = expecteddateStart;
			}else {
				expecteddateStart = CommonUtility.dateFomat(expecteddateStart);
				expecteddateEnd = CommonUtility.dateFomat(expecteddateEnd);
			}
		}
		/**************************************************************************************************************/

		if (StringUtils.isEmpty(operatedTimeStart)) {
			operatedTimeStart = "000000";
		} else {
			operatedTimeStart = operatedTimeStart + "00";
		}
	
		if (StringUtils.isEmpty(operatedTimeEnd)) {
			operatedTimeEnd = "235959";
		} else {
			operatedTimeEnd = operatedTimeEnd + "59";
		}
		if (!StringUtils.isEmpty(operateddateStart) && !StringUtils.isEmpty(operateddateEnd)) {
			
			if (CommonUtility.compareDateTime(operateddateStart+" "+operatedTimeStart, operateddateEnd+" "+operatedTimeEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String operatdateEnds = messageSource.getMessage("order.operatdate.message", null, Locale.JAPAN);
				modelView.addObject("operatdateEnd", operatdateEnds);
				modelView.setViewName("/pick_inquiry");
				return modelView;
			}
		} else if (!StringUtils.isEmpty(operateddateStart) && StringUtils.isEmpty(operateddateEnd)) {
			operateddateEnd = operateddateStart;
		} else if (StringUtils.isEmpty(operateddateStart) && !StringUtils.isEmpty(operateddateEnd)) {
			operateddateStart = operateddateEnd;
		} else {
			operateddateStart = "";
			operateddateEnd = "";
			
			operatedTimeStart = "";
			operatedTimeEnd = "";
		}

		pickInquiry.setDatareceiveddateStart(datareceivedateStart);
		pickInquiry.setDatareceiveddateEnd(datareceivedateEnd);
		pickInquiry.setDataReceivedtimeStart(dataReceiveTimeStart);
		pickInquiry.setDataReceivedtimeEnd(dataReceiveTimeEnd);
		
		pickInquiry.setOperateddateStart(operateddateStart);
		pickInquiry.setOperateddateEnd(operateddateEnd);		
		pickInquiry.setOperatedTimeStart(operatedTimeStart);
		pickInquiry.setOperatedTimeEnd(operatedTimeEnd);
		
		pickInquiry.setExpecteddateStart(expecteddateStart);
		pickInquiry.setExpecteddateEnd(expecteddateEnd);
		pickInquiry.setOrderid(orderid);
		pickInquiry.setWorkingstatus(workingstatus);
		pickInquiry.setPpsid(ppsid);
		pickInquiry.setPpsbinid(ppsbinid);
		pickInquiry.setIrregularKind(irregularKind);
		pickInquiry.setIrregularKindName(irregularKindName);
		pickInquiry.setOrderKindName(orderKindName);
		pickInquiry.setSku(sku);

		String flag;
		if(allMissingFlag){
			pickInquiry.setAllMissingFlag(CommonConstant.FLAG_ON);
			flag = CommonConstant.FLAG_ON;
		}
		else{
			pickInquiry.setAllMissingFlag(null);
			flag = null;
		}
		if(orderKind.equals("9")){
			orderKind = null;			
		}else {
			pickInquiry.setOrderKind(orderKind);
		}
		
		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual=orderService.selectCountt(pickInquiry);
		if(count <= countManual){	
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/pick_inquiry");
			return modelView;
		}
		
		List<PickInquiryCsv> pickInquiryCsvList = 
				      orderService.findPickInquiryCsv(
				    		  datareceivedateStart, datareceivedateEnd, dataReceiveTimeStart,dataReceiveTimeEnd,expecteddateStart, expecteddateEnd,
				    		  operateddateStart,operateddateEnd,operatedTimeStart,operatedTimeEnd,
						orderid,workingstatus,ppsid,ppsbinid,irregularKind,irregularKindName,orderKind,orderKindName,sku,flag);
		
		if (CollectionUtils.isEmpty(pickInquiryCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/pick_inquiry");
			return modelView;
		}
		
		modelView.addObject("pickInquiryCsvList", pickInquiryCsvList);
		modelView.setViewName("PickInquiryCsvView");
		
		return modelView;
	}

	@RequestMapping(value = "/view_order/{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getSkuName(@PathVariable String skuCode) {
		logger.info("--- PickInquiryController.getSkuName() start ---");
		
		String skuName = "";
		
		if (!StringUtils.isEmpty(skuCode)) {
			skuName = commonService.getSkuName(skuCode);
		} 

		return skuName;
	}
}

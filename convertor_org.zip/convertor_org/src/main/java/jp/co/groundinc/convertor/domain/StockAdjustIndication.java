package jp.co.groundinc.convertor.domain;

public class StockAdjustIndication {

	private String skuStart;

	private String skuEnd;
	
	private String sku;
	
	private String skuDetail;
	
	private String auditParamValueFrom;

	private String auditParamValueTo;
	
	private String auditParamValue;

	private String auditType;

	private String targetSlotCount;

	private String auditStockKind;

	private String startDate;

	private String startTime;

	private String createUser;

	private String createDate;

	private String createTime;

	private String updateUser;

	private String updateDate;

	private String updateTime;

	private String skuName;

	private int slotCount;

	private int stockQty;

	private String auditNo;
	
	private String sendStatus;
	
	private String  location;
	
	private String  locationStart;
	
	private String  locationEnd;
	
	private int skuCount;
	
	private String msuSideStart;
	private String msuStepStart;
	private String msuIdEnd;
	private String msuSideEnd;
	private String msuStepEnd;
	private String msuIdStart;
	
	public String getMsuSideStart() {
		return msuSideStart;
	}

	public void setMsuSideStart(String msuSideStart) {
		this.msuSideStart = msuSideStart;
	}

	public String getMsuStepStart() {
		return msuStepStart;
	}

	public void setMsuStepStart(String msuStepStart) {
		this.msuStepStart = msuStepStart;
	}

	public String getMsuIdEnd() {
		return msuIdEnd;
	}

	public void setMsuIdEnd(String msuIdEnd) {
		this.msuIdEnd = msuIdEnd;
	}

	public String getMsuSideEnd() {
		return msuSideEnd;
	}

	public void setMsuSideEnd(String msuSideEnd) {
		this.msuSideEnd = msuSideEnd;
	}

	public String getMsuStepEnd() {
		return msuStepEnd;
	}

	public void setMsuStepEnd(String msuStepEnd) {
		this.msuStepEnd = msuStepEnd;
	}

	public String getMsuIdStart() {
		return msuIdStart;
	}

	public void setMsuIdStart(String msuIdStart) {
		this.msuIdStart = msuIdStart;
	}

	public int getSkuCount() {
		return skuCount;
	}

	public void setSkuCount(int skuCount) {
		this.skuCount = skuCount;
	}

	public String getLocationStart() {
		return locationStart;
	}

	public void setLocationStart(String locationStart) {
		this.locationStart = locationStart;
	}

	public String getLocationEnd() {
		return locationEnd;
	}

	public void setLocationEnd(String locationEnd) {
		this.locationEnd = locationEnd;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getAuditParamValue() {
		return auditParamValue;
	}

	public void setAuditParamValue(String auditParamValue) {
		this.auditParamValue = auditParamValue;
	}

	public String getSkuDetail() {
		return skuDetail;
	}

	public void setSkuDetail(String skuDetail) {
		this.skuDetail = skuDetail;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getAuditType() {
		return auditType;
	}

	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	public String getTargetSlotCount() {
		return targetSlotCount;
	}

	public void setTargetSlotCount(String targetSlotCount) {
		this.targetSlotCount = targetSlotCount;
	}

	public String getAuditStockKind() {
		return auditStockKind;
	}

	public void setAuditStockKind(String auditStockKind) {
		this.auditStockKind = auditStockKind;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

	public String getSkuStart() {
		return skuStart;
	}

	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}

	public String getSkuEnd() {
		return skuEnd;
	}

	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}

	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}

	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}

	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}

	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public int getSlotCount() {
		return slotCount;
	}

	public void setSlotCount(int slotCount) {
		this.slotCount = slotCount;
	}

	public int getStockQty() {
		return stockQty;
	}

	public void setStockQty(int stockQty) {
		this.stockQty = stockQty;
	}

}

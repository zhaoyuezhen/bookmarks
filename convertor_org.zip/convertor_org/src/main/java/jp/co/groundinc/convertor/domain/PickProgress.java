package jp.co.groundinc.convertor.domain;

import javax.validation.constraints.NotNull;

public class PickProgress {
	private static final long serialVersionUID = 1L;

	private String expecteddate;
	@NotNull(message = "{Pick.search.expecteddatestart.empty.message}")
	private String expecteddatestart;
	private String expecteddateend;
	private String orderprogresskey;
	private String orderprogresskeyname;
	private String totalExpectedCount;
	private String totalCompletedCount;
	private String totalIncompletedCount;
	private String completedRate;
	private String orderKindName;
	private String orderKind;
	private String orderAreaKind;
	private String orderAreaKindName;
	private String butlerRatio;
	
	public String getButlerRatio() {
		return butlerRatio;
	}

	public void setButlerRatio(String butlerRatio) {
		this.butlerRatio = butlerRatio;
	}

	public String getOrderAreaKind() {
		return orderAreaKind;
	}

	public void setOrderAreaKind(String orderAreaKind) {
		this.orderAreaKind = orderAreaKind;
	}

	public String getOrderAreaKindName() {
		return orderAreaKindName;
	}

	public void setOrderAreaKindName(String orderAreaKindName) {
		this.orderAreaKindName = orderAreaKindName;
	}

	public String getOrderKindName() {
		return orderKindName;
	}

	public void setOrderKindName(String orderKindName) {
		this.orderKindName = orderKindName;
	}

	public String getOrderKind() {
		return orderKind;
	}

	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}

	public String getExpecteddate() {
		return expecteddate;
	}

	public void setExpecteddate(String expecteddate) {
		this.expecteddate = expecteddate;
	}

	public String getExpecteddatestart() {
		return expecteddatestart;
	}

	public void setExpecteddatestart(String expecteddatestart) {
		this.expecteddatestart = expecteddatestart;
	}

	public String getExpecteddateend() {
		return expecteddateend;
	}

	public void setExpecteddateend(String expecteddateend) {
		this.expecteddateend = expecteddateend;
	}

	public String getOrderprogresskey() {
		return orderprogresskey;
	}

	public void setOrderprogresskey(String orderprogresskey) {
		this.orderprogresskey = orderprogresskey;
	}

	public String getOrderprogresskeyname() {
		return orderprogresskeyname;
	}

	public void setOrderprogresskeyname(String orderprogresskeyname) {
		this.orderprogresskeyname = orderprogresskeyname;
	}

	public String getTotalExpectedCount() {
		return totalExpectedCount;
	}

	public void setTotalExpectedCount(String totalExpectedCount) {
		this.totalExpectedCount = totalExpectedCount;
	}

	public String getTotalCompletedCount() {
		return totalCompletedCount;
	}

	public void setTotalCompletedCount(String totalCompletedCount) {
		this.totalCompletedCount = totalCompletedCount;
	}

	public String getTotalIncompletedCount() {
		return totalIncompletedCount;
	}

	public void setTotalIncompletedCount(String totalIncompletedCount) {
		this.totalIncompletedCount = totalIncompletedCount;
	}

	public String getCompletedRate() {
		return completedRate;
	}

	public void setCompletedRate(String completedRate) {
		this.completedRate = completedRate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

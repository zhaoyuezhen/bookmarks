package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.domain.StockInquiry;
import jp.co.groundinc.convertor.domain.StockInquiryCsv;
import jp.co.groundinc.convertor.domain.StockInquiryDetail;
import jp.co.groundinc.convertor.mapper.StockInquiryMapper;

@Service
@EnableAutoConfiguration
public class StockInquiryService {
	@Autowired
	StockInquiryMapper stockInquiryMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<StockInquiry> findStockInquiryInfo(StockInquiry stockInquiry) {
		logger.info("--- StockInquiryService.findStockInquiryInfo() start ---");
		List<StockInquiry> StockInquiryList = stockInquiryMapper.selectStockInquiryInfo(stockInquiry);
		return StockInquiryList;
	}
	public int selectCountt(StockInquiry stockInquiry) {
		logger.info("--- StockInquiryService.selectCountt() start ---");
		int count = stockInquiryMapper.selectCountt(stockInquiry);
		return count;
	}

	public List<StockInquiryDetail> findStockInquiryDetailInfo(String sku) {
		logger.info("--- StockInquiryService.findStockInquiryDetailInfo() start ---");
		List<StockInquiryDetail> StockInquiryDetailList = stockInquiryMapper.selectStockInquiryDetailInfo(sku);
		return StockInquiryDetailList;
	}
	
	public StockInquiry findStockInquiryInfo(String sku) {
		logger.info("--- StockInquiryService.findStockInquiryDetailInfo() start ---");
		StockInquiry  stockInquiry = stockInquiryMapper.selectStockInquiryInfos(sku);
		return stockInquiry;
	}
	
	public List<StockInquiryCsv> findStockInquiryCsv(
			String skuStart, String skuEnd, 
			String skuName, String totalCbmUnder,
			String totalCbmAbove, String retentionDays) {
		logger.info("--- StockInquiryService.findStockInquiryCsv() start ---");
		
		List<StockInquiryCsv> stockInquiryCsvList = 
				stockInquiryMapper.selectStockInquiryCsv(
						skuStart, skuEnd, skuName,totalCbmUnder,totalCbmAbove,retentionDays);
		
		return stockInquiryCsvList;
	}
	public String productName(String productCoder) {
		String productname = stockInquiryMapper.selectproductName(productCoder);
		return productname;
	}
}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.PickProgress;
import jp.co.groundinc.convertor.mapper.PickProgressMapper;

@Service
public class PickProgressService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	PickProgressMapper pickProgressMapper;
	@Autowired
	CommonUtility commonUtility;

	public List<PickProgress> findPickProgressA(PickProgress pickProgress) {
		logger.info("--- PickProgressService.findPickProgress() start ---");
		String starDate = CommonUtility.dateFomat(pickProgress.getExpecteddatestart());
		String endDate = CommonUtility.dateFomat(pickProgress.getExpecteddateend());
		pickProgress.setExpecteddatestart(starDate);
		pickProgress.setExpecteddateend(endDate);
		List<PickProgress> pickListA = pickProgressMapper.findPickProgressA(pickProgress);
		return pickListA;
	}
	
	public List<PickProgress> findPickProgressB(PickProgress pickProgress) {
		logger.info("--- PickProgressService.findPickProgress() start ---");
		String starDate = CommonUtility.dateFomat(pickProgress.getExpecteddatestart());
		String endDate = CommonUtility.dateFomat(pickProgress.getExpecteddateend());
		pickProgress.setExpecteddatestart(starDate);
		pickProgress.setExpecteddateend(endDate);
		
		List<PickProgress> pickListB = pickProgressMapper.findPickProgressB(pickProgress);
		return pickListB;
	}
	
	public List<PickProgress> findPickProgress(PickProgress pickProgress) {
		logger.info("--- PickProgressService.findPickProgress() start ---");
		String starDate = CommonUtility.dateFomat(pickProgress.getExpecteddatestart());
		String endDate = CommonUtility.dateFomat(pickProgress.getExpecteddateend());
		pickProgress.setExpecteddatestart(starDate);
		pickProgress.setExpecteddateend(endDate);
		
		List<PickProgress> pickList = pickProgressMapper.findPickProgress(pickProgress);
		return pickList;
	}
	
	public List<PickProgress> findButler(PickProgress pickProgress) {
		logger.info("--- PickProgressService.findButler() start ---");
		String starDate = CommonUtility.dateFomat(pickProgress.getExpecteddatestart());
		String endDate = CommonUtility.dateFomat(pickProgress.getExpecteddateend());
		pickProgress.setExpecteddatestart(starDate);
		pickProgress.setExpecteddateend(endDate);
		
		List<PickProgress> butlerList = pickProgressMapper.findButlerList(pickProgress);
		return butlerList;
	}
	
	public int selectCountt(PickProgress pickProgress) {

		String starDate = CommonUtility.dateFomat(pickProgress.getExpecteddatestart());
		String endDate = CommonUtility.dateFomat(pickProgress.getExpecteddateend());
		pickProgress.setExpecteddatestart(starDate);
		pickProgress.setExpecteddateend(endDate);
		
		int count = pickProgressMapper.selectCountt(pickProgress);
		return count;

	}
	
	public String  getDefTranslateCode(){
		String TranslateCode =  pickProgressMapper.getDefTranslateCode();
		return TranslateCode;
	}
}


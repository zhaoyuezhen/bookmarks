package jp.co.groundinc.convertor.domain;

public class AuditInquiryDetailReports {

	
	private String auditNo;
	
	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

}

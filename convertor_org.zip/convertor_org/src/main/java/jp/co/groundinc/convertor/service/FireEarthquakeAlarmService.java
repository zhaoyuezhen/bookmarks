package jp.co.groundinc.convertor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

@Service
@EnableAutoConfiguration
public class FireEarthquakeAlarmService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OAuth2RestTemplate restTemplate;

	@Value("${webapi.butler-core-api.url}")
	private String apiUrl;
	
	public boolean alert() {
		boolean result = true;
		
		try {
			String url = apiUrl + "/fire_emergency_alert";
			logger.info("--- FireEarthquakeAlarmService.alert() Call webapi start ---");
			restTemplate.postForLocation(url, null);
			logger.info("--- FireEarthquakeAlarmService.alert() Call webapi end ---");
		} catch(RestClientException e) {
			logger.error("--- FireEarthquakeAlarmService.alert()" + e.getMessage());
			result = false;
		}
		return result;
	}
}

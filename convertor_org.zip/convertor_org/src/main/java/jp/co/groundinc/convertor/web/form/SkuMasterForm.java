package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.Pattern;

public class SkuMasterForm {
	
	/**商品コード*/
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{skuMaster.product.Halfangle.message}")
	private String sku;
	
	private String skug[];
	
	/**商品名*/
	private String skuName;
	
	private String updateUser;
	
	private String updateDate;
	
	private String updateTime;
	
	private String updateDateTime;
	
	private String deletionKind;
	
	private String deletionKindName;
	
	private String checkStatus;
	
	private String checkStatusName;
	
	private String checkFlag;
	
	private String logisticsCbm;
	
	private String logisticsSkuWeight;
	
	private String cbm;
	
	private String skuKind;
	
	/** 梱包幅*/
	private String skuWidth;
	
	/** 梱包奥行*/
	private String skuDepth;
	
	/** 梱包高さ*/
	private String skuHeight;
	
	/** 重量*/
	private String skuWeight;
	
	/** スキャニングコード*/
	private String scanningCode;

	private String skuImageUrl;
	
	private String stockStatus;
	
	private String stockStatusName;
	
    private String logisticsSkuName;
	
	private String logisticsSkuKind;
	
	private String logisticsSkuWidth;
	
	private String logisticsSkuDepth;
	
	private String logisticsSkuHeight;
	
	private String logisticsScanningCode;
	
	private String logisticsSkuImageUrl;
	
	public String getStockStatusName() {
		return stockStatusName;
	}
	public void setStockStatusName(String stockStatusName) {
		this.stockStatusName = stockStatusName;
	}
	public String getDeletionKindName() {
		return deletionKindName;
	}
	public void setDeletionKindName(String deletionKindName) {
		this.deletionKindName = deletionKindName;
	}
	public String getCheckStatusName() {
		return checkStatusName;
	}
	public void setCheckStatusName(String checkStatusName) {
		this.checkStatusName = checkStatusName;
	}
	public String[] getSkug() {
		return skug;
	}
	public void setSkug(String[] skug) {
		this.skug = skug;
	}
	public String getLogisticsSkuName() {
		return logisticsSkuName;
	}
	public void setLogisticsSkuName(String logisticsSkuName) {
		this.logisticsSkuName = logisticsSkuName;
	}
	
	public String getLogisticsSkuKind() {
		return logisticsSkuKind;
	}
	public void setLogisticsSkuKind(String logisticsSkuKind) {
		this.logisticsSkuKind = logisticsSkuKind;
	}
	public String getLogisticsSkuWidth() {
		return logisticsSkuWidth;
	}
	public void setLogisticsSkuWidth(String logisticsSkuWidth) {
		this.logisticsSkuWidth = logisticsSkuWidth;
	}
	public String getLogisticsSkuDepth() {
		return logisticsSkuDepth;
	}
	public void setLogisticsSkuDepth(String logisticsSkuDepth) {
		this.logisticsSkuDepth = logisticsSkuDepth;
	}
	public String getLogisticsSkuHeight() {
		return logisticsSkuHeight;
	}
	public void setLogisticsSkuHeight(String logisticsSkuHeight) {
		this.logisticsSkuHeight = logisticsSkuHeight;
	}
	public String getLogisticsScanningCode() {
		return logisticsScanningCode;
	}
	public void setLogisticsScanningCode(String logisticsScanningCode) {
		this.logisticsScanningCode = logisticsScanningCode;
	}
	public String getLogisticsSkuImageUrl() {
		return logisticsSkuImageUrl;
	}
	public void setLogisticsSkuImageUrl(String logisticsSkuImageUrl) {
		this.logisticsSkuImageUrl = logisticsSkuImageUrl;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSkuImageUrl() {
		return skuImageUrl;
	}
	public void setSkuImageUrl(String skuImageUrl) {
		this.skuImageUrl = skuImageUrl;
	}
	public String getCheckFlag() {
		return checkFlag;
	}
	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}
	public String getDeletionKind() {
		return deletionKind;
	}
	public void setDeletionKind(String deletionKind) {
		this.deletionKind = deletionKind;
	}
	public String getCheckStatus() {
		return checkStatus;
	}
	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(String updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public String getStockStatus() {
		return stockStatus;
	}
	public void setStockStatus(String stockStatus) {
		this.stockStatus = stockStatus;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getLogisticsCbm() {
		return logisticsCbm;
	}
	public void setLogisticsCbm(String logisticsCbm) {
		this.logisticsCbm = logisticsCbm;
	}
	public String getLogisticsSkuWeight() {
		return logisticsSkuWeight;
	}
	public void setLogisticsSkuWeight(String logisticsSkuWeight) {
		this.logisticsSkuWeight = logisticsSkuWeight;
	}
	public String getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(String skuWidth) {
		this.skuWidth = skuWidth;
	}
	public String getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(String skuDepth) {
		this.skuDepth = skuDepth;
	}
	public String getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(String skuHeight) {
		this.skuHeight = skuHeight;
	}
	public String getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(String skuWeight) {
		this.skuWeight = skuWeight;
	}
	
}

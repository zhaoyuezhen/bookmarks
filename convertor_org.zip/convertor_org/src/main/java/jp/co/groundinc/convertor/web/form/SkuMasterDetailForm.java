package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.Pattern;

import org.springframework.web.multipart.MultipartFile;

public class SkuMasterDetailForm {

	private String skuy;
	
	private String skuName;
	
	private String cbm;
	
	private String skuKind;
	
	private String skuWidth;
	
	private String skuDepth;
	
	private String skuHeight;
	
	private String skuWeight;
	
	private String scanningCode;

	private String skuImageUrl;
	
	private String checkStatus;
	
	private String updateUser; 
	
	private String deletionKind;
	
	private String logisticsSkuName;
	
	private String logisticsCbm;
	
	private MultipartFile skuImageFile;

	private String logisticsSkuKind;
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String logisticsSkuWidth;
	
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String logisticsSkuDepth;
	
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String logisticsSkuHeight;
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String logisticsSkuWeight;
	
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{skuMasterDetail.update.AlphaNumeric.message}")
	private String logisticsScanningCode;
	
	/**割れ物*/
	private String fragileFlag;
	/**保管方向*/
	private String stockDirection;
	/**スタック可否*/
	private String stackingFlag;
	/**ネスト可否*/
	private String nestingFlag;
	/**ネスト方向*/
	private String nestingDirection;
	/**ストレージタイプ*/
	private String slotType;
	/**保管タイプ*/
	private String storeType;
	
	/**最大スタック数*/
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String maxStacableCount;
	
	/**最大ネスト数*/
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String maxNestingCount;
	/**ネスト増数*/
	@Pattern(regexp = "[0-9]*", message = "{skuMasterDetail.update.Number.message}")
	private String nestingIncrementCount;
	/**論理削除*/
	private String logicalDeletionFlag;
	

	public String getStoreType() {
		return storeType;
	}
	public void setStoreType(String storeType) {
		this.storeType = storeType;
	}
	public String getLogicalDeletionFlag() {
		return logicalDeletionFlag;
	}
	public void setLogicalDeletionFlag(String logicalDeletionFlag) {
		this.logicalDeletionFlag = logicalDeletionFlag;
	}
	public String getFragileFlag() {
		return fragileFlag;
	}
	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}
	public String getStockDirection() {
		return stockDirection;
	}
	public void setStockDirection(String stockDirection) {
		this.stockDirection = stockDirection;
	}
	public String getStackingFlag() {
		return stackingFlag;
	}
	public void setStackingFlag(String stackingFlag) {
		this.stackingFlag = stackingFlag;
	}
	public String getNestingFlag() {
		return nestingFlag;
	}
	public void setNestingFlag(String nestingFlag) {
		this.nestingFlag = nestingFlag;
	}
	public String getNestingDirection() {
		return nestingDirection;
	}
	public void setNestingDirection(String nestingDirection) {
		this.nestingDirection = nestingDirection;
	}
	public String getSlotType() {
		return slotType;
	}
	public void setSlotType(String slotType) {
		this.slotType = slotType;
	}
	public String getMaxStacableCount() {
		return maxStacableCount;
	}
	public void setMaxStacableCount(String maxStacableCount) {
		this.maxStacableCount = maxStacableCount;
	}
	public String getMaxNestingCount() {
		return maxNestingCount;
	}
	public void setMaxNestingCount(String maxNestingCount) {
		this.maxNestingCount = maxNestingCount;
	}
	public String getNestingIncrementCount() {
		return nestingIncrementCount;
	}
	public void setNestingIncrementCount(String nestingIncrementCount) {
		this.nestingIncrementCount = nestingIncrementCount;
	}
	
	
	private String logisticsSkuImageUrl;
	
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getDeletionKind() {
		return deletionKind;
	}
	public void setDeletionKind(String deletionKind) {
		this.deletionKind = deletionKind;
	}
	public String getCheckStatus() {
		return checkStatus;
	}
	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}
	public String getLogisticsSkuName() {
		return logisticsSkuName;
	}
	public void setLogisticsSkuName(String logisticsSkuName) {
		this.logisticsSkuName = logisticsSkuName;
	}
	public String getLogisticsCbm() {
		return logisticsCbm;
	}
	public void setLogisticsCbm(String logisticsCbm) {
		this.logisticsCbm = logisticsCbm;
	}
	public String getLogisticsSkuKind() {
		return logisticsSkuKind;
	}
	public void setLogisticsSkuKind(String logisticsSkuKind) {
		this.logisticsSkuKind = logisticsSkuKind;
	}
	public String getLogisticsSkuWidth() {
		return logisticsSkuWidth;
	}
	public void setLogisticsSkuWidth(String logisticsSkuWidth) {
		this.logisticsSkuWidth = logisticsSkuWidth;
	}
	public String getLogisticsSkuDepth() {
		return logisticsSkuDepth;
	}
	public void setLogisticsSkuDepth(String logisticsSkuDepth) {
		this.logisticsSkuDepth = logisticsSkuDepth;
	}
	public String getLogisticsSkuHeight() {
		return logisticsSkuHeight;
	}
	public void setLogisticsSkuHeight(String logisticsSkuHeight) {
		this.logisticsSkuHeight = logisticsSkuHeight;
	}
	public String getLogisticsSkuWeight() {
		return logisticsSkuWeight;
	}
	public void setLogisticsSkuWeight(String logisticsSkuWeight) {
		this.logisticsSkuWeight = logisticsSkuWeight;
	}
	public String getLogisticsScanningCode() {
		return logisticsScanningCode;
	}
	public void setLogisticsScanningCode(String logisticsScanningCode) {
		this.logisticsScanningCode = logisticsScanningCode;
	}
	public String getLogisticsSkuImageUrl() {
		return logisticsSkuImageUrl;
	}
	public void setLogisticsSkuImageUrl(String logisticsSkuImageUrl) {
		this.logisticsSkuImageUrl = logisticsSkuImageUrl;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSkuImageUrl() {
		return skuImageUrl;
	}
	public void setSkuImageUrl(String skuImageUrl) {
		this.skuImageUrl = skuImageUrl;
	}
	
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getSkuy() {
		return skuy;
	}
	public void setSkuy(String skuy) {
		this.skuy = skuy;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public String getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(String skuWidth) {
		this.skuWidth = skuWidth;
	}
	public String getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(String skuDepth) {
		this.skuDepth = skuDepth;
	}
	public String getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(String skuHeight) {
		this.skuHeight = skuHeight;
	}
	public String getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(String skuWeight) {
		this.skuWeight = skuWeight;
	}
	public MultipartFile getSkuImageFile() {
		return skuImageFile;
	}
	public void setSkuImageFile(MultipartFile skuImageFile) {
		this.skuImageFile = skuImageFile;
	}
}

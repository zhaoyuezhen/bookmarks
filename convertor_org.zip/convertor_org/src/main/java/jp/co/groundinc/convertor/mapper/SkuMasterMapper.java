package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.SkuMaster;
import jp.co.groundinc.convertor.domain.SkuMasterCsv;
import jp.co.groundinc.convertor.domain.SkuMasterDetailReports;
@Mapper
public interface SkuMasterMapper {

	List<SkuMaster> selectSkuMaster(SkuMaster skuMaster);
	
	SkuMaster selectSkuMasterInfo(String sku);
	
	SkuMaster selectSkuMasterDetail(String sku);
	
	int updateSkuMaster(SkuMaster skuMaster);
	void updateDetail(SkuMaster skuMaster);
	void updateUrl(SkuMaster skuMaster);
	int selectProductCount(SkuMaster skuMaster);
	List<SkuMasterCsv> selectSkuMasterCsv(
			@Param("sku") String sku,
			@Param("skuName") String skuName,
			@Param("checkStatus") String checkStatus,
			@Param("checkStatusName") String checkStatusName,
			@Param("deletionKind") String deletionKind,
			@Param("updateUser") String updateUser);
	List<SkuMasterDetailReports> selectSkuMasterDetailReports(
			@Param("sku") String sku);
	
	
}

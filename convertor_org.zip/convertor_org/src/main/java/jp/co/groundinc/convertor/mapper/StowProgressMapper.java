package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.StowProgress;

@Mapper
public interface StowProgressMapper {

	List<StowProgress> findAll(StowProgress stowProgress);
	int selectCountt(StowProgress stowProgress);
	List<StowProgress> selectStowProgress(StowProgress stowProgress);
	int selectStowProgressCount(StowProgress stowProgress);
}

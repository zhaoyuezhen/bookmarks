package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.Pattern;

public class ManualPickInstructionForm {
	
@Pattern(regexp = "[a-zA-Z0-9]*", message = "{ManualPickInstructionForm.From.message}")
private String skuStart;
@Pattern(regexp = "[a-zA-Z0-9]*", message = "{ManualPickInstructionForm.To.message}")
private String skuEnd;
private String pickQtys[];
private String scheduled[];
private String skus[];

public String[] getPickQtys() {
	return pickQtys;
}
public void setPickQtys(String[] pickQtys) {
	this.pickQtys = pickQtys;
}
public String[] getSkus() {
	return skus;
}
public void setSkus(String[] skus) {
	this.skus = skus;
}
public String[] getScheduled() {
	return scheduled;
}
public void setScheduled(String[] scheduled) {
	this.scheduled = scheduled;
}
public String getSkuStart() {
	return skuStart;
}
public void setSkuStart(String skuStart) {
	this.skuStart = skuStart;
}
public String getSkuEnd() {
	return skuEnd;
}
public void setSkuEnd(String skuEnd) {
	this.skuEnd = skuEnd;
}


}

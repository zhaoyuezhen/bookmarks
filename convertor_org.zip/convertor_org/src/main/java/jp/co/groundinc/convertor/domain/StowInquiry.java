package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class StowInquiry implements Serializable {
	private static final long serialVersionUID = 1L;
	/** データ受信Start日 */
	private String dataReceivedDateStart;
	/** データ受信End日 */
	private String dataReceivedDateEnd;
	/** 作業実績Start日 */
	private String operatedDateStart;
	/** 作業実績End日  */
	private String operatedDateEnd;
	/** 伝票番号  */
	private String expectedPutId;
	/** コンテナID  */
	private String containerId;
	/** 行番号  */
	private String expectedPutLineId;
	/** 商品コード  */
	private String sku;
	/** 商品名  */
	private String skuName;
	/** 商品区分  */
	private String skuKind;
	/** 作業状態  */
	private String workingStatus;
	/** 作業状態 名 */
	private String workingStatusName;
	/** 予定数  */
	private String expectedQty;
	/** 実績数  */
	private String resultQty;
	/** 不良数  */
	private String damagedQty;
	/** 過剰数  */
	private String extraQty;
	/** 欠品数  */
	private String missingQty;
	/** 作業日  */
	private String operatedDate;
	/** 作業時間  */
	private String operatedTime;
	
	private String operatedDateTimeStart;
	
	private String operatedDateTimeEnd;
	/** ステーション  */
	private String ppsId;
	/** 予実差異  */
	private String irregularKindName;
	/** 受信予定開始日（時刻）  */
	private String dataReceivedTimeStart;
	/** 受信予定終了日（時刻）   */
	private String dataReceivedTimeEnd;
	
	private String irregularKind;
	
	private String putComment;
	
	private String butlerStatus;
	
	private String butlerStatusDetail;
	
	private String errorMessage;
	
	private String dataReceivedDate;
	
	private String dataReceivedDateTime;
	
	private String damagedQtyExtraQtyMissingQty;
	
	private String operatedDateTime;
	
	private String ppsBinId;
	
	private String ppsBinName;
	
	private String putKind;
	
	private String putKindName;
	
	private String createTime;
	
	public String getOperatedDateTimeStart() {
		return operatedDateTimeStart;
	}

	public void setOperatedDateTimeStart(String operatedDateTimeStart) {
		this.operatedDateTimeStart = operatedDateTimeStart;
	}

	public String getOperatedDateTimeEnd() {
		return operatedDateTimeEnd;
	}

	public void setOperatedDateTimeEnd(String operatedDateTimeEnd) {
		this.operatedDateTimeEnd = operatedDateTimeEnd;
	}

	public String getDataReceivedDateTime() {
		return dataReceivedDateTime;
	}

	public void setDataReceivedDateTime(String dataReceivedDateTime) {
		this.dataReceivedDateTime = dataReceivedDateTime;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getWorkingStatusName() {
		return workingStatusName;
	}

	public void setWorkingStatusName(String workingStatusName) {
		this.workingStatusName = workingStatusName;
	}

	public String getPpsBinId() {
		return ppsBinId;
	}

	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}

	public String getPutComment() {
		return putComment;
	}

	public void setPutComment(String putComment) {
		this.putComment = putComment;
	}

	public String getButlerStatus() {
		return butlerStatus;
	}

	public void setButlerStatus(String butlerStatus) {
		this.butlerStatus = butlerStatus;
	}

	public String getButlerStatusDetail() {
		return butlerStatusDetail;
	}

	public void setButlerStatusDetail(String butlerStatusDetail) {
		this.butlerStatusDetail = butlerStatusDetail;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPutKind() {
		return putKind;
	}

	public void setPutKind(String putKind) {
		this.putKind = putKind;
	}

	public String getPutKindName() {
		return putKindName;
	}

	public void setPutKindName(String putKindName) {
		this.putKindName = putKindName;
	}

	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}

	public String getOperatedDateTime() {
		return operatedDateTime;
	}

	public void setOperatedDateTime(String operatedDateTime) {
		this.operatedDateTime = operatedDateTime;
	}

	public String getDamagedQtyExtraQtyMissingQty() {
		return damagedQtyExtraQtyMissingQty;
	}

	public void setDamagedQtyExtraQtyMissingQty(String damagedQtyExtraQtyMissingQty) {
		this.damagedQtyExtraQtyMissingQty = damagedQtyExtraQtyMissingQty;
	}

	public String getDataReceivedDateStart() {
		return dataReceivedDateStart;
	}

	public void setDataReceivedDateStart(String dataReceivedDateStart) {
		this.dataReceivedDateStart = dataReceivedDateStart;
	}

	public String getDataReceivedDateEnd() {
		return dataReceivedDateEnd;
	}

	public void setDataReceivedDateEnd(String dataReceivedDateEnd) {
		this.dataReceivedDateEnd = dataReceivedDateEnd;
	}
		
	/** 受信予定開始日（時刻）    */
	public void setDataReceivedTimeStart(String dataReceivedTimeStart) {
		this.dataReceivedTimeStart = dataReceivedTimeStart;
	}
	public String getDataReceivedTimeStart() {
		return dataReceivedTimeStart;
	}	

	/** 受信予定終了日（時刻）    */
	public void setDataReceivedTimeEnd(String dataReceivedTimeEnd) {
		this.dataReceivedTimeEnd = dataReceivedTimeEnd;
	}
	public String getDataReceivedTimeEnd() {
		return dataReceivedTimeEnd;
	}

	public String getOperatedDateStart() {
		return operatedDateStart;
	}

	public void setOperatedDateStart(String operatedDateStart) {
		this.operatedDateStart = operatedDateStart;
	}

	public String getOperatedDateEnd() {
		return operatedDateEnd;
	}

	public void setOperatedDateEnd(String operatedDateEnd) {
		this.operatedDateEnd = operatedDateEnd;
	}

	
	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getExpectedPutId() {
		return expectedPutId;
	}

	public void setExpectedPutId(String expectedPutId) {
		this.expectedPutId = expectedPutId;
	}

	public String getExpectedPutLineId() {
		return expectedPutLineId;
	}

	public void setExpectedPutLineId(String expectedPutLineId) {
		this.expectedPutLineId = expectedPutLineId;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getSkuKind() {
		return skuKind;
	}

	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}

	public String getExpectedQty() {
		return expectedQty;
	}

	public void setExpectedQty(String expectedQty) {
		this.expectedQty = expectedQty;
	}

	public String getResultQty() {
		return resultQty;
	}

	public void setResultQty(String resultQty) {
		this.resultQty = resultQty;
	}

	public String getDamagedQty() {
		return damagedQty;
	}

	public void setDamagedQty(String damagedQty) {
		this.damagedQty = damagedQty;
	}

	public String getExtraQty() {
		return extraQty;
	}

	public void setExtraQty(String extraQty) {
		this.extraQty = extraQty;
	}

	public String getMissingQty() {
		return missingQty;
	}

	public void setMissingQty(String missingQty) {
		this.missingQty = missingQty;
	}

	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}
	

	public String getPpsBinName() {
		return ppsBinName;
	}

	public void setPpsBinName(String ppsBinName) {
		this.ppsBinName = ppsBinName;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

	public String getDataReceivedDate() {
		return dataReceivedDate;
	}

	public void setDataReceivedDate(String dataReceivedDate) {
		this.dataReceivedDate = dataReceivedDate;
	}

}

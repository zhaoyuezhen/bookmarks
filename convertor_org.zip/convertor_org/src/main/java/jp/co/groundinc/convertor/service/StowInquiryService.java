package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StowInquiry;
import jp.co.groundinc.convertor.domain.StowInquiryCsv;
import jp.co.groundinc.convertor.mapper.StowInquiryMapper;

@Service
public class StowInquiryService {
	@Autowired
	StowInquiryMapper stowInquiryMapper;
	@Autowired
	CommonUtility commonUtility;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<StowInquiry> selectStowInquiry(StowInquiry stowInquiry) {

		/*String receiveddateStart = CommonUtility.dateFomat(stowInquiry.getDataReceivedDateStart());
		stowInquiry.setDataReceivedDateStart(receiveddateStart);
		String receiveddateEnd = CommonUtility.dateFomat(stowInquiry.getDataReceivedDateEnd());
		stowInquiry.setDataReceivedDateEnd(receiveddateEnd);

		if (!StringUtils.isEmpty(stowInquiry.getOperatedDateStart())) {
			String operatedDateStart = CommonUtility.dateFomat(stowInquiry.getOperatedDateStart());
			stowInquiry.setOperatedDateStart(operatedDateStart);
		}

		if (!StringUtils.isEmpty(stowInquiry.getOperatedDateEnd())) {
			String operatedDateEnd = CommonUtility.dateFomat(stowInquiry.getOperatedDateEnd());
			stowInquiry.setOperatedDateEnd(operatedDateEnd);
		}
		
		if(!StringUtils.isEmpty(stowInquiry.getOperatedDateTimeStart())){
			String operatedDateTimeStart = CommonUtility.timeFomat(stowInquiry.getOperatedDateTimeStart());
			stowInquiry.setOperatedDateTimeStart(operatedDateTimeStart);
			
		}
		
		if(!StringUtils.isEmpty(stowInquiry.getOperatedDateTimeStart())){
			String operatedDateTimeEnd = CommonUtility.timeFomat(stowInquiry.getOperatedDateTimeEnd());
			stowInquiry.setOperatedDateTimeEnd(operatedDateTimeEnd);
		}
		*/
		List<StowInquiry> list = stowInquiryMapper.selectStowInquiry(stowInquiry);
		return list;

	}
	
	public int selectCountt(StowInquiry stowInquiry) {

		/*String receiveddateStart = CommonUtility.dateFomat(stowInquiry.getDataReceivedDateStart());
		stowInquiry.setDataReceivedDateStart(receiveddateStart);
		String receiveddateEnd = CommonUtility.dateFomat(stowInquiry.getDataReceivedDateEnd());
		stowInquiry.setDataReceivedDateEnd(receiveddateEnd);

		if (!StringUtils.isEmpty(stowInquiry.getOperatedDateStart())) {
			String operatedDateStart = CommonUtility.dateFomat(stowInquiry.getOperatedDateStart());
			stowInquiry.setOperatedDateStart(operatedDateStart);
		}
		if (!StringUtils.isEmpty(stowInquiry.getOperatedDateEnd())) {
			String operatedDateEnd = CommonUtility.dateFomat(stowInquiry.getOperatedDateEnd());
			stowInquiry.setOperatedDateEnd(operatedDateEnd);
		}
		
		if(!StringUtils.isEmpty(stowInquiry.getOperatedDateTimeStart())){
			String operatedDateTimeStart = CommonUtility.timeFomat(stowInquiry.getOperatedDateTimeStart());
			stowInquiry.setOperatedDateTimeStart(operatedDateTimeStart +"00");
			
		}
		
		if(!StringUtils.isEmpty(stowInquiry.getOperatedDateTimeStart())){
			String operatedDateTimeEnd = CommonUtility.timeFomat(stowInquiry.getOperatedDateTimeEnd());
			stowInquiry.setOperatedDateTimeEnd(operatedDateTimeEnd +"59");
		}
		*/
		int count = stowInquiryMapper.selectCountt(stowInquiry);
		return count;

	}
	
	public List<StowInquiryCsv> findStowInquiryCsv(
			String dataReceivedDateStart,String dataReceivedDateEnd,
			String dataReceivedTimeStart,String dataReceivedTimeEnd,
			String operatedDateStart, String operatedDateEnd,
			String operatedDateTimeStart,String operatedDateTimeEnd,
			String containerId, String expectedPutId,
			String workingStatus, String ppsId,
			String irregularKind, String irregularKindName,
			String sku, String putKind,String putKindName) {
		logger.info("--- StowInquiryService.findStowInquiryCsv() start ---");
		if (!StringUtils.isEmpty(operatedDateStart)) {
			 operatedDateStart = CommonUtility.dateFomat(operatedDateStart);
			 operatedDateEnd = CommonUtility.dateFomat(operatedDateEnd);
			 operatedDateTimeStart = CommonUtility.timeFomat(operatedDateTimeStart)+"00";
			 operatedDateTimeEnd = CommonUtility.timeFomat(operatedDateTimeEnd)+"59";
		}
		List<StowInquiryCsv> stowInquiryCsvList = 
				stowInquiryMapper.selectStowInquiryCsv(
						dataReceivedDateStart,dataReceivedDateEnd,
						dataReceivedTimeStart,dataReceivedTimeEnd,
						operatedDateStart,operatedDateEnd,
						operatedDateTimeStart,operatedDateTimeEnd,
						containerId,expectedPutId,workingStatus,ppsId,
						irregularKind,irregularKindName,
						sku,putKind,putKindName);
		return stowInquiryCsvList;
		
	}

}
package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.WCSStockInquiry;
import jp.co.groundinc.convertor.mapper.WCSStockInquiryMapper;

@Service
public class WCSStockInquiryService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	WCSStockInquiryMapper wCSStockInquiryMapper;
	@Autowired
	CommonUtility commonUtility;
	public List<WCSStockInquiry> findWCSStockInquiry(WCSStockInquiry wCSStockInquiry) {

		logger.info("--- WCSStockInquiryService.findWCSStockInquiry() start ---");

			String starDate = CommonUtility.dateFomat(wCSStockInquiry.getRequestDateStart());
			String endDate = CommonUtility.dateFomat(wCSStockInquiry.getRequestDateEnd());
			wCSStockInquiry.setRequestDateStart(starDate);
			wCSStockInquiry.setRequestDateEnd(endDate);
			List<WCSStockInquiry> wCSStockInquiryList = wCSStockInquiryMapper.findAll(wCSStockInquiry);

			return wCSStockInquiryList;
	}
	
	public int selectCountt(WCSStockInquiry wCSStockInquiry) {

		String starDate = CommonUtility.dateFomat(wCSStockInquiry.getRequestDateStart());
		String endDate = CommonUtility.dateFomat(wCSStockInquiry.getRequestDateEnd());
		wCSStockInquiry.setRequestDateStart(starDate);
		wCSStockInquiry.setRequestDateEnd(endDate);
		int count = wCSStockInquiryMapper.selectCountt(wCSStockInquiry);
		return count;

	}
}


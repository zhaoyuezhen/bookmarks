package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.WCSStockInquiry;

@Mapper
public interface WCSStockInquiryMapper {

	List<WCSStockInquiry> findAll(WCSStockInquiry wCSStockInquiry);
	int selectCountt(WCSStockInquiry wCSStockInquiry);
}

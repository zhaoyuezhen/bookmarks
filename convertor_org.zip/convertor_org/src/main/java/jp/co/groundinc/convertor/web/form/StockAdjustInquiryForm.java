package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class StockAdjustInquiryForm {
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{auditInquiry.auditNo.From.message}")
	private String auditNoStart;
	
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{auditInquiry.auditNo.From.message}")
	private String auditNoEnd;
	
	private String startDateStart;
	
	private String startDateEnd;
	
	private String startDate;
    
	private String auditId;
	
	private String auditTypeName;
	
	private String auditParamValueFrom;
	
	private String auditParamValueTo;
	
	private String auditParamValue;
	
	private String expectedSkuCount;
	
	private String resultSkuCount;
	
	private String startTime;
	
    private String expectedCount;
	
	private String resultCount;
	
    private String auditNo;
   
    private String irregularKind;
    
    private String irregularKindName;
	
    private String targetCount;
    
    private String [] auditNost;
    
    private String [] orderIDs;
    
    
	private String printerCode;
	
	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{StockAdjustInquiry.maxReauditCount.message}")
    private String maxReauditCount;
	
	public String getIrregularKind() {
		return irregularKind;
	}
	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}
	public String getMaxReauditCount() {
		return maxReauditCount;
	}
	public void setMaxReauditCount(String maxReauditCount) {
		this.maxReauditCount = maxReauditCount;
	}
	public String[] getOrderIDs() {
		return orderIDs;
	}
	public void setOrderIDs(String[] orderIDs) {
		this.orderIDs = orderIDs;
	}
	public String[] getAuditNost() {
		return auditNost;
	}
	public void setAuditNost(String[] auditNost) {
		this.auditNost = auditNost;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getTargetCount() {
		return targetCount;
	}
	public void setTargetCount(String targetCount) {
		this.targetCount = targetCount;
	}
    
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditTypeName() {
		return auditTypeName;
	}
	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}
	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}
	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}
	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}
	public String getAuditParamValue() {
		return auditParamValue;
	}
	public void setAuditParamValue(String auditParamValue) {
		this.auditParamValue = auditParamValue;
	}
	public String getExpectedSkuCount() {
		return expectedSkuCount;
	}
	public void setExpectedSkuCount(String expectedSkuCount) {
		this.expectedSkuCount = expectedSkuCount;
	}
	public String getResultSkuCount() {
		return resultSkuCount;
	}
	public void setResultSkuCount(String resultSkuCount) {
		this.resultSkuCount = resultSkuCount;
	}
	public String getIrregularKindName() {
		return irregularKindName;
	}
	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getExpectedCount() {
		return expectedCount;
	}
	public void setExpectedCount(String expectedCount) {
		this.expectedCount = expectedCount;
	}
	public String getResultCount() {
		return resultCount;
	}
	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}
	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

	public String getAuditNoStart() {
		return auditNoStart;
	}

	public void setAuditNoStart(String auditNoStart) {
		this.auditNoStart = auditNoStart;
	}

	public String getAuditNoEnd() {
		return auditNoEnd;
	}

	public void setAuditNoEnd(String auditNoEnd) {
		this.auditNoEnd = auditNoEnd;
	}

	public String getStartDateStart() {
		return startDateStart;
	}

	public void setStartDateStart(String startDateStart) {
		this.startDateStart = startDateStart;
	}

	public String getStartDateEnd() {
		return startDateEnd;
	}

	public void setStartDateEnd(String startDateEnd) {
		this.startDateEnd = startDateEnd;
	}
	public String getPrinterCode() {
		return printerCode;
	}
	public void setPrinterCode(String printerCode) {
		this.printerCode = printerCode;
	}

}

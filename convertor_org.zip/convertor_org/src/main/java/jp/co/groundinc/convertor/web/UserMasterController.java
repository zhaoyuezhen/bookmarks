package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.domain.UserMasterCsv;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.UserMasterService;
import jp.co.groundinc.convertor.web.form.UserMasterForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "authorityKinds", "userMasterForm" }) 
public class UserMasterController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CommonService commonService ;
	
	@Autowired
	UserMasterService userMasterService ;

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }
    
	@ModelAttribute("authorityKinds")
	public List<Translate> authorityKinds() {
		logger.info("--- UserMasterController.authorityKinds() start ---");
		return commonService.getTranslateList("AuthorityKind");
	}
	
	@ModelAttribute("userMasterForm")
	public UserMasterForm userMasterForm() {
		logger.info("--- UserMasterController.userMasterForm() start ---");
		return new UserMasterForm();
	}
	
    @RequestMapping("/user_master")
    public ModelAndView userMaster(ModelAndView modelView) throws ParseException {
    	logger.info("--- UserMasterController.userMaster() start ---");

    	UserMasterForm userMasterForm = new UserMasterForm();
		modelView.addObject("userMasterForm", userMasterForm);
        return modelView;
    }
    
    @RequestMapping(value="/user_master", params="action=search")
    public ModelAndView search(@Validated @ModelAttribute UserMasterForm form, BindingResult result, ModelAndView modelView) {
    	logger.info("--- UserMasterController.search() start ---");

    	modelView.setViewName("/user_master");

    	if (result.hasErrors()) {
            String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
    		return modelView;
    	}
    	
    	String userCode = form.getUserCode();
    	String userName = form.getUserName();
    	String authoritykind = form.getAuthoritykind();
    	
    	UserMaster user = new UserMaster();
    	user.setUserCode(userCode);
    	user.setUserName(userName);
    	user.setAuthorityKind(authoritykind);

    	int count  = commonService.selectTableUpperLimitCount();
		int countManual = userMasterService.selectCountt(user);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
        List<UserMaster> userList = userMasterService.findUsers(user);
        if (CollectionUtils.isEmpty(userList)) {
            String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
            modelView.addObject("validationMessage", message);
        }
        modelView.addObject("users", userList);
    	
        return modelView;
    }
    
    @RequestMapping(value = "/user_master", params = "action=download")
	public ModelAndView download(@Validated @ModelAttribute("form") UserMasterForm form,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) {
		logger.info("--- UserMasterController.download() start ---");
		modelView.setViewName("/user_master");
		
		String userCode = form.getUserCode();
    	String userName = form.getUserName();
    	String authorityKind = form.getAuthoritykind();
		
		UserMaster user = new UserMaster();
		user.setUserCode(userCode);
    	user.setUserName(userName);
    	user.setAuthorityKind(authorityKind);
		int count  = commonService.selectTableUpperCSVLimitCount();
		int countManual = userMasterService.selectCountt(user);
		if(count<=countManual){
			String message = messageSource.getMessage("Common.Search.Message.E006", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<UserMasterCsv> userMasterCsvList = 
				userMasterService.findUserMasterCsv(
						userCode, userName, authorityKind);
		
		if (CollectionUtils.isEmpty(userMasterCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/user_master");
			return modelView;
		}
		
		modelView.addObject("userMasterCsvList", userMasterCsvList);
		modelView.setViewName("UserMasterCsvView");
		return modelView;
	}
    
    @RequestMapping(value="/user_master", params="action=clear")
    public ModelAndView clearUserMaster(ModelAndView modelAndView, SessionStatus status) throws ParseException {
    	logger.info("--- UserMasterController.clearUserMaster() start ---");
    	
    	status.setComplete();
    	
    	UserMasterForm form = new UserMasterForm();
    	modelAndView.addObject("userMasterForm", form);

		return modelAndView;
    }
    
    @RequestMapping(value="/user_master", params="action=adduser")
    public String addUser(RedirectAttributes redirectAttributes, @ModelAttribute UserMasterForm form, Model model) {
    	logger.info("--- UserMasterController.addUser() start ---");
    	
    	redirectAttributes.addFlashAttribute("userEditMode", CommonConstant.USER_EDIT_MODE_ADDITION);
    	redirectAttributes.addFlashAttribute("userMasterForm", form);
    	return "redirect:user_detail";
    }
    
    @RequestMapping(value="/user_master", params="action=edituser")
    public String editUser(@RequestParam("tbUserCode") String tbUserCode, RedirectAttributes redirectAttributes, @ModelAttribute UserMasterForm form, Model model) {
    	logger.info("--- UserMasterController.editUser() start ---");
    	
    	redirectAttributes.addFlashAttribute("userEditMode", CommonConstant.USER_EDIT_MODE_EDIT);
    	redirectAttributes.addFlashAttribute("tbUserCode", tbUserCode);
    	redirectAttributes.addFlashAttribute("userMasterForm", form);
    	
        return "redirect:user_detail";
    }
}

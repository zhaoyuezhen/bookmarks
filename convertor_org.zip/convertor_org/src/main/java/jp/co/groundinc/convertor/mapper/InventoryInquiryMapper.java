package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import jp.co.groundinc.convertor.domain.InventoryInquiry;
import jp.co.groundinc.convertor.domain.InventoryInquiryCsv;
@Mapper
public interface InventoryInquiryMapper {

	List<InventoryInquiry> selectInventoryInquiry(InventoryInquiry inventoryInquiry);
	int selectCount(InventoryInquiry inventoryInquiry);
	List<InventoryInquiryCsv> selectInventoryInquiryCsv(
			@Param("operatedDateStart") String operatedDateStart,
			@Param("operatedDateEnd") String operatedDateEnd,
			@Param("operatedDateTimeStart") String operatedDateTimeStart,
			@Param("operatedDateTimeEnd") String operatedDateTimeEnd,
			@Param("sku") String sku,
			@Param("keyId") String keyId,
			@Param("location") String location,
	        @Param("userCode") String userCode,
	        @Param("ppsId") String ppsId,
			@Param("Put") String Put,
		    @Param("Pick") String Pick,
			@Param("ManualPick") String ManualPick,
			@Param("ManualPut") String ManualPut,
			@Param("Audit") String Audit,
			@Param("StockAdjust") String StockAdjust,
			@Param("operationKindCode") String operationKindCode,
			@Param("PickExceptions") String PickExceptions,
			@Param("AuditExceptions") String AuditExceptions);
	
}

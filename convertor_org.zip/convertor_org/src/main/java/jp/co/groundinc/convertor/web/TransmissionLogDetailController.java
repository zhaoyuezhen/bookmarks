package jp.co.groundinc.convertor.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.TransmissionLog;
import jp.co.groundinc.convertor.domain.TransmissionLogMapperDetail;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.TransmissionLogService;
import jp.co.groundinc.convertor.web.form.TransmissionLogForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class TransmissionLogDetailController {
	@Autowired
	CommonService commonService;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	TransmissionLogService transmissionLogService;

	@ModelAttribute("transmissionLogForm")
	public TransmissionLogForm transmissionLogForm() {
		logger.info("--- TransmissionLogController.transmissionLogForm() start ---");
		return new TransmissionLogForm();
	}

	@ModelAttribute("communicationType")
	public List<Translate> communicationTypes() {
		logger.info("--- TransmissionLogController.communicationTypes() start ---");
		return commonService.getTranslateList("CommunicationType");
	}

	@ModelAttribute("communicationTypeDetail")
	public List<Translate> communicationTypeDetails() {
		logger.info("--- TransmissionLogController.communicationTypeDetails() start ---");
		return commonService.getTranslateList("CommunicationTypeDetail");
	}

	@ModelAttribute("sendRecvKind")
	public List<Translate> sendRecvKinds() {
		logger.info("--- TransmissionLogController.sendRecvKinds() start ---");
		return commonService.getTranslateList("SendRecvKind");
	}

	@ModelAttribute("processingStatus")
	public List<Translate> processStatuss() {
		logger.info("--- TransmissionLogController.processStatuss() start ---");
		return commonService.getTranslateList("ProcessingStatus");
	}

	@RequestMapping(value = "/monitorDetail")
	public ModelAndView communicationMonitorDetail(@RequestParam("transmissionid") String transmissionid,
			ModelAndView modelView) {
		modelView.setViewName("transmission_log_detail");
		logger.info("--- TransmissionLogDetailController.communicationMonitorDetail() start ---");
		TransmissionLog transmissionLogInfo = transmissionLogService.findCommunicationMonitor(transmissionid);
		modelView.addObject("transmissionLogInfo", transmissionLogInfo);
		int successcount = Integer.parseInt(transmissionLogInfo.getTotalCount())
				- Integer.parseInt(transmissionLogInfo.getErrorCount());
		modelView.addObject("successcount", Integer.toString(successcount));
		logger.info("--- TransmissionLogDetailController.communicationMonitorDetail() start ---");
		List<TransmissionLogMapperDetail> errorInfoList = transmissionLogService.selectErrorInfo(transmissionid);
		modelView.addObject("errorInfoList", errorInfoList);
		return modelView;
	}

	@RequestMapping(value = "/monitorDetail", params = "action=Detailback")
	public ModelAndView communicationMonitorDetailBack(HttpServletRequest request, ModelAndView modelView) {
		logger.info("--- communicationMonitorDetailBack() start ---");
		modelView.setViewName("/transmission_log");
		TransmissionLogForm transmissionLogForm = (TransmissionLogForm) request.getSession()
				.getAttribute("transmissionLogForm");	
		String startDate = transmissionLogForm.getStartDate();
		String endDate = transmissionLogForm.getEndDate();
		modelView.addObject("startDate", startDate);
		modelView.addObject("endDate", endDate);
		String sendrecvkind = transmissionLogForm.getSendrecvKind();
		String processingstatus = transmissionLogForm.getProcessingStatus();
		String transmissiontype = transmissionLogForm.getTransMissionType();
		String transmissiontypedetail = transmissionLogForm.getTransMissionTypeDetail();
		TransmissionLog transmissionLog = new TransmissionLog();
		transmissionLog.setStartDate(CommonUtility.dateFomat(startDate));
		transmissionLog.setEndDate(CommonUtility.dateFomat(endDate));
		transmissionLog.setSendrecvKind(sendrecvkind);
		transmissionLog.setProcessingStatus(processingstatus);
		transmissionLog.setTransmissionType(transmissiontype);
		transmissionLog.setTransmissionTypeDetail(transmissiontypedetail);
		List<TransmissionLog> communicationMonitorlist = transmissionLogService
				.findCommunicationMonitor(transmissionLog);
		modelView.addObject("communicationMonitorlist", communicationMonitorlist);
		modelView.addObject("transmissionLogForm", transmissionLogForm);
		return modelView;
	}
}

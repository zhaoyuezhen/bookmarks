package jp.co.groundinc.convertor.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.AuthorityMaster;

@Mapper
public interface AuthorityMasterMapper {
	List<AuthorityMaster> findByAuthorityKind(String authorityKind);
	void update(AuthorityMaster authorityMaster);
}

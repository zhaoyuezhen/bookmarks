package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.DailyStockFileInquiry;
import jp.co.groundinc.convertor.mapper.DailyStockInquiryMapper;

@Service
public class DailyStockInquiryService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	DailyStockInquiryMapper dailyStockInquiryMapper;
	@Autowired
	CommonUtility commonUtility;
	public List<DailyStockFileInquiry> findDailyStockFileInquiry(DailyStockFileInquiry dailyStockFileInquiry) {

		logger.info("--- DailyStockInquiryService.findDailyStockFileInquiry() start ---");

			String starDate = CommonUtility.dateFomat(dailyStockFileInquiry.getProcessedDateStart());
			String endDate = CommonUtility.dateFomat(dailyStockFileInquiry.getProcessedDateEnd());
			dailyStockFileInquiry.setProcessedDateStart(starDate);
			dailyStockFileInquiry.setProcessedDateEnd(endDate);
			List<DailyStockFileInquiry> dailyStockFileInquiryList = dailyStockInquiryMapper.findAll(dailyStockFileInquiry);

			return dailyStockFileInquiryList;
	}
	
	public int selectCountt(DailyStockFileInquiry dailyStockFileInquiry) {

		String starDate = CommonUtility.dateFomat(dailyStockFileInquiry.getProcessedDateStart());
		String endDate = CommonUtility.dateFomat(dailyStockFileInquiry.getProcessedDateEnd());
		dailyStockFileInquiry.setProcessedDateStart(starDate);
		dailyStockFileInquiry.setProcessedDateEnd(endDate);
		int count = dailyStockInquiryMapper.selectCountt(dailyStockFileInquiry);
		return count;

	}
}


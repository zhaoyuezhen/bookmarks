package jp.co.groundinc.convertor;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonConstant {
	/** フラグ ON */
	public final static String FLAG_ON = "1";
	/** フラグ OFF */
	public final static String FLAG_OFF = "0";
	
	/** レポートタイプ：CSV */
	public final static String REPORT_TYPE_CSV = "CSV";
	/** レポートタイプ：TSV */
	public final static String REPORT_TYPE_TSV = "TSV";
	
	/** ユーザ編集モード：登録 */
	public final static String USER_EDIT_MODE_ADDITION = "ADDITION";
	/** ユーザ編集モード：編集 */
	public final static String USER_EDIT_MODE_EDIT = "EDIT";
	
	/** マニュアル出庫指示 */
	public final static String ORDER_KIND = "2";
	public final static String WORKING_STATUS = "00";
	public final static int PRIORITY= 1;
	public final static String FILE_OUTPUT_FLAG= "0";
	public final static String REGX ="^\\d+$";
	
	/** 棚卸し：指示 */
	public final  static String AUDIT_STOCK_KIND= "a";
	public final  static String CLASSI_FICATION_PRODUCTCODE = "productCode";
	public final  static String AUDIT_TYPE_SKU = "sku";
	public final  static String AUDIT_TYPE_LOCATION = "location";
	public final  static String SEND_STATUS = "0";
	public final  static String MSUID_NUMBER = "0000";
	public final  static  String MSUSIDE_NUMBER = "0";
	public final  static  String MSUSTEP_NUMBER = "0";
	public final  static String MSUSLOT_NUMBER = "00";
	public final static  String MSUID_ARUFA = "zzzz";
	public final static String MSUSIDE_ARUFA = "z";
	public final static String MSUSTEP_ARUFA = "z";
	public final  static String MSUSLOT_ARUFA = "zz";
	public final  static String SLOT = "slot";
	public final  static String REGEX = ".*[a-zA-Z]+.*";
	
	/** 棚卸し：指示 */
	
	public final  static String KY_AUDIT_STOCK_KIND= "s";
	
	/** 商品マスター明細　 */
	public final static String REGXN ="[^',\"\\[\\]]*";
	
	/** ユーザマスター　 */
	public final static String REGXU ="[^,\"\\[\\]]*";
	
	/** ユーザマスター　 */
	public final static String LOGISTICSSKUWEIGHT = "^\\d{1,3}(\\.\\d{1,3})?$";
	
	/** 緊急出庫指示 */
	public final  static String BINTAGS ="SH";
	public final static String ORDER_KINDS = "1";
	
	/** 日次在庫ファイル作成 */
	public final  static String CREATE_KIND ="temp";
	public final  static String CREATE_KINDS ="send";
	

    /**WCS在庫ファイル作成*/
	
	public final  static String PAYLOADSTART ="{"+"\"delimiter\":\",\""+","+"\"output_fields\""+":[";
	public final static String PAYLOADEND = "{\"key\":\"product_sku\",\"display_name\":\"SKU\"}"+","+"{\"key\":\"location\",\"display_name\":\"Location\"}"+","+"{\"key\":\"actual_quantity\",\"display_name\":\"Quantity\"}]}";
	
	
}

package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class PrintLogInquiryForm {
	
	@NotNull(message = "{printLogInquiry.printDateStart.empty.message}")
    private String printDateStart;
	
    private String printTimeStart;
	
	private String printTimeEnd;
	
	@Size(max = 13)
	@Pattern(regexp = "[a-zA-Z0-9]*", message="{PrintLogInquiry.userId.Halfangle.message}")
	private String userCode;
	
	/**　フェイル名　*/
	private String filePath;
	
	/**　帳票名　*/
	private String formName;
	
	private String printer;

	public String getPrintDateStart() {
		return printDateStart;
	}

	public void setPrintDateStart(String printDateStart) {
		this.printDateStart = printDateStart;
	}


	public String getPrintTimeStart() {
		return printTimeStart;
	}

	public void setPrintTimeStart(String printTimeStart) {
		this.printTimeStart = printTimeStart;
	}

	public String getPrintTimeEnd() {
		return printTimeEnd;
	}

	public void setPrintTimeEnd(String printTimeEnd) {
		this.printTimeEnd = printTimeEnd;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getPrinter() {
		return printer;
	}

	public void setPrinter(String printer) {
		this.printer = printer;
	}

}

package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class WCSStockInquiry implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private String ID;
	
	private String component;
	
	@NotNull(message = "{WCSStockInquiry.search.requestDateStart.empty.message}")
	private String requestDateStart;
	
	private String requestDateEnd;
	
	private String requestDate;
	
	private String requestTime;
	
	private String generateDate;
	
	private String generateTime;
	
	private String fileUrl;
	
	private String requestDateTime;
	
	private String generateDateTime;
	
	
	public String getGenerateDateTime() {
		return generateDateTime;
	}

	public void setGenerateDateTime(String generateDateTime) {
		this.generateDateTime = generateDateTime;
	}

	public String getRequestDateTime() {
		return requestDateTime;
	}

	public void setRequestDateTime(String requestDateTime) {
		this.requestDateTime = requestDateTime;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getRequestDateStart() {
		return requestDateStart;
	}

	public void setRequestDateStart(String requestDateStart) {
		this.requestDateStart = requestDateStart;
	}

	public String getRequestDateEnd() {
		return requestDateEnd;
	}

	public void setRequestDateEnd(String requestDateEnd) {
		this.requestDateEnd = requestDateEnd;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public String getGenerateDate() {
		return generateDate;
	}

	public void setGenerateDate(String generateDate) {
		this.generateDate = generateDate;
	}

	public String getGenerateTime() {
		return generateTime;
	}

	public void setGenerateTime(String generateTime) {
		this.generateTime = generateTime;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}

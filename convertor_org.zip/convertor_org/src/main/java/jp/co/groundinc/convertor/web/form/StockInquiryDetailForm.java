package jp.co.groundinc.convertor.web.form;


public class StockInquiryDetailForm {
	
	private String auditNo;
	
	private String location;
	
	private String sku;
	
	private String skuName;
	
	private int expectedQty;
	
	private int resultQty;
	
	private int diffQty;
	
	private int extraQty;
	
	private String erd;
	
	private String ppsName;
	
	private String userName;
	
	private String operatedDate;
	
	private String operatedTime;
	
	private String operatedDateTime;
	
	private String auditId;
	
	private String irregularKindName;
	
	private String auditStatus;

	private String reauditCount;
	
	private String [] auditNost;
	    
	private String [] orderIDs;
	
	public String getAuditNoList() {
		return auditNoList;
	}

	public void setAuditNoList(String auditNoList) {
		this.auditNoList = auditNoList;
	}

	public String getSlotList() {
		return slotList;
	}

	public void setSlotList(String slotList) {
		this.slotList = slotList;
	}

	public String getSkuList() {
		return skuList;
	}

	public void setSkuList(String skuList) {
		this.skuList = skuList;
	}

	private String auditNoList;

	private String slotList;
	
	private String skuList;
	
	private String auditTypeName;

	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public int getExpectedQty() {
		return expectedQty;
	}

	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}

	public int getResultQty() {
		return resultQty;
	}

	public void setResultQty(int resultQty) {
		this.resultQty = resultQty;
	}

	public int getDiffQty() {
		return diffQty;
	}

	public void setDiffQty(int diffQty) {
		this.diffQty = diffQty;
	}

	public int getExtraQty() {
		return extraQty;
	}

	public void setExtraQty(int extraQty) {
		this.extraQty = extraQty;
	}

	public String getErd() {
		return erd;
	}

	public void setErd(String erd) {
		this.erd = erd;
	}

	public String getPpsName() {
		return ppsName;
	}

	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}

	public String getOperatedDateTime() {
		return operatedDateTime;
	}

	public void setOperatedDateTime(String operatedDateTime) {
		this.operatedDateTime = operatedDateTime;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getReauditCount() {
		return reauditCount;
	}

	public void setReauditCount(String reauditCount) {
		this.reauditCount = reauditCount;
	}

	public String[] getAuditNost() {
		return auditNost;
	}

	public void setAuditNost(String[] auditNost) {
		this.auditNost = auditNost;
	}

	public String[] getOrderIDs() {
		return orderIDs;
	}

	public void setOrderIDs(String[] orderIDs) {
		this.orderIDs = orderIDs;
	}
	
	public String getAuditTypeName() {
		return auditTypeName;
	}

	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
}

package jp.co.groundinc.convertor.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.domain.InventoriesInstruction;
import jp.co.groundinc.convertor.domain.InventoriesInstructionReports;
import jp.co.groundinc.convertor.mapper.InventoriesInstructionMapper;

@Service
@EnableAutoConfiguration
public class InventoriesInstructionService {
	
	@Autowired
	InventoriesInstructionMapper inventoriesInstructionMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<InventoriesInstruction> findProductInfo(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.findProductInfo() start ---");
		List<InventoriesInstruction> selectProductInfoList = inventoriesInstructionMapper.selectProductInfo(inventoriesInstruction);
		return selectProductInfoList;
	}
	
	public void selectAuditSeqenceNext() {
		logger.info("--- InventoriesInstructionService.selectAuditSeqenceNext() start ---");
		  inventoriesInstructionMapper.selectAuditSeqenceNext();
		
	}
	
	public String selectAuditSeqence() {
		logger.info("--- InventoriesInstructionService.selectAuditSeqence() start ---");
		String AuditNo  = inventoriesInstructionMapper.selectAuditSeqence();
		return AuditNo;
	}
	
	public void insertauditException(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.insertauditException() start ---");
		inventoriesInstructionMapper.insertAuditExpectation(inventoriesInstruction);
		
	}
	
	public String selectSlotCount(String sku) {
		logger.info("--- InventoriesInstructionService.findProductInfo() start ---");
		String selectProductSlotCount = inventoriesInstructionMapper.selectSlotCount(sku);
		return selectProductSlotCount;
	}
	
	public List<InventoriesInstruction> selectViewStockDetail(String sku) {
		logger.info("--- InventoriesInstructionService.selectViewStockDetail() start ---");
		List<InventoriesInstruction> selectViewStockDetaillList = inventoriesInstructionMapper.selectViewStockDetail(sku);
		return selectViewStockDetaillList;
	}
	public List<InventoriesInstruction> selectViewStockDetailLocation(String location) {
		logger.info("--- InventoriesInstructionService.selectViewStockDetailLocation() start ---");
		List<InventoriesInstruction> selectViewStockDetaillLocationList = inventoriesInstructionMapper.selectViewStockDetailLocation(location);
		return selectViewStockDetaillLocationList;
	}
	
	public void insertAuditExceptionDetail(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.insertAuditExceptionDetail() start ---");
		inventoriesInstructionMapper.insertAuditExceptionDetail(inventoriesInstruction);
		
	}
	
	public void insertAuditStock(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.insertAuditExceptionDetail() start ---");
		inventoriesInstructionMapper.insertAuditStock(inventoriesInstruction);
		
	}
	
	public List<InventoriesInstruction> findLocationInfo(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.findProductInfo() start ---");
		List<InventoriesInstruction> LocationList = inventoriesInstructionMapper.findLocationInfo(inventoriesInstruction);
		return LocationList;
	}
	
	public int selectProductCount(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.selectProductCount() start ---");
		int count = inventoriesInstructionMapper.selectProductCount(inventoriesInstruction);
		return count;
	}
	
	public int selectSlotCountt(InventoriesInstruction inventoriesInstruction) {
		logger.info("--- InventoriesInstructionService.selectSlotCount() start ---");
		int count = inventoriesInstructionMapper.selectSlotCountt(inventoriesInstruction);
		return count;
	}
	
	public List<InventoriesInstructionReports> findInventoriesInstructionReports(String Seqence) {
		logger.info("--- InventoriesInstructionService.findInventoriesInstructionReports() start ---");
		List<InventoriesInstructionReports> inventoriesInstructionReportsList = 
				inventoriesInstructionMapper.selectInventoriesInstructionReports(Seqence);
		
		return inventoriesInstructionReportsList;
	}

}

package jp.co.groundinc.convertor.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.domain.ManualPickInstruction;
import jp.co.groundinc.convertor.domain.ManualPickInstructionReports;
import jp.co.groundinc.convertor.mapper.ManualPickInstructionMapper;
@Service
@EnableAutoConfiguration
public class ManualPickInstructionService {
	@Autowired
	ManualPickInstructionMapper manualPickInstructionMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<ManualPickInstruction> findPickInfo(ManualPickInstruction manualPickInstruction) {
		logger.info("--- ManualPickInstructionService.findPickInfo() start ---");
		List<ManualPickInstruction> selectPickList = manualPickInstructionMapper.selectPickInquiryInfo(manualPickInstruction);
		return selectPickList;
	}
	public int selectCountt(ManualPickInstruction manualPickInstruction) {
		logger.info("--- ManualPickInstructionService.selectCount() start ---");
		int countManualPick = manualPickInstructionMapper.selectCountt(manualPickInstruction);
		return countManualPick;
	}
	public String selectOrderSeqence() {
		logger.info("--- ManualPickInstructionService.selectOrderSeqence() start ---");
		String orderId = manualPickInstructionMapper.selectOrderSeqence();
		return orderId;
	}
	public String selectprocessSequenceNo() {
		logger.info("--- ManualPickInstructionService.selectprocessSequenceNo() start ---");
		String processSequenceNo = manualPickInstructionMapper.selectOrderProcessSeqence();
		return processSequenceNo;
	}

	public int insetrOrderManual(ManualPickInstruction manualPickInstruction) {
		logger.info("--- ManualPickInstructionService.insetrOrderManual() start ---");
		 int count  = manualPickInstructionMapper.insertOrderManual(manualPickInstruction);
		 return count;
	}
	
	public List<ManualPickInstructionReports> findManualPickInstructionReports(String orderId) {
		logger.info("--- ManualPickInstructionService.findManualPickInstructionReports() start ---");
		List<ManualPickInstructionReports> manualPickInstructionReportsList = 
				manualPickInstructionMapper.selectManualPickInstructionReports(orderId);
		
		return manualPickInstructionReportsList;
	}
	public void updateFileOutputFlag(ManualPickInstruction manualPickInstruction) {
		logger.info("---  ManualPickInstructionService.updateFileOutputFlag() start ---");
		manualPickInstructionMapper.update(manualPickInstruction);
	}
}

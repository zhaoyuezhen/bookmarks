package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class PickInquiryCsv implements Serializable {
	private static final long serialVersionUID = 1L;
	private String datareceiveddateStart;
	private String datareceiveddateEnd;
	private String expecteddateStart;
	private String expecteddateEnd;
	private String operateddateStart;
	private String operateddateEnd;
	private String operateddate;
	private String operatedtime;
	private String ppsbinid;
	private String ppsbinName;
	private String datareceiveddate;
	private String expecteddate;
	private String orderid;
	private String orderlineid;
	private String orderAreaKind;
	private String orderAreaKindName;
	private String sku;
	private String skuname;
	private String skuKind;
	private String skuKindName;
	private String area;
	private String expectedqty;
	private String resultqty;
	private String missingqty;
	private String irregularKindName;
	private String irregularKind;
	private String workingstatus;
	private String workingstatusName;
	private String ppsid;
	private String ppsName;
	private String priority;
	private String orderKindName;
	private String orderKind;
	private String userCode;
	private String userName;
	private String csvExportDate;
	private String csvExportTime;
	/**予定開始日 */
	private String dataReceivedtimeStart;
	/**予定終了日   */
	private String dataReceivedtimeEnd;	

	public String getCsvExportDate() {
		return csvExportDate;
	}

	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}

	public String getCsvExportTime() {
		return csvExportTime;
	}

	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	
	public String getPpsbinName() {
		return ppsbinName;
	}

	public void setPpsbinName(String ppsbinName) {
		this.ppsbinName = ppsbinName;
	}

	public String getPpsName() {
		return ppsName;
	}

	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}

	public String getOrderKindName() {
		return orderKindName;
	}

	public void setOrderKindName(String orderKindName) {
		this.orderKindName = orderKindName;
	}

	public String getOrderKind() {
		return orderKind;
	}

	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}

	public String getExpecteddate() {
		return expecteddate;
	}

	public void setExpecteddate(String expecteddate) {
		this.expecteddate = expecteddate;
	}

	public String getOrderlineid() {
		return orderlineid;
	}

	public void setOrderlineid(String orderlineid) {
		this.orderlineid = orderlineid;
	}

	public String getPpsbinid() {
		return ppsbinid;
	}

	public void setPpsbinid(String ppsbinid) {
		this.ppsbinid = ppsbinid;
	}

	public String getDatareceiveddateStart() {
		return datareceiveddateStart;
	}

	public String getWorkingstatus() {
		return workingstatus;
	}

	public void setWorkingstatus(String workingstatus) {
		this.workingstatus = workingstatus;
	}

	public void setDatareceiveddateStart(String datareceiveddateStart) {
		this.datareceiveddateStart = datareceiveddateStart;
	}

	public String getDatareceiveddateEnd() {
		return datareceiveddateEnd;
	}

	public void setDatareceiveddateEnd(String datareceiveddateEnd) {
		this.datareceiveddateEnd = datareceiveddateEnd;
	}

	public String getExpecteddateStart() {
		return expecteddateStart;
	}

	public void setExpecteddateStart(String expecteddateStart) {
		this.expecteddateStart = expecteddateStart;
	}

	public String getExpecteddateEnd() {
		return expecteddateEnd;
	}

	public void setExpecteddateEnd(String expecteddateEnd) {
		this.expecteddateEnd = expecteddateEnd;
	}

	public String getOperateddateStart() {
		return operateddateStart;
	}

	public void setOperateddateStart(String operateddateStart) {
		this.operateddateStart = operateddateStart;
	}

	public String getOperateddateEnd() {
		return operateddateEnd;
	}

	public void setOperateddateEnd(String operateddateEnd) {
		this.operateddateEnd = operateddateEnd;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDatareceiveddate() {
		return datareceiveddate;
	}

	public void setDatareceiveddate(String datareceiveddate) {
		this.datareceiveddate = datareceiveddate;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuname() {
		return skuname;
	}

	public void setSkuname(String skuname) {
		this.skuname = skuname;
	}

	public String getExpectedqty() {
		return expectedqty;
	}

	public void setExpectedqty(String expectedqty) {
		this.expectedqty = expectedqty;
	}

	public String getResultqty() {
		return resultqty;
	}

	public void setResultqty(String resultqty) {
		this.resultqty = resultqty;
	}

	public String getMissingqty() {
		return missingqty;
	}

	public void setMissingqty(String missingqty) {
		this.missingqty = missingqty;
	}

	public String getOperateddate() {
		return operateddate;
	}

	public void setOperateddate(String operateddate) {
		this.operateddate = operateddate;
	}

	public String getOperatedtime() {
		return operatedtime;
	}

	public void setOperatedtime(String operatedtime) {
		this.operatedtime = operatedtime;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

	public String getOrderAreaKind() {
		return orderAreaKind;
	}

	public void setOrderAreaKind(String orderAreaKind) {
		this.orderAreaKind = orderAreaKind;
	}

	public String getOrderAreaKindName() {
		return orderAreaKindName;
	}

	public void setOrderAreaKindName(String orderAreaKindName) {
		this.orderAreaKindName = orderAreaKindName;
	}

	public String getSkuKind() {
		return skuKind;
	}

	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}

	public String getSkuKindName() {
		return skuKindName;
	}

	public void setSkuKindName(String skuKindName) {
		this.skuKindName = skuKindName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getWorkingstatusName() {
		return workingstatusName;
	}

	public void setWorkingstatusName(String workingstatusName) {
		this.workingstatusName = workingstatusName;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}

	public String getPpsid() {
		return ppsid;
	}

	public void setPpsid(String ppsid) {
		this.ppsid = ppsid;
	}
	/** 予定開始日 */
	public void setDataReceivedtimeStart(String dataReceivedtimeStart) {
		this.dataReceivedtimeStart = dataReceivedtimeStart;
	}
	public String getDataReceivedtimeStart() {
		return dataReceivedtimeStart;
	}	

	/**予定終了日   */
	public void setDataReceivedtimeEnd(String dataReceivedtimeEnd) {
		this.dataReceivedtimeEnd = dataReceivedtimeEnd;
	}
	public String getDataReceivedtimeEnd() {
		return dataReceivedtimeEnd;
	}


}

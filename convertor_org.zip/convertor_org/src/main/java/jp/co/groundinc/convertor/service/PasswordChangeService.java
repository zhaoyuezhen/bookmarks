package jp.co.groundinc.convertor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.mapper.PassWordChangeMapper;

@Service
public class PasswordChangeService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PassWordChangeMapper passWordChangeMapper;

	public boolean exists(String userCode, String password) {
		logger.info("--- PasswordChangeService.exists() start ---");
		boolean bRtn = true;
		
		int count = passWordChangeMapper.countAll(userCode, password);
		if (count == 0) {
			bRtn = false;
		}
		
		return bRtn;
	}
	public void updateUserPassword(UserMaster user) {
		passWordChangeMapper.updateUserPassword(user);
	}
	
}

package jp.co.groundinc.convertor.web;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.domain.SkuMasterReject;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.SkuMasterRejectService;
import jp.co.groundinc.convertor.web.form.SkuMasterRejectForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "skuMasterRejectForm" })
public class SkuMasterRejectController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	SkuMasterRejectService skuMasterRejectService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("skuMasterRejectForm")
	public SkuMasterRejectForm skuMasterRejectForm() {
		logger.info("--- skuMasterRejectForm.skuMasterRejectForm() start ---");
		return new SkuMasterRejectForm();
	}

	@ModelAttribute("sendStatus")
	public List<Translate> processingStatus() {
		logger.info("--- SkuMasterRejectController.sendStatus() start ---");
		List<Translate> translateList = new ArrayList<Translate>();
		List<Translate> resTranslateList = new ArrayList<Translate>();
		translateList = commonService.getTranslateList("SendStatus");
		for(Translate translate : translateList) {
			if(translate.getTranslate_code().equals("1")||translate.getTranslate_code().equals("3")) {
				resTranslateList.add(translate);
			}
		}
		return resTranslateList;
	}

	@RequestMapping("/sku_master_reject")
	public ModelAndView skuMasterReject(ModelAndView modelView) throws ParseException {
		logger.info("--- SkuMasterRejectController.skuMasterReject() start ---");

		String operationDate = commonService.getOperationDate();
		SkuMasterRejectForm form = new SkuMasterRejectForm();
		form.setDataReceivedDateStart(operationDate);
		form.setDataReceivedDateEnd(operationDate);
		modelView.addObject("skuMasterRejectForm", form);

		return modelView;
	}

	@RequestMapping(value = "/sku_master_reject", params = "action=search")
	public ModelAndView search(
			@Validated @ModelAttribute("skuMasterRejectForm") SkuMasterRejectForm skuMasterRejectForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {

		logger.info("--- search() start ---");
		modelView.setViewName("/sku_master_reject");

		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String dataReceivedDateStart = skuMasterRejectForm.getDataReceivedDateStart();
		String dataReceivedDateEnd = skuMasterRejectForm.getDataReceivedDateEnd();
		String sku = skuMasterRejectForm.getSku();
		String skuName = skuMasterRejectForm.getSkuName();
		String sendStatus = skuMasterRejectForm.getSendStatus();
		String sendStatusName = skuMasterRejectForm.getSendStatusName();

		if (!StringUtils.isEmpty(dataReceivedDateStart) && !StringUtils.isEmpty(dataReceivedDateEnd)) {

			if (CommonUtility.comparedateStartafterEnd(dataReceivedDateStart, dataReceivedDateEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String dataReceivedDate = messageSource
						.getMessage("skuMasterReject.dataReceivedDate.Datecomparison.message", null, Locale.JAPAN);
				modelView.addObject("dataReceivedDate", dataReceivedDate);
				return modelView;
			}
		}
		
		skuMasterRejectForm.setDataReceivedDateEnd(dataReceivedDateEnd);
		skuMasterRejectForm.setDataReceivedDateStart(dataReceivedDateStart);
		skuMasterRejectForm.setSku(sku);
		skuMasterRejectForm.setSkuName(skuName);
		skuMasterRejectForm.setSendStatus(sendStatus);
		skuMasterRejectForm.setSendStatusName(sendStatusName);

		SkuMasterReject skuMasterReject = new SkuMasterReject();
		skuMasterReject.setDataReceivedDateStart(dataReceivedDateStart);
		skuMasterReject.setDataReceivedDateEnd(dataReceivedDateEnd);
		skuMasterReject.setSku(sku);
		skuMasterReject.setSkuName(skuName);
		skuMasterReject.setSendStatus(sendStatus);
		if (StringUtils.isEmpty(skuMasterReject.getDataReceivedDateEnd())) {

			String datareceivedDateStar = skuMasterReject.getDataReceivedDateStart();

			skuMasterReject.setDataReceivedDateEnd(datareceivedDateStar);
		}

		int count = commonService.selectTableUpperLimitCount();
		int countManual = skuMasterRejectService.selectCount(skuMasterReject);
		if (count <= countManual) {
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<SkuMasterReject> putList = skuMasterRejectService.selectSkuMasterReject(skuMasterReject);

		if (CollectionUtils.isEmpty(putList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		modelView.addObject("putList", putList);
		return modelView;
	}

	@RequestMapping(value = "/sku_master_reject", params = "action=clear")
	public String skuMasterRejectClear(Model model) throws ParseException {
		logger.info("--- skuMasterRejectClear() start ---");

		String operationDate = commonService.getOperationDate();
		SkuMasterRejectForm form = new SkuMasterRejectForm();
		form.setDataReceivedDateStart(operationDate);
		form.setDataReceivedDateEnd(operationDate);
		model.addAttribute("skuMasterRejectForm", form);

		return "sku_master_reject";
	}

	@RequestMapping(value = "/sku_master_reject/{skuCode}", method = RequestMethod.GET)
	@ResponseBody
	public String getSkuName(@PathVariable String skuCode) {
		logger.info("--- SkuMasterRejectController.getSkuName() start ---");

		String skuName = "";

		if (!StringUtils.isEmpty(skuCode)) {
			skuName = commonService.getSkuName(skuCode);
		}

		return skuName;
	}

}
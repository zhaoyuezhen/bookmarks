package jp.co.groundinc.convertor.domain;

public class TransmissionLogMapperDetail {
	private String transmissionId;
	private String lineNo;
	private String errorCode;
	private String errorComment;
	public String getTransmissionId() {
		return transmissionId;
	}
	public void setTransmissionId(String transmissionId) {
		this.transmissionId = transmissionId;
	}
	public String getLineNo() {
		return lineNo;
	}
	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorComment() {
		return errorComment;
	}
	public void setErrorComment(String errorComment) {
		this.errorComment = errorComment;
	}
	
	
	
	
}

package jp.co.groundinc.convertor.domain;

public class SkuMasterReject {
	// 商品コード
	private String sku;
	// 商品名
	private String skuName;
	// 送信ステータス
	private String sendStatus;

	private String sendStatusName;

	// 処理結果概要
	private String errorMessage;
	// 更新日時
	private String updateDate;

	private String updateTime;

	private String dataReceivedDateStart;
	private String dataReceivedDateEnd;

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getSendStatusName() {
		return sendStatusName;
	}

	public void setSendStatusName(String sendStatusName) {
		this.sendStatusName = sendStatusName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getDataReceivedDateStart() {
		return dataReceivedDateStart;
	}

	public void setDataReceivedDateStart(String dataReceivedDateStart) {
		this.dataReceivedDateStart = dataReceivedDateStart;
	}

	public String getDataReceivedDateEnd() {
		return dataReceivedDateEnd;
	}

	public void setDataReceivedDateEnd(String dataReceivedDateEnd) {
		this.dataReceivedDateEnd = dataReceivedDateEnd;
	}

}

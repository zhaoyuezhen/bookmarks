package jp.co.groundinc.convertor.web.view;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.view.AbstractView;

public abstract class AbstractCsvView extends AbstractView {
	private String csvFileName;
	@Value("${AbstractCsvView.csvHeaderCode}")
	private String[] csvHeaderCode;
	@Value("${AbstractCsvView.csvHeaderName}")
	private String[] csvHeaderName;
	
    public void setCsvFileName(String fileName) {
        this.csvFileName = fileName;
    }
    
    public void setCsvHeaderCode(String[] csvHeaderCode) {
        this.csvHeaderCode = csvHeaderCode;
    }
    
    public void setCsvHeaderName(String[] csvHeaderName) {
        this.csvHeaderName = csvHeaderName;
    }
    
    public String[] getCsvHeaderCode() {
    	return this.csvHeaderCode;
    }
    
    public String[] getCsvHeaderName() {
        return this.csvHeaderName;
    }
    
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		response.setContentType("text/csv;charset=Shift_JIS");
		String fileName = new String(csvFileName.getBytes("Shift_JIS"), "ISO-8859-1");
		response.setHeader("Content-Disposition","attachment; filename=" + fileName);
		
		buildCsvDocument(model, request, response.getWriter());
	}
	
	protected abstract void buildCsvDocument(
			Map<String, Object> model, HttpServletRequest request, PrintWriter writer)
					throws Exception;

}

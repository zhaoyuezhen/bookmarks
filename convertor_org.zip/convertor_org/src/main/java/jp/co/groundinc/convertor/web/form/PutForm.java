package jp.co.groundinc.convertor.web.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class PutForm {
	//データ受信Start日
	@NotNull(message = "{put.dataReceivedDateStart.empty.message}")
	private String dataReceivedDateStart;
	//データ受信End日
	private String dataReceivedDateEnd;
	//作業状態
	private String workingStatus;
	//作業実績Start日
	private String operatedDateStart;
	//作業実績End日
	private String operatedDateEnd;
	//ステーション
	private String ppsId;
	//コンテナID
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{put.container.Halfangle.message}")
	private String containerId;
	//伝票番号
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{put.ticket.Halfangle.message}")
	private String expectedPutId;
	//商品コード
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{put.product.Halfangle.message}")
	private String sku;
	//商品名
	private String skuName;
	//イレギュラーフラグ 予実差異
	private String irregularFlag;

	public String getDataReceivedDateStart() {
		return dataReceivedDateStart;
	}

	public void setDataReceivedDateStart(String dataReceivedDateStart) {
		this.dataReceivedDateStart = dataReceivedDateStart;
	}

	public String getDataReceivedDateEnd() {
		return dataReceivedDateEnd;
	}

	public void setDataReceivedDateEnd(String dataReceivedDateEnd) {
		this.dataReceivedDateEnd = dataReceivedDateEnd;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}

	public String getOperatedDateStart() {
		return operatedDateStart;
	}

	public void setOperatedDateStart(String operatedDateStart) {
		this.operatedDateStart = operatedDateStart;
	}

	public String getOperatedDateEnd() {
		return operatedDateEnd;
	}

	public void setOperatedDateEnd(String operatedDateEnd) {
		this.operatedDateEnd = operatedDateEnd;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getExpectedPutId() {
		return expectedPutId;
	}

	public void setExpectedPutId(String expectedPutId) {
		this.expectedPutId = expectedPutId;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getIrregularFlag() {
		return irregularFlag;
	}

	public void setIrregularFlag(String irregularFlag) {
		this.irregularFlag = irregularFlag;
	}

	

}

package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.groundinc.convertor.domain.DailyStockFilecreat;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatCsv;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatReports;
@Mapper
public interface DailyStockFilecreatMapper {
	List<DailyStockFilecreatReports> selectDailyStockFilecreatReports(
			@Param("sku") String sku);
	
	List<DailyStockFilecreatCsv> selectDailyStockFilecreatCsv();
	
	void updateDate(DailyStockFilecreat dailyStockFilecreat);
	void updateTime(DailyStockFilecreat dailyStockFilecreat1);
	int selectCount();
	int insertStockDailyLog(DailyStockFilecreat dailyStockFilecreat1);
}

package jp.co.groundinc.convertor.domain;

public class PickList {

	private String pickListGroup;

	private String skuKind;

	private String largeAreaCode;

	private String incompleteOrderCount;

	private String processSequence;

	private String pickKind1;

	private String pickKind2;

	private String pickKind3;

	private String pickKind4;

	private String pickKind5;

	private String pickKind6;

	private String pickKind7;

	private String pickKind8;

	private String pickKind9;

	private String pickKind10;

	private String pickKind20;
	private String pickKind30;

	private String print1;

	private String print2;

	private String print3;

	private String print4;

	private String print5;

	private String print6;

	private String print7;

	private String print8;

	private String print9;

	private String print10;

	private String print20;
	private String print30;

	private String print12;
	private String printId;
	private String printDate;
	private String printTime;
	private String formId;
	private String formName;
	private String filePath;
	private String printer;
	private String userCode;
	private String createUser;
	private String createDate;
	private String createTime;
	private String updateUser;
	private String updateDate;
	private String updateTime;

	public String getPrintId() {
		return printId;
	}

	public void setPrintId(String printId) {
		this.printId = printId;
	}

	public String getPrintDate() {
		return printDate;
	}

	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}

	public String getPrintTime() {
		return printTime;
	}

	public void setPrintTime(String printTime) {
		this.printTime = printTime;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getPrinter() {
		return printer;
	}

	public void setPrinter(String printer) {
		this.printer = printer;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getProcessSequence() {
		return processSequence;
	}

	public void setProcessSequence(String processSequence) {
		this.processSequence = processSequence;
	}

	public String getPrint1() {
		return print1;
	}

	public void setPrint1(String print1) {
		this.print1 = print1;
	}

	public String getPrint2() {
		return print2;
	}

	public void setPrint2(String print2) {
		this.print2 = print2;
	}

	public String getPrint3() {
		return print3;
	}

	public void setPrint3(String print3) {
		this.print3 = print3;
	}

	public String getPrint4() {
		return print4;
	}

	public void setPrint4(String print4) {
		this.print4 = print4;
	}

	public String getPrint5() {
		return print5;
	}

	public void setPrint5(String print5) {
		this.print5 = print5;
	}

	public String getPrint6() {
		return print6;
	}

	public void setPrint6(String print6) {
		this.print6 = print6;
	}

	public String getPrint7() {
		return print7;
	}

	public void setPrint7(String print7) {
		this.print7 = print7;
	}

	public String getPrint8() {
		return print8;
	}

	public void setPrint8(String print8) {
		this.print8 = print8;
	}

	public String getPrint9() {
		return print9;
	}

	public void setPrint9(String print9) {
		this.print9 = print9;
	}

	public String getPrint10() {
		return print10;
	}

	public void setPrint10(String print10) {
		this.print10 = print10;
	}

	
	public String getPrint12() {
		return print12;
	}

	public void setPrint12(String print12) {
		this.print12 = print12;
	}

	public String getPickKind1() {
		return pickKind1;
	}

	public void setPickKind1(String pickKind1) {
		this.pickKind1 = pickKind1;
	}

	public String getPickKind2() {
		return pickKind2;
	}

	public void setPickKind2(String pickKind2) {
		this.pickKind2 = pickKind2;
	}

	public String getPickKind3() {
		return pickKind3;
	}

	public void setPickKind3(String pickKind3) {
		this.pickKind3 = pickKind3;
	}

	public String getPickKind4() {
		return pickKind4;
	}

	public void setPickKind4(String pickKind4) {
		this.pickKind4 = pickKind4;
	}

	public String getPickKind5() {
		return pickKind5;
	}

	public void setPickKind5(String pickKind5) {
		this.pickKind5 = pickKind5;
	}

	public String getPickKind6() {
		return pickKind6;
	}

	public void setPickKind6(String pickKind6) {
		this.pickKind6 = pickKind6;
	}

	public String getPickKind7() {
		return pickKind7;
	}

	public void setPickKind7(String pickKind7) {
		this.pickKind7 = pickKind7;
	}

	public String getPickKind8() {
		return pickKind8;
	}

	public void setPickKind8(String pickKind8) {
		this.pickKind8 = pickKind8;
	}

	public String getPickKind9() {
		return pickKind9;
	}

	public void setPickKind9(String pickKind9) {
		this.pickKind9 = pickKind9;
	}

	public String getPickKind10() {
		return pickKind10;
	}

	public void setPickKind10(String pickKind10) {
		this.pickKind10 = pickKind10;
	}

	
	public String getPickKind20() {
		return pickKind20;
	}

	public void setPickKind20(String pickKind20) {
		this.pickKind20 = pickKind20;
	}

	public String getPickKind30() {
		return pickKind30;
	}

	public void setPickKind30(String pickKind30) {
		this.pickKind30 = pickKind30;
	}

	public String getPrint20() {
		return print20;
	}

	public void setPrint20(String print20) {
		this.print20 = print20;
	}

	public String getPrint30() {
		return print30;
	}

	public void setPrint30(String print30) {
		this.print30 = print30;
	}

	public String getPickListGroup() {
		return pickListGroup;
	}

	public void setPickListGroup(String pickListGroup) {
		this.pickListGroup = pickListGroup;
	}

	public String getSkuKind() {
		return skuKind;
	}

	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}

	public String getLargeAreaCode() {
		return largeAreaCode;
	}

	public void setLargeAreaCode(String largeAreaCode) {
		this.largeAreaCode = largeAreaCode;
	}

	public String getIncompleteOrderCount() {
		return incompleteOrderCount;
	}

	public void setIncompleteOrderCount(String incompleteOrderCount) {
		this.incompleteOrderCount = incompleteOrderCount;
	}

}

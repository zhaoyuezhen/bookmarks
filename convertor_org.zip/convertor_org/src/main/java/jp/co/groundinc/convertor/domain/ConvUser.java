package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class ConvUser implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String userCode;
	private String userName;
	private String password;
	private String passwordChangeDate;
	private String oldPassword;
	private String lockFlag;
	private String authorityKind;

	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPasswordChangeDate() {
		return passwordChangeDate;
	}
	public void setPasswordChangeDate(String passwordChangeDate) {
		this.passwordChangeDate = passwordChangeDate;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getLockFlag() {
		return lockFlag;
	}
	public void setLockFlag(String lockFlag) {
		this.lockFlag = lockFlag;
	}
	public String getAuthorityKind() {
		return authorityKind;
	}
	public void setAuthorityKind(String authorityKind) {
		this.authorityKind = authorityKind;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}

package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.TransmissionLog;
import jp.co.groundinc.convertor.domain.TransmissionLogCsv;
import jp.co.groundinc.convertor.domain.TransmissionLogMapperDetail;
import jp.co.groundinc.convertor.mapper.TransmissionLogMapper;

@Service
public class TransmissionLogService {
	@Autowired
	TransmissionLogMapper transmissionLogMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<TransmissionLog> findCommunicationMonitor(TransmissionLog communicationMonitor) {
		logger.info("--- TransmissionLogService.findCommunicationMonitor() start ---");
		List<TransmissionLog> transmissionLogList = transmissionLogMapper
				.findcommunicationMonitor(communicationMonitor);
		return transmissionLogList;
	}
	public int selectCountt(TransmissionLog communicationMonitor) {
		logger.info("--- TransmissionLogService.selectCountt() start ---");
		int count = transmissionLogMapper
				.selectCountt(communicationMonitor);
		return count;
	}

	public TransmissionLog findCommunicationMonitor(String transmissionid) {
		logger.info("--- TransmissionLogService.findCommunicationMonitor() start ---");
		TransmissionLog transmissionLog = transmissionLogMapper.findcommunicationMonitorIdInfo(transmissionid);
		return transmissionLog;
	}

	public List<TransmissionLogMapperDetail> selectErrorInfo(String transmissionid) {
		logger.info("--- TransmissionLogService.selectErrorInfo() start ---");
		List<TransmissionLogMapperDetail> transmissionLogDetailList = transmissionLogMapper
				.selectErrorInfo(transmissionid);
		return transmissionLogDetailList;
	}
	
	public List<TransmissionLogCsv> findTransmissionLogCsv(
			String startDate, String endDate, 
			String transmissionType, String transMissionTypeDetail, 
			String sendrecvKind, String processingStatus) {
		logger.info("--- TransmissionLogService.findTransmissionLogCsv() start ---");
		
		List<TransmissionLogCsv> transmissionLogCsvList = 
				transmissionLogMapper.selectTransmissionLogCsv(
						CommonUtility.dateFomat(startDate),CommonUtility.dateFomat(endDate),
						transmissionType, transMissionTypeDetail, sendrecvKind,processingStatus);
		return transmissionLogCsvList;
	}
}

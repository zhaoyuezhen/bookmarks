package jp.co.groundinc.convertor.domain;

import java.math.BigDecimal;

public class StockInquiryCsv {
	private String skuStart ;
	private String skuEnd;
	private String sku;
	private String skuName;
	private BigDecimal totalCbmAbove;
	private BigDecimal totalCbmUnder;
	private String totalCbm;
	private String retentionDays;
	private String stockQty;
	private String cbm;
	private String lastedPutDate;
	private String latestShipmentDate;
	private String csvExportDate;
	private String csvExportTime;
	
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	public String getSkuStart() {
		return skuStart;
	}
	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}
	public String getSkuEnd() {
		return skuEnd;
	}
	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public BigDecimal getTotalCbmAbove() {
		return totalCbmAbove;
	}
	public void setTotalCbmAbove(BigDecimal totalCbmAbove) {
		this.totalCbmAbove = totalCbmAbove;
	}
	public BigDecimal getTotalCbmUnder() {
		return totalCbmUnder;
	}
	public void setTotalCbmUnder(BigDecimal totalCbmUnder) {
		this.totalCbmUnder = totalCbmUnder;
	}
	public String getTotalCbm() {
		return totalCbm;
	}
	public void setTotalCbm(String totalCbm) {
		this.totalCbm = totalCbm;
	}
	public String getRetentionDays() {
		return retentionDays;
	}
	public void setRetentionDays(String retentionDays) {
		this.retentionDays = retentionDays;
	}
	public String getStockQty() {
		return stockQty;
	}
	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public String getLastedPutDate() {
		return lastedPutDate;
	}
	public void setLastedPutDate(String lastedPutDate) {
		this.lastedPutDate = lastedPutDate;
	}
	public String getLatestShipmentDate() {
		return latestShipmentDate;
	}
	public void setLatestShipmentDate(String latestShipmentDate) {
		this.latestShipmentDate = latestShipmentDate;
	}
	
}

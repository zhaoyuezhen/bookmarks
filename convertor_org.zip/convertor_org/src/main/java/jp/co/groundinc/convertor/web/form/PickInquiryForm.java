package jp.co.groundinc.convertor.web.form;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class PickInquiryForm implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "{order.datareceiveddateStart.empty.message}")
	private String datareceiveddateStart;
	private String datareceiveddateEnd;

	@NotEmpty(message = "{order.datareceiveddateStart.empty.message}")
	private String dataReceivedTimeStart;
	private String dataReceivedTimeEnd;
	
	private String expecteddateStart;
	private String expecteddateEnd;
	private String operateddateStart;
	private String operateddateEnd;
	
	private String operatedTimeStart;
	private String operatedTimeEnd;
	
	private String ppsid;
	private String ppsbinid;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{order.ticket.Halfangle.message}")
	private String orderid;
	private String workingstatus;
	private String irregularKindName;
	private String irregularKind;
	private String orderKindName;
	private String orderKind;
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "{order.product.Halfangle.message}")
	private String sku;
	private String skuName;
	private boolean allMissingFlag;
	private String createTime;
	private String dataReceivedDateTime;
	
	public String getDataReceivedDateTime() {
		return dataReceivedDateTime;
	}

	public void setDataReceivedDateTime(String dataReceivedDateTime) {
		this.dataReceivedDateTime = dataReceivedDateTime;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public boolean isAllMissingFlag() {
		return allMissingFlag;
	}

	public void setAllMissingFlag(boolean allMissingFlag) {
		this.allMissingFlag = allMissingFlag;
	}

	public String getOrderKindName() {
		return orderKindName;
	}

	public void setOrderKindName(String orderKindName) {
		this.orderKindName = orderKindName;
	}

	public String getOrderKind() {
		return orderKind;
	}

	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}

	public String getDatareceiveddateStart() {
		return datareceiveddateStart;
	}

	public void setDatareceiveddateStart(String datareceiveddateStart) {
		this.datareceiveddateStart = datareceiveddateStart;
	}

	public String getDatareceiveddateEnd() {
		return datareceiveddateEnd;
	}

	public void setDatareceiveddateEnd(String datareceiveddateEnd) {
		this.datareceiveddateEnd = datareceiveddateEnd;
	}

	public String getExpecteddateStart() {
		return expecteddateStart;
	}

	public void setExpecteddateStart(String expecteddateStart) {
		this.expecteddateStart = expecteddateStart;
	}

	public String getExpecteddateEnd() {
		return expecteddateEnd;
	}

	public void setExpecteddateEnd(String expecteddateEnd) {
		this.expecteddateEnd = expecteddateEnd;
	}

	public String getOperateddateStart() {
		return operateddateStart;
	}

	public void setOperateddateStart(String operateddateStart) {
		this.operateddateStart = operateddateStart;
	}

	public String getOperateddateEnd() {
		return operateddateEnd;
	}

	public void setOperateddateEnd(String operateddateEnd) {
		this.operateddateEnd = operateddateEnd;
	}

	public String getPpsid() {
		return ppsid;
	}

	public void setPpsid(String ppsid) {
		this.ppsid = ppsid;
	}

	public String getPpsbinid() {
		return ppsbinid;
	}

	public void setPpsbinid(String ppsbinid) {
		this.ppsbinid = ppsbinid;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getWorkingstatus() {
		return workingstatus;
	}

	public void setWorkingstatus(String workingstatus) {
		this.workingstatus = workingstatus;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	
	public String getIrregularKind() {
		return irregularKind;
	}

	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	
	public String getDataReceivedTimeStart() {
		return dataReceivedTimeStart;
	}

	public void setDataReceivedTimeStart(String dataReceivedTimeStart) {
		this.dataReceivedTimeStart = dataReceivedTimeStart;
	}

	public String getDataReceivedTimeEnd() {
		return dataReceivedTimeEnd;
	}

	public void setDataReceivedTimeEnd(String dataReceivedTimeEnd) {
		this.dataReceivedTimeEnd = dataReceivedTimeEnd;
	}

	public String getOperatedTimeStart() {
		return operatedTimeStart;
	}

	public void setOperatedTimeStart(String operatedTimeStart) {
		this.operatedTimeStart = operatedTimeStart;
	}

	public String getOperatedTimeEnd() {
		return operatedTimeEnd;
	}

	public void setOperatedTimeEnd(String operatedTimeEnd) {
		this.operatedTimeEnd = operatedTimeEnd;
	}


}

package jp.co.groundinc.convertor.web;

import java.math.BigDecimal;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.domain.StockInquiry;
import jp.co.groundinc.convertor.domain.StockInquiryDetail;
import jp.co.groundinc.convertor.service.StockInquiryService;
import jp.co.groundinc.convertor.web.form.StockInquiryForm;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration

public class StockInquiryDetailController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MessageSource messageSource;
	
	@Autowired
	StockInquiryService stockInquiryService;

	@ModelAttribute("stockInquiryForm")
	public StockInquiryForm stockInquiryForm(HttpServletRequest request) {
		logger.info("--- StockInquiryDetailController.stockInquiryForm() start ---");
		StockInquiryForm stockInquiryForm = (StockInquiryForm) request.getSession().getAttribute("stockInquiryForm");
		return stockInquiryForm;
	}

	@RequestMapping(value = "/stockinquirydetail")
	public ModelAndView stockInquiryDetail(@RequestParam("sku") String sku, ModelAndView modelView,HttpServletRequest request) {
		modelView.setViewName("stock_inquiry_detail");
		logger.info("--- StockInquiryDetailController.stockInquiryDetail() start ---");
		List<StockInquiryDetail> inquiryDetailList = stockInquiryService.findStockInquiryDetailInfo(sku);
		StockInquiry stockInquiry = stockInquiryService.findStockInquiryInfo(sku);
		request.getSession().setAttribute("productname", "");
		modelView.addObject("stockInquiry", stockInquiry);
		modelView.addObject("inquiryDetailList", inquiryDetailList);
		return modelView;
	}

	@RequestMapping(value = "/stockinquirydetail", params = "action=Detailback")
	public ModelAndView stockInquiryDetailBack(HttpServletRequest request, ModelAndView modelView) {
		logger.info("--- stockInquiryDetailBack() start ---");
		modelView.setViewName("/stock_inquiry");
		StockInquiryForm stockInquiryForm = (StockInquiryForm) request.getSession().getAttribute("stockInquiryForm");
		int sumPiece = 0;
		float sumCbm = 0.0f;
		logger.info("--- selectStockInquiryInfo() start ---");
		modelView.setViewName("/stock_inquiry");
		String skuStart = stockInquiryForm.getSkuStart();
		String skuEnd = stockInquiryForm.getSkuEnd();
		if (!StringUtils.isEmpty(skuStart) && StringUtils.isEmpty(skuEnd)) {
			skuEnd = skuStart;
		}
		String skuName = stockInquiryForm.getSkuName();
		String totalCbmUnder = stockInquiryForm.getTotalCbmUnder();
		String totalCbmAbove = stockInquiryForm.getTotalCbmAbove();
		String retentionDays = stockInquiryForm.getRetentionDays();
		StockInquiry stockInquiry = new StockInquiry();
		stockInquiry.setSkuStart(skuStart);
		stockInquiry.setSkuEnd(skuEnd);
		stockInquiry.setSkuName(skuName);
		if (!StringUtils.isEmpty(totalCbmUnder)) {
			BigDecimal totalCbmUnders = new BigDecimal(totalCbmUnder);
			stockInquiry.setTotalCbmUnder(totalCbmUnders);

		}
		if (!StringUtils.isEmpty(totalCbmAbove)) {
			BigDecimal totalCbmAboves = new BigDecimal(totalCbmAbove);
			stockInquiry.setTotalCbmAbove(totalCbmAboves);
		}

		stockInquiry.setRetentionDays(retentionDays);
		List<StockInquiry> stockInquirylist = stockInquiryService.findStockInquiryInfo(stockInquiry);
		for (int i = 0; i < stockInquirylist.size(); i++) {
			if (!StringUtils.isEmpty(stockInquirylist.get(i).getStockQty())
					&& !StringUtils.isEmpty(stockInquirylist.get(i).getTotalCbm())) {
				sumPiece = sumPiece + Integer.valueOf(stockInquirylist.get(i).getStockQty()).intValue();
				sumCbm = sumCbm + Float.parseFloat(stockInquirylist.get(i).getTotalCbm());
			}

		}
		modelView.addObject("sumPiece", sumPiece);
		modelView.addObject("sumCbm", sumCbm);
		modelView.addObject("sumCommodity", stockInquirylist.size());
		modelView.addObject("stockInquirylist", stockInquirylist);
		return modelView;
	}

}

package jp.co.groundinc.convertor.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import jp.co.groundinc.convertor.domain.SkuMasterReject;

@Mapper
public interface SkuMasterRejectMapper {
	List<SkuMasterReject> selectSkuMasterReject(SkuMasterReject skuMasterReject);
	int selectCount(SkuMasterReject skuMasterReject);
}

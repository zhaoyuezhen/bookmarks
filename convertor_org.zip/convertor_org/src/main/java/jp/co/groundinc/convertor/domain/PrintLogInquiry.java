package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

public class PrintLogInquiry implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String userCode;
	
	private String userName;
	
	/**　帳票ID　*/
	private String formId;
	
	/**　帳票名　*/
	private String formName;
	
	/**　フェイル名　*/
	private String filePath;
	
	private String printDate;
	
	private String printDateStart;
	
	private String printTime;
	
	private String printTimeStart;
	
	private String printTimeEnd;
	
	private String printer;
	
	private String printName;
	
	private String printLogDateTime;
	
	private String fileName;
	
	
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getPrintLogDateTime() {
		return printLogDateTime;
	}

	public void setPrintLogDateTime(String printLogDateTime) {
		this.printLogDateTime = printLogDateTime;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getPrintDate() {
		return printDate;
	}

	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}

	public String getPrintTime() {
		return printTime;
	}

	public void setPrintTime(String printTime) {
		this.printTime = printTime;
	}

	public String getPrinter() {
		return printer;
	}

	public void setPrinter(String printer) {
		this.printer = printer;
	}

	public String getPrintName() {
		return printName;
	}

	public void setPrintName(String printName) {
		this.printName = printName;
	}

	public String getPrintDateStart() {
		return printDateStart;
	}

	public void setPrintDateStart(String printDateStart) {
		this.printDateStart = printDateStart;
	}

	public String getPrintTimeStart() {
		return printTimeStart;
	}

	public void setPrintTimeStart(String printTimeStart) {
		this.printTimeStart = printTimeStart;
	}

	public String getPrintTimeEnd() {
		return printTimeEnd;
	}

	public void setPrintTimeEnd(String printTimeEnd) {
		this.printTimeEnd = printTimeEnd;
	}

}

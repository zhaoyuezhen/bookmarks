package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.AuditInquiry;
import jp.co.groundinc.convertor.domain.AuditInquiryDetail;
import jp.co.groundinc.convertor.domain.AuditInquiryDetailCsv;
import jp.co.groundinc.convertor.domain.AuditInquiryReports;
import jp.co.groundinc.convertor.mapper.AuditInquiryMapper;

@Service
@EnableAutoConfiguration
public class AuditInquiryService {
	@Autowired
	AuditInquiryMapper auditInquiryMapper;
	
	@Autowired
	CommonUtility commonUtility;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<AuditInquiry> findAuditInquiry(AuditInquiry auditInquiry) {
		logger.info("--- AuditInquiryService.findAuditInquiry() start ---");
		if (!StringUtils.isEmpty(auditInquiry.getStartDateStart())) {
			String startDateStart = CommonUtility.dateFomat(auditInquiry.getStartDateStart());
			auditInquiry.setStartDateStart(startDateStart);
		}

		if (!StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {
			String startDateEnd = CommonUtility.dateFomat(auditInquiry.getStartDateEnd());
			auditInquiry.setStartDateEnd(startDateEnd);;
		}
		
		List<AuditInquiry> AuditInquiryList = auditInquiryMapper.selectAuditInquiry(auditInquiry);
		return AuditInquiryList;
	}
	public int selectCountt(AuditInquiry auditInquiry) {
		logger.info("--- AuditInquiryService.findAuditInquiry() start ---");
		if (!StringUtils.isEmpty(auditInquiry.getStartDateStart())) {
			String startDateStart = CommonUtility.dateFomat(auditInquiry.getStartDateStart());
			auditInquiry.setStartDateStart(startDateStart);
		}

		if (!StringUtils.isEmpty(auditInquiry.getStartDateEnd())) {
			String startDateEnd = CommonUtility.dateFomat(auditInquiry.getStartDateEnd());
			auditInquiry.setStartDateEnd(startDateEnd);;
		}
		
		int count = auditInquiryMapper.selectCountt(auditInquiry);
		return count;
	}
	public AuditInquiry findAuditInquiryInfo(String auditNo) {
		logger.info("--- AuditInquiryService.findAuditInquiryInfo() start ---");
		AuditInquiry auditInquiry = auditInquiryMapper.selectAuditInquiryInfo(auditNo);
		return auditInquiry;
	}
	
	public List<AuditInquiryDetail> findAuditInquiryDetailInfo(String auditNo) {
		logger.info("--- AuditInquiryService.findAuditInquiryDetailInfo() start ---");
		List<AuditInquiryDetail> AuditInquiryDetailList = auditInquiryMapper.selectAuditInquiryDetail(auditNo);
		return AuditInquiryDetailList;
	}
	
	public List<AuditInquiryDetailCsv> findAuditInquiryDetailCsv(List<String> orderIdList) {
		logger.info("--- AuditInquiryService.findAuditInquiryDetailCsv() start ---");
		
		List<AuditInquiryDetailCsv> auditInquiryDetailCsvList = 
				auditInquiryMapper.selectAuditInquiryDetailCsv(orderIdList);
		
		return auditInquiryDetailCsvList;
	}
	
	public List<AuditInquiryReports> findAuditInquiryReport(String auditNo) {
		logger.info("--- AuditInquiryService.findAuditInquiryReport() start ---");
		
		List<AuditInquiryReports> auditInquiryReportList = 
				auditInquiryMapper.selectAuditInquiryReport(auditNo);
		
		return auditInquiryReportList;
	}
	public List<AuditInquiryReports> findAuditInquiryExpectReport(
			String auditNo) {
		logger.info("--- AuditInquiryService.findAuditInquiryExpectReport() start ---");
		
		List<AuditInquiryReports> auditInquiryExpectReportList = 
				auditInquiryMapper.selectAuditInquiryExpectReport(auditNo);
		
		return auditInquiryExpectReportList;
	}
	public String selectPrintLogSeqence() {
		logger.info("--- AuditInquiryService.selectPrintLogSeqence() start ---");
		
		String Seqence  = auditInquiryMapper.selectPrintLogSeqence();
		return Seqence;
		
	}
	public void insertPrintLog(AuditInquiry auditInquiry ){
		logger.info("--- AuditInquiryService.insertPrintLog() start ---");
		auditInquiryMapper.insertPrintLog(auditInquiry);
		
	}
	
	public void insertAuditExpectationDetail(AuditInquiryDetail auditInquiryDetail){
		logger.info("--- AuditInquiryService.insertAuditExpectationDetail() start ---");
		auditInquiryMapper.insertAuditExpectationDetail(auditInquiryDetail);
		
	}

}

package jp.co.groundinc.convertor.web.report;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

public class SkuMasterDetailReport extends AbstractReport {
	public SkuMasterDetailReport(String reportName) {
		super(reportName);
	}

	@Override
	public void buildDocument(List<?> documentDataList, HttpServletRequest request)
			throws Exception {
		setDocumentDataList(documentDataList, request);
	}

}

package jp.co.groundinc.convertor.web.utility;

import java.beans.PropertyEditorSupport;

public class DatePropertyEditor extends PropertyEditorSupport {
    @Override
    public void setAsText(String text) {
        if (text == null) {
            return;
        }
        setValue(text.replaceAll("-", ""));
    }

    @Override
    public String getAsText() {
        String value = (String) getValue();
        if (value == null || value.trim().length() == 0) {
        	value = "";
        } else {
    		value = value.trim().replaceAll("(\\d{4})(\\d{2})(\\d{2})", "$1-$2-$3");	
        }
        
        return value;
    }
}

package jp.co.groundinc.convertor.domain;

public class ManualPickInstruction {
	private String orderId;
	private String orderLineId;
	private String skuStart ;
	private String skuEnd;
	private String sku;
	private String skuName;
	private String stockQty;
	private int expectedQty;
	private String processSequenceNo;
	private String dataReceivedDate;
	private String expectedDate;
	private String orderKind;
	private String workingStatus;
	private String creatUser;
	private String creatDate;
	private String creatTime;
	private String upateUser;
	private String upadateDate;
	private String upadateTime;
	private int priority;
	private String fileOutputFlag;

	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getDataReceivedDate() {
		return dataReceivedDate;
	}
	public void setDataReceivedDate(String dataReceivedDate) {
		this.dataReceivedDate = dataReceivedDate;
	}
	public String getExpectedDate() {
		return expectedDate;
	}
	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}
	public String getOrderKind() {
		return orderKind;
	}
	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}
	public String getWorkingStatus() {
		return workingStatus;
	}
	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}
	public String getCreatUser() {
		return creatUser;
	}
	public void setCreatUser(String creatUser) {
		this.creatUser = creatUser;
	}
	public String getCreatDate() {
		return creatDate;
	}
	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}
	public String getCreatTime() {
		return creatTime;
	}
	public void setCreatTime(String creatTime) {
		this.creatTime = creatTime;
	}
	public String getUpateUser() {
		return upateUser;
	}
	public void setUpateUser(String upateUser) {
		this.upateUser = upateUser;
	}
	public String getUpadateDate() {
		return upadateDate;
	}
	public void setUpadateDate(String upadateDate) {
		this.upadateDate = upadateDate;
	}
	public String getUpadateTime() {
		return upadateTime;
	}
	public void setUpadateTime(String upadateTime) {
		this.upadateTime = upadateTime;
	}
	public String getFileOutputFlag() {
		return fileOutputFlag;
	}
	public void setFileOutputFlag(String fileOutputFlag) {
		this.fileOutputFlag = fileOutputFlag;
	}
	public String getProcessSequenceNo() {
		return processSequenceNo;
	}
	public void setProcessSequenceNo(String processSequenceNo) {
		this.processSequenceNo = processSequenceNo;
	}
	public int getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}
	public String getSkuStart() {
		return skuStart;
	}
	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}
	public String getSkuEnd() {
		return skuEnd;
	}
	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getStockQty() {
		return stockQty;
	}
	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}
	
	
	
}

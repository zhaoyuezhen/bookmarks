package jp.co.groundinc.convertor.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.domain.AuthUser;
import jp.co.groundinc.convertor.domain.ConvUser;
import jp.co.groundinc.convertor.mapper.CommonMapper;

@Service
public class AuthUserService implements UserDetailsService{
	@Autowired
	CommonMapper commonMapper;
	
	public ConvUser selectUserByUserCd(String userCd) {
		return commonMapper.selectUserByUserCd(userCd);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		ConvUser convUser = selectUserByUserCd(username);
		if (convUser == null) {
			throw new UsernameNotFoundException("User not found for name: " + username);
		}

		return new AuthUser(convUser);
	}
	
	public Map<String, String> getAllAuthorityKinds() {
		Map<String, String> authorityKindMap = new HashMap<String, String>();
		
		List<String> authorityKindsList = commonMapper.selectAllAuthorityKinds();
		for(String authorityKinds : authorityKindsList){
			authorityKindMap.put(authorityKinds.split(":")[0], authorityKinds.split(":")[1]);
		}
		
		return authorityKindMap;
	}
}

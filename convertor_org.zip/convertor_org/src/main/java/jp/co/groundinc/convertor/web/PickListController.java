package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.domain.PickList;
import jp.co.groundinc.convertor.domain.PickListCsv;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.PickListService;
import jp.co.groundinc.convertor.web.form.PickListForm;
import jp.co.groundinc.convertor.web.report.PickListOrderReport;
import jp.co.groundinc.convertor.web.report.PickListOrderReport1;
import jp.co.groundinc.convertor.web.report.PickListTotalReport;
import jp.co.groundinc.convertor.web.report.PickListTotalReport1;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class PickListController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	PickListService pickListService;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("pickListForm")
	public PickListForm viewPicklistCount() {
		logger.info("--- PickListController.viewPicklistCount() start ---");
		PickListForm pickListForm = new PickListForm();
		List<PickList> list = pickListService.selectPickList();
		pickListForm.setIncompleteOrderCount1(list.get(0).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount2(list.get(1).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount3(list.get(2).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount4(list.get(3).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount5(list.get(4).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount6(list.get(5).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount7(list.get(6).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount8(list.get(7).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount9(list.get(8).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount10(list.get(9).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount11(list.get(10).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount12(list.get(11).getIncompleteOrderCount());
		pickListForm.setAllMissingCount(list.get(12).getIncompleteOrderCount());
		return pickListForm;
	}

	@ModelAttribute("printer")
	public List<Translate> printer() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer2() {
		logger.info("--- PickListController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer3() {
		logger.info("--- PickListController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer4() {
		logger.info("--- PickListController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer5() {
		logger.info("--- PickListController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer6() {
		logger.info("--- PickListController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer7() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer8() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer9() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer10() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer11() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("printer")
	public List<Translate> printer12() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}
	
	@ModelAttribute("printer")
	public List<Translate> printer13() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PrinterCode");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType2() {
		logger.info("--- PrintLogInquiryController.printer() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType3() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType4() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType5() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType6() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType7() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType8() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType9() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType10() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("pickingListType")
	public List<Translate> pickingListType11() {
		logger.info("--- PrintLogInquiryController.pickingListType() start ---");
		return commonService.getTranslateList("PickingListType");
	}

	@ModelAttribute("orderPick")
	public String orderPick() throws ParseException {
		logger.info("--- PrintLogInquiryController.orderPick() start ---");
		return pickListService.getOrderPick();
	}

	@ModelAttribute("totalPick")
	public String totalPick() throws ParseException {
		logger.info("--- PrintLogInquiryController.totalPick() start ---");
		return pickListService.getTotalPick();
	}

	@ModelAttribute("note1")
	public String note1() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote1();
	}

	@ModelAttribute("note2")
	public String note2() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote2();
	}

	@ModelAttribute("note3")
	public String note3() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote3();
	}

	@ModelAttribute("note4")
	public String note4() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote4();
	}

	@ModelAttribute("note5")
	public String note5() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote5();
	}

	@ModelAttribute("note6")
	public String note6() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote6();
	}

	@ModelAttribute("note7")
	public String note7() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote7();
	}

	@ModelAttribute("note8")
	public String note8() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote8();
	}

	@ModelAttribute("note9")
	public String note9() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote9();
	}

	@ModelAttribute("note10")
	public String note10() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote10();
	}

	@ModelAttribute("note11")
	public String note11() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote11();
	}

	@ModelAttribute("note12")
	public String note12() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote12();
	}
	
	@ModelAttribute("note13")
	public String note13() throws ParseException {
		logger.info("--- PrintLogInquiryController.note() start ---");
		return pickListService.getNote13();
	}

	@RequestMapping("/pick_list")
	public String viewPickList(Model model, HttpServletRequest request) {
		logger.info("--- PickListController.pickList() start ---");
		PickListForm pickListForm = new PickListForm();
		model.addAttribute("/PickList", pickListForm);
		return "pick_list";
	}

	@RequestMapping(value = "/pick_list", params = "action=print")
	public ModelAndView pickListPrint(@Validated @ModelAttribute("pickListForm") PickListForm pickListForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) throws Exception {
		logger.info("--- pickListPrint() start ---");
		modelView.setViewName("/pick_list");
		if (StringUtils.isEmpty(pickListForm.getLargeAreaCode9())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode8())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode7())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode6())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode5())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode4())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode3())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode2())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode1())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode10())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode20())
				&& StringUtils.isEmpty(pickListForm.getLargeAreaCode30())
				&& StringUtils.isEmpty(pickListForm.getAllMissing1())) {

			String message = messageSource.getMessage("Common.Search.Message.E005", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		//String timeStemp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(dt);
		String sysTime = dfTime.format(dt);
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode9())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint9());	
			pickList.setPickKind9(pickListForm.getPickKind9());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode9()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind9().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint9());
					orderReport1.exportReport(pickListForm.getPrint9());
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint9());
					totalReport1.exportReport(pickListForm.getPrint9());
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				}
			}
		}

		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode8())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint8());
			pickList.setPickKind8(pickListForm.getPickKind8());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode8()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind8().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint8());
					orderReport1.exportReport(pickListForm.getPrint8());
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint8());
					totalReport1.exportReport(pickListForm.getPrint8());
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				}
			}
		}

		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode7())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint7());
			pickList.setPickKind7(pickListForm.getPickKind7());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode7()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind7().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint7());
					orderReport1.exportReport(pickListForm.getPrint7());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint7());
					totalReport1.exportReport(pickListForm.getPrint7());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}

		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode6())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint6());
			pickList.setPickKind6(pickListForm.getPickKind6());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode6()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind6().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint6());
					orderReport1.exportReport(pickListForm.getPrint6());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint6());
					totalReport1.exportReport(pickListForm.getPrint6());
				
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}

		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode5())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint5());
			pickList.setPickKind5(pickListForm.getPickKind5());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode5()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind5().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint5());
					orderReport1.exportReport(pickListForm.getPrint5());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint5());
					totalReport1.exportReport(pickListForm.getPrint5());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode4())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint4());
			pickList.setPickKind4(pickListForm.getPickKind4());
			pickList.setLargeAreaCode((pickListForm.getLargeAreaCode4()));
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind4().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint4());
					orderReport1.exportReport(pickListForm.getPrint4());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint4());
					totalReport1.exportReport(pickListForm.getPrint4());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode3())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint3());	
			pickList.setPickKind3(pickListForm.getPickKind3());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode3());
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind3().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint3());
					orderReport1.exportReport(pickListForm.getPrint3());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint3());
					totalReport1.exportReport(pickListForm.getPrint3());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog()+ ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode2())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint2());
			pickList.setPickKind2(pickListForm.getPickKind2());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode2());
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind2().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea29OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint2());
					orderReport1.exportReport(pickListForm.getPrint2());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea29TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint2());
					totalReport1.exportReport(pickListForm.getPrint2());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode1())) {
			String processSequenceNo = pickListService.selectprocessSequenceNo().trim();
			PickList pickList = new PickList();
			pickList.setProcessSequence(processSequenceNo);
			pickList.setPrintId(processSequenceNo);
			pickList.setPrintDate(commonService.getPrintdate());
			pickList.setPrintTime(sysTime);
			pickList.setPrinter(pickListForm.getPrint1().trim());
			pickList.setUserCode(userDetails.getUsername());
			pickList.setCreateUser(userDetails.getUsername());
			pickList.setCreateDate(sysDate);
			pickList.setCreateTime(sysTime);
			pickList.setUpdateUser(userDetails.getUsername());
			pickList.setUpdateDate(sysDate);
			pickList.setUpdateTime(sysTime);
			pickList.setPickKind1(pickListForm.getPickKind1());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode1().trim());
			int count = pickListService.updateOrderAreaInterface(pickList);
			if (count > 0) {
				List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea1OrderCsv(processSequenceNo);
				if(!CollectionUtils.isEmpty(pickListOrderCsvList)){
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint1());
					orderReport1.exportReport(pickListForm.getPrint1());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
				List<PickListCsv> pickListTotaruCsvList = pickListService.findPickListArea1TotaruCsv(processSequenceNo);
				if(!CollectionUtils.isEmpty(pickListTotaruCsvList)){
					PickListTotalReport totalreport = new PickListTotalReport("PickListTotalReport");
					PickListTotalReport1 totalreport1 = new PickListTotalReport1("PickListTotalReport1");
					totalreport.buildDocument(pickListTotaruCsvList, request);
					totalreport1.buildDocument(pickListTotaruCsvList, request);
					totalreport.exportReport(pickListForm.getPrint1());
					totalreport1.exportReport(pickListForm.getPrint1());
					
					pickList.setFormId(totalreport1.getReportFileName());
					pickList.setFormName(totalreport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalreport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}

			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode30())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint30().trim());
			pickList.setPickKind30(pickListForm.getPickKind30().trim());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode30().trim());
			int count = pickListService.updateOrderSendStatusInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind30().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea1030OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint30());
					orderReport1.exportReport(pickListForm.getPrint30());
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea1030TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint30());
					totalReport1.exportReport(pickListForm.getPrint30());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode20())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);	
			pickList.setPrinter(pickListForm.getPrint20());
			pickList.setPickKind20(pickListForm.getPickKind20());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode20());
			int count = pickListService.updateOrderSendStatusInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind20().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea1030OrderCsv(pickList);
					
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint20());
					orderReport1.exportReport(pickListForm.getPrint20());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea1030TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint20());
					totalReport1.exportReport(pickListForm.getPrint20());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);

				}
			}
		}
		if (!StringUtils.isEmpty(pickListForm.getLargeAreaCode10())) {
			PickList pickList = this.getOrderTotalInfo(userDetails, sysDate, sysTime);
			pickList.setPrinter(pickListForm.getPrint10());
			pickList.setPickKind10(pickListForm.getPickKind10());
			pickList.setLargeAreaCode(pickListForm.getLargeAreaCode10());
			int count = pickListService.updateOrderSendStatusInterface(pickList);
			if (count > 0) {
				if (pickListForm.getPickKind10().equals(CommonConstant.FLAG_ON)) {
					List<PickListCsv> pickListOrderCsvList = pickListService.findPickListArea1030OrderCsv(pickList);
					PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
					PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
					orderReport.buildDocument(pickListOrderCsvList, request);
					orderReport1.buildDocument(pickListOrderCsvList, request);
					orderReport.exportReport(pickListForm.getPrint10());
					orderReport1.exportReport(pickListForm.getPrint10());
					
					pickList.setFormId(orderReport1.getReportFileName());
					pickList.setFormName(
							orderReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
					
				} else {
					List<PickListCsv> pickListTotalCsvList = pickListService.findPickListArea1030TotalCsv(pickList);
					PickListOrderReport totalReport = new PickListOrderReport("PickListTotalReport");
					PickListOrderReport1 totalReport1 = new PickListOrderReport1("PickListTotalReport1");
					totalReport.buildDocument(pickListTotalCsvList, request);
					totalReport1.buildDocument(pickListTotalCsvList, request);
					totalReport.exportReport(pickListForm.getPrint10());
					totalReport1.exportReport(pickListForm.getPrint10());
					
					pickList.setFormId(totalReport1.getReportFileName());
					pickList.setFormName(
							totalReport1.getReportFileNameLog() + ".pdf");
					pickList.setFilePath(this.getNewFilePath(totalReport1.getReportFilePath()));
					pickListService.insertPrintLog(pickList);
				}
			}
		}
		
		
		if (!StringUtils.isEmpty(pickListForm.getAllMissing1())) {
			String processSequenceNo = pickListService.selectprocessSequenceNo().trim();
			PickList pickList = new PickList();
			pickList.setProcessSequence(processSequenceNo);
			pickList.setPrintId(processSequenceNo);
			pickList.setPrintDate(commonService.getPrintdate());
			pickList.setPrintTime(sysTime);
			pickList.setPrinter(pickListForm.getAllMissingPrint().trim());
			pickList.setUserCode(userDetails.getUsername());
			pickList.setCreateUser(userDetails.getUsername());
			pickList.setCreateDate(sysDate);
			pickList.setCreateTime(sysTime);
			pickList.setUpdateUser(userDetails.getUsername());
			pickList.setUpdateDate(sysDate);
			pickList.setUpdateTime(sysTime);
			int count = pickListService.updateAllMissingOrderInterface(processSequenceNo);
			if (count > 0) {
				List<PickListCsv> pickListOrderCsvList = pickListService.findPickListAllMissingCsv(processSequenceNo);
				PickListOrderReport orderReport = new PickListOrderReport("PickListOrderReport");
				PickListOrderReport1 orderReport1 = new PickListOrderReport1("PickListOrderReport1");
				orderReport.buildDocument(pickListOrderCsvList, request);
				orderReport1.buildDocument(pickListOrderCsvList, request);
				orderReport.exportReport(pickListForm.getAllMissingPrint());
				orderReport1.exportReport(pickListForm.getAllMissingPrint());
				pickList.setFormId(orderReport1.getReportFileName());
				pickList.setFormName(orderReport1.getReportFileNameLog() + ".pdf");
				pickList.setFilePath(this.getNewFilePath(orderReport1.getReportFilePath()));
				pickListService.insertPrintLog(pickList);
			}
		}
		
		List<PickList> list = pickListService.selectPickList();
		pickListForm.setIncompleteOrderCount1(list.get(0).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount2(list.get(1).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount3(list.get(2).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount4(list.get(3).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount5(list.get(4).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount6(list.get(5).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount7(list.get(6).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount8(list.get(7).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount9(list.get(8).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount10(list.get(9).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount11(list.get(10).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount12(list.get(11).getIncompleteOrderCount());
		pickListForm.setAllMissingCount(list.get(12).getIncompleteOrderCount());
		modelView.addObject("pickListForm", pickListForm);
		return modelView;
	}

	@RequestMapping(value = "/pick_list", params = "action=search")
	public ModelAndView search(@Validated @ModelAttribute("pickListForm") PickListForm pickListForm,
			BindingResult result, ModelAndView modelView) {
		logger.info("--- search() start ---");
		boolean flag = true;
		modelView.addObject("flag", flag);
		modelView.setViewName("/pick_list");
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		String incompleteOrderCount = pickListForm.getIncompleteOrderCount();
		PickList pickList = new PickList();
		pickList.setIncompleteOrderCount(incompleteOrderCount);

		int count = commonService.selectTableUpperLimitCount();
		int countManual = pickListService.selectCountt(pickList);
		if (count <= countManual) {
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<PickList> list = pickListService.selectPickList();

		pickListForm.setIncompleteOrderCount1(list.get(0).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount2(list.get(1).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount3(list.get(2).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount4(list.get(3).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount5(list.get(4).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount6(list.get(5).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount7(list.get(6).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount8(list.get(7).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount9(list.get(8).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount10(list.get(9).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount11(list.get(10).getIncompleteOrderCount());
		pickListForm.setIncompleteOrderCount12(list.get(11).getIncompleteOrderCount());
		pickListForm.setAllMissingCount(list.get(12).getIncompleteOrderCount());
		if (CollectionUtils.isEmpty(list)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		modelView.addObject("pickListForm", pickListForm);
		return modelView;
	}
	
	private PickList getOrderTotalInfo(UserDetails userDetails,String sysDate, String sysTime) throws ParseException{
		String processSequenceNo = pickListService.selectprocessSequenceNo().trim();
		PickList pickList = new PickList();
		pickList.setProcessSequence(processSequenceNo);
		pickList.setPrintId(processSequenceNo);
		pickList.setPrintDate(commonService.getPrintdate());
		pickList.setPrintTime(sysTime);
		pickList.setUserCode(userDetails.getUsername());
		pickList.setCreateUser(userDetails.getUsername());
		pickList.setCreateDate(sysDate);
		pickList.setCreateTime(sysTime);
		pickList.setUpdateUser(userDetails.getUsername());
		pickList.setUpdateDate(sysDate);
		pickList.setUpdateTime(sysTime);
		return pickList;
		
	}
	
	private String  getNewFilePath(String oldPath){
		String  newPilePath = commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint");
		return newPilePath;
	}
}

package jp.co.groundinc.convertor.domain;

public class AuditInquiry {
	
	private String auditNoStart;
	
	private String auditNoEnd;
	
	private String auditNo;
	
	private String startDateStart;
	
	private String startDateEnd;
	
	private String startDate;
	
	private String auditId;
	
	private String auditTypeName;
	
	private String auditParamValueFrom;
	
	private String auditParamValueTo;
	
	private String auditParamValue;
	
	private String expectedSkuCount;
	
	private String resultSkuCount;
	
	private String startTime;
	
	private String expectedCount;
	
	private String resultCount;
	
	private String startDateTime;
	
	private String irregularKindName;
	
	private String irregularKind;
	
	private String targetCount;
	
	private String printId;
	
	private String printDate;
	
	private String printTime;
	
	private String formId;
	
	private String formName;
	
	private String filePath;
	
	private String printer;
	
	private String userCode;
	
	private String createUser;
	
	private String createDate;
	
	private String createTime;
	
	private String updateUser;
	
	private String updateDate;
	
	private String updateTime;
	
    private Integer  maxReauditCount;
    
	public String getIrregularKind() {
		return irregularKind;
	}
	public void setIrregularKind(String irregularKind) {
		this.irregularKind = irregularKind;
	}
	public Integer getMaxReauditCount() {
		return maxReauditCount;
	}
	public void setMaxReauditCount(Integer maxReauditCount) {
		this.maxReauditCount = maxReauditCount;
	}
	public String getPrintId() {
		return printId;
	}
	public void setPrintId(String printId) {
		this.printId = printId;
	}
	public String getPrintDate() {
		return printDate;
	}
	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}
	public String getPrintTime() {
		return printTime;
	}
	public void setPrintTime(String printTime) {
		this.printTime = printTime;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getPrinter() {
		return printer;
	}
	public void setPrinter(String printer) {
		this.printer = printer;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getTargetCount() {
		return targetCount;
	}
	public void setTargetCount(String targetCount) {
		this.targetCount = targetCount;
	}
	public String getAuditId() {
		return auditId;
	}
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}
	public String getAuditTypeName() {
		return auditTypeName;
	}
	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}
	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}
	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}
	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}
	public String getAuditParamValue() {
		return auditParamValue;
	}
	public void setAuditParamValue(String auditParamValue) {
		this.auditParamValue = auditParamValue;
	}
	public String getExpectedSkuCount() {
		return expectedSkuCount;
	}
	public void setExpectedSkuCount(String expectedSkuCount) {
		this.expectedSkuCount = expectedSkuCount;
	}
	public String getResultSkuCount() {
		return resultSkuCount;
	}
	public void setResultSkuCount(String resultSkuCount) {
		this.resultSkuCount = resultSkuCount;
	}
	public String getIrregularKindName() {
		return irregularKindName;
	}
	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getAuditNoStart() {
		return auditNoStart;
	}
	public void setAuditNoStart(String auditNoStart) {
		this.auditNoStart = auditNoStart;
	}
	public String getAuditNoEnd() {
		return auditNoEnd;
	}
	public void setAuditNoEnd(String auditNoEnd) {
		this.auditNoEnd = auditNoEnd;
	}
	public String getAuditNo() {
		return auditNo;
	}
	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}
	public String getStartDateStart() {
		return startDateStart;
	}
	public void setStartDateStart(String startDateStart) {
		this.startDateStart = startDateStart;
	}
	public String getStartDateEnd() {
		return startDateEnd;
	}
	public void setStartDateEnd(String startDateEnd) {
		this.startDateEnd = startDateEnd;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getExpectedCount() {
		return expectedCount;
	}
	public void setExpectedCount(String expectedCount) {
		this.expectedCount = expectedCount;
	}
	public String getResultCount() {
		return resultCount;
	}
	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}
	
}

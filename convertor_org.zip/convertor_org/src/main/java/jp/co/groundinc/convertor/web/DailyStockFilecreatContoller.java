package jp.co.groundinc.convertor.web;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jp.co.groundinc.convertor.CommonConstant;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.DailyStockFilecreat;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatCsv;
import jp.co.groundinc.convertor.domain.DailyStockFilecreatReports;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.DailyStockFilecreatService;
import jp.co.groundinc.convertor.web.form.DailyStockFilecreatForm;
import jp.co.groundinc.convertor.web.report.DailyStockFilecreatReport;
import jp.co.groundinc.convertor.web.report.DailyStockFilecreatReport1;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
public class DailyStockFilecreatContoller {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	CommonService commonService;

	@Autowired
	CommonUtility commonUtility;
	
	@Autowired
	DailyStockFilecreatService dailyStockFilecreatService;
	
	
	@Value("${wcs.file.path}")
	private String fileUrl;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("dailyStockFilecreatForm")
	public DailyStockFilecreatForm pickInquiryForm() {
		logger.info("--- DailyStockFilecreatContoller.DailyStockFilecreatForm() start ---");
		return new DailyStockFilecreatForm();
	}
	@RequestMapping(value = "/dailystockfilecreat", params = "action=back")
	public String viewDailyStock(HttpServletRequest request, Model model) {
		logger.info("--- viewDailyStock() start ---");
		return "stock_menu";
	}
	@RequestMapping("/dailystockfilecreat")
	public String DailyStock(Model model, HttpServletRequest request) throws ParseException {
		logger.info("--- DailyStockFilecreatContoller.DailyStock() start ---");
		DailyStockFilecreatForm form = new DailyStockFilecreatForm();
		model.addAttribute("dailyStockFilecreatForm", form);
		model.addAttribute("souSinDate", commonService.getStockSendDate());
		model.addAttribute("souSinTime", commonService.getStockSendTime());
		return "daily_stock_filecreat";
	}
	
	@RequestMapping(value = "/dailystockfilecreat", params = "action=download")
	public ModelAndView csv(@Validated @ModelAttribute("dailyStockFilecreatForm") DailyStockFilecreatForm dailyStockFilecreatForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) throws Exception {
		logger.info("--- DailyStockFilecreatContoller.csv() start ---");
		
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		DailyStockFilecreat dailyStockFilecreat = new DailyStockFilecreat();
		dailyStockFilecreat.setStockSendDate(sysDate);
		dailyStockFilecreat.setStockSendStartTime(sysTime);
		dailyStockFilecreatService.updateDate(dailyStockFilecreat);
		
		//Reports
		String sku = dailyStockFilecreatForm.getSku();
		List<DailyStockFilecreatReports> dailyStockFilecreatReportsList = 
				dailyStockFilecreatService.findDailyStockFilecreatReports(sku);
		
		DailyStockFilecreatReport reprot = new DailyStockFilecreatReport("DailyStockFilecreatReport");
			reprot.buildDocument(dailyStockFilecreatReportsList, request);
			reprot.exportReport1(sku);
		    modelView.setViewName("/daily_stock_filecreat");
		    
		    Date dts = new Date();
		    DateFormat dfDates = new SimpleDateFormat("yyyyMMdd");
			String sysDates = dfDates.format(dts);
			DateFormat dfTimes = new SimpleDateFormat("HHmmss");
			String sysTimes = dfTimes.format(dts);
			DailyStockFilecreat dailyStockFilecreat1 = new DailyStockFilecreat();
			dailyStockFilecreat1.setStockSendDate(sysDates);
			dailyStockFilecreat1.setStockSendEndTime(sysTimes);
			dailyStockFilecreatService.updateTime(dailyStockFilecreat1);
			
			DateFormat dfDates1 = new SimpleDateFormat("yyyyMMdd");
		    Date souSinDate1 = dfDates1.parse(dailyStockFilecreat1.getStockSendDate());
			dfDates1 = new SimpleDateFormat("yyyy/MM/dd");
			String newsouSinDate = dfDates1.format(souSinDate1);
			
			DateFormat dfTimes1 = new SimpleDateFormat("HHmmss");
			Date souSinTime = dfTimes1.parse(dailyStockFilecreat1.getStockSendEndTime());
			dfTimes1 = new SimpleDateFormat("HH:mm:ss");
			String newsouSinTime = dfTimes1.format(souSinTime);
			
		    modelView.addObject("souSinDate",newsouSinDate);
		    modelView.addObject("souSinTime",newsouSinTime);
		    String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
		   return modelView;
	}
	
	@RequestMapping(value = "/dailystockfilecreat", params = "action=Registration")
	public ModelAndView registration(@Validated @ModelAttribute("dailyStockFilecreatForm") DailyStockFilecreatForm dailyStockFilecreatForm,
			BindingResult result, ModelAndView modelView,HttpServletRequest request) throws Exception {
		logger.info("--- DailyStockFilecreatContoller.csv() start ---");
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		String userId = userDetails.getUsername();
		List<DailyStockFilecreatCsv>  dailyStockFilecreatCsvList = dailyStockFilecreatService.findDailyStockFilecreatCsv();
		DailyStockFilecreatReport1 report = new DailyStockFilecreatReport1("DailyStockFilecreatReport1");
		report.buildDocument(dailyStockFilecreatCsvList, request);
		report.exportReport2(sysDate);
	    modelView.setViewName("/daily_stock_filecreat");
	    DailyStockFilecreat dailyStockFilecreat = new DailyStockFilecreat();
			int skuCount = dailyStockFilecreatService.selectCount();
			dailyStockFilecreat.setCreateDate(sysDate);
			dailyStockFilecreat.setCreateTime(sysTime);
			dailyStockFilecreat.setCreateUser(userId);
			dailyStockFilecreat.setUpdateDate(sysDate);
			dailyStockFilecreat.setUpdateTime(sysTime);
			dailyStockFilecreat.setUpdateUser(userId);
			dailyStockFilecreat.setProcessedDate(sysDate);
			dailyStockFilecreat.setProcessedTime(sysTime);
			dailyStockFilecreat.setCreateKind(CommonConstant.CREATE_KIND);
			dailyStockFilecreat.setTotalCount(skuCount);
			String fileName = fileUrl+ dailyStockFilecreat.getProcessedDate()+"/"+report.getReportFileNameLog()+".csv";
			dailyStockFilecreat.setFilePath(fileName);
			dailyStockFilecreatService.insertStockDailyLog(dailyStockFilecreat);
			modelView.addObject("souSinDate", commonService.getStockSendDate());
			modelView.addObject("souSinTime", commonService.getStockSendTime());
		    String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
		   return modelView;
	}
	
}


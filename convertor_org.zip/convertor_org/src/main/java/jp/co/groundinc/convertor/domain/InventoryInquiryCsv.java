package jp.co.groundinc.convertor.domain;

public class InventoryInquiryCsv {
	
	private String operatedDate;
	
	private String operatedTime;

	private String ppsId;
	
	private String ppsName;
	
	private String stationName;
	
	private String keyId;
	
	private String sku;

	private String skuName;

	private String qty;
	
	private String ppsBinId;
	
	private String ppsBinName;
	
	private String operationKindCode;
	
	private String operationKindName;
	
    private String operationTagCode;
	
	private String operationTagName;
	
	private String location;
	
    private String userCode;
	
	private String userName;
	
    private String msuId;
    
    private String msuSide;
    
    private String msuStep;
    
    private String msuSlot;
    
    private String slotType;
    
    private String operatedTimeStart;
    
    private String operatedTimeEnd;
    
    private String csvExportDate;
    
	private String csvExportTime;
	
	public String getOperatedTimeStart() {
		return operatedTimeStart;
	}

	public void setOperatedTimeStart(String operatedTimeStart) {
		this.operatedTimeStart = operatedTimeStart;
	}

	public String getOperatedTimeEnd() {
		return operatedTimeEnd;
	}

	public void setOperatedTimeEnd(String operatedTimeEnd) {
		this.operatedTimeEnd = operatedTimeEnd;
	}

	public String getPpsName() {
		return ppsName;
	}

	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}

	public String getSlotType() {
		return slotType;
	}

	public void setSlotType(String slotType) {
		this.slotType = slotType;
	}

	public String getCsvExportDate() {
		return csvExportDate;
	}

	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}

	public String getCsvExportTime() {
		return csvExportTime;
	}

	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}

	public String getMsuId() {
		return msuId;
	}

	public void setMsuId(String msuId) {
		this.msuId = msuId;
	}

	public String getMsuSide() {
		return msuSide;
	}

	public void setMsuSide(String msuSide) {
		this.msuSide = msuSide;
	}

	public String getMsuStep() {
		return msuStep;
	}

	public void setMsuStep(String msuStep) {
		this.msuStep = msuStep;
	}

	public String getMsuSlot() {
		return msuSlot;
	}

	public void setMsuSlot(String msuSlot) {
		this.msuSlot = msuSlot;
	}
	
	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getOperationTagCode() {
		return operationTagCode;
	}

	public void setOperationTagCode(String operationTagCode) {
		this.operationTagCode = operationTagCode;
	}

	public String getOperationTagName() {
		return operationTagName;
	}

	public void setOperationTagName(String operationTagName) {
		this.operationTagName = operationTagName;
	}

	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}

	public String getPpsBinId() {
		return ppsBinId;
	}

	public void setPpsBinId(String ppsBinId) {
		this.ppsBinId = ppsBinId;
	}

	public String getPpsBinName() {
		return ppsBinName;
	}

	public void setPpsBinName(String ppsBinName) {
		this.ppsBinName = ppsBinName;
	}

	public String getOperationKindCode() {
		return operationKindCode;
	}

	public void setOperationKindCode(String operationKindCode) {
		this.operationKindCode = operationKindCode;
	}

	public String getOperationKindName() {
		return operationKindName;
	}

	public void setOperationKindName(String operationKindName) {
		this.operationKindName = operationKindName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}

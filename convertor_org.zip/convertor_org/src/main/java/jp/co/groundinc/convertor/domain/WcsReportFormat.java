package jp.co.groundinc.convertor.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class WcsReportFormat implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private List<WcsReportField> output_fields;
	private String delimiter;
	
	public List<WcsReportField> getOutput_fields() {
		if (output_fields == null) {
			output_fields = new ArrayList<WcsReportField>();
		}
		return output_fields;
	}
	public String getDelimiter() {
		return delimiter;
	}
	public void setOutput_fields(List<WcsReportField> output_fields) {
		this.output_fields = output_fields;
	}
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	
	public void addFiled(String key, String display_name){
		getOutput_fields().add(new WcsReportField(key, display_name));
	}

}

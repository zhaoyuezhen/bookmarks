package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StockAdjustInquiry;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetail;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetailCsv;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryReports;
import jp.co.groundinc.convertor.mapper.StockAdjustInquiryMapper;

@Service
@EnableAutoConfiguration
public class StockAdjustInquiryService {
	@Autowired
	StockAdjustInquiryMapper stockAdjustInquiryMapper;
	
	@Autowired
	CommonUtility commonUtility;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<StockAdjustInquiry> findStockAdjustInquiry(StockAdjustInquiry stockAdjustInquiry) {
		logger.info("--- StockAdjustInquiryService.findstockAdjustInquiry() start ---");
		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())) {
			String startDateStart = CommonUtility.dateFomat(stockAdjustInquiry.getStartDateStart());
			stockAdjustInquiry.setStartDateStart(startDateStart);
		}

		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {
			String startDateEnd = CommonUtility.dateFomat(stockAdjustInquiry.getStartDateEnd());
			stockAdjustInquiry.setStartDateEnd(startDateEnd);;
		}
		
		List<StockAdjustInquiry> stockAdjustInquiryList = stockAdjustInquiryMapper.selectStockAdjustInquiry(stockAdjustInquiry);
		return stockAdjustInquiryList;
	}
	
	public int selectCountt(StockAdjustInquiry stockAdjustInquiry) {
		logger.info("--- StockAdjustInquiryService.findstockAdjustInquiry() start ---");
		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())) {
			String startDateStart = CommonUtility.dateFomat(stockAdjustInquiry.getStartDateStart());
			stockAdjustInquiry.setStartDateStart(startDateStart);
		}

		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {
			String startDateEnd = CommonUtility.dateFomat(stockAdjustInquiry.getStartDateEnd());
			stockAdjustInquiry.setStartDateEnd(startDateEnd);;
		}
		
		int count = stockAdjustInquiryMapper.selectCountt(stockAdjustInquiry);
		return count;
	}


	public StockAdjustInquiry findStockAdjustInquiryInfo(String auditNo) {
		logger.info("--- StockAdjustInquiryService.findStockAdjustInquiryInfo() start ---");
		StockAdjustInquiry stockAdjustInquiry = stockAdjustInquiryMapper.selectStockAdjustInquiryInfo(auditNo);
		return stockAdjustInquiry;
	}
	
	public List<StockAdjustInquiryDetail> findStockAdjustInquiryDetailInfo(String auditNo) {
		logger.info("--- StockAdjustInquiryService.findStockAdjustInquiryDetailInfo() start ---");
		List<StockAdjustInquiryDetail> stockAdjustInquiryDetailList = stockAdjustInquiryMapper.selectStockAdjustInquiryDetail(auditNo);
		return stockAdjustInquiryDetailList;
	}
	
	public List<StockAdjustInquiryDetailCsv> findStockAdjustInquiryDetailCsv(List<String> orderIdList) {
		logger.info("--- StockInquiryService.findStockInquiryDetailCsv() start ---");
		
		List<StockAdjustInquiryDetailCsv> stockAdjustInquiryDetailCsvList = 
				stockAdjustInquiryMapper.selectStockAdjustInquiryDetailCsv(orderIdList);
		
		return stockAdjustInquiryDetailCsvList;
	}
	
	public List<StockAdjustInquiryReports> findStockAdjustInquiryReport(String auditNo) {
		logger.info("--- StockInquiryService.findStockAdjustInquiryReport() start ---");
		
		List<StockAdjustInquiryReports> stockAdjustInquiryReportList = 
				stockAdjustInquiryMapper.selectStockAdjustInquiryReport(auditNo);
		
		return stockAdjustInquiryReportList;
	}
	
	public String selectPrintLogSeqence() {
		logger.info("--- StockInquiryService.selectPrintLogSeqence() start ---");
		
		String Seqence  = stockAdjustInquiryMapper.selectPrintLogSeqence();
		return Seqence;
		
	}
	public void insertPrintLog(StockAdjustInquiry stockAdjustInquiry ){
		logger.info("--- StockInquiryService.insertPrintLog() start ---");
		stockAdjustInquiryMapper.insertPrintLog(stockAdjustInquiry);
		
	}
	
	public void insertAuditExpectationDetail(StockAdjustInquiryDetail stockAdjustInquiryDetail){
		logger.info("--- StockInquiryService.insertAuditExpectationDetail() start ---");
		stockAdjustInquiryMapper.insertAuditExpectationDetail(stockAdjustInquiryDetail);
		
	}

}

package jp.co.groundinc.convertor.domain;

import java.util.List;

public class StockAdjustInquiryDetail {

	private String sendStatus;

	private String auditNo;
	
	private String location;
	
	private String sku;
	
	private String skuName;
	
	private int expectedQty;
	
	private int resultQty;
	
	private int diffQty;
	
	private int extraQty;
	
	private String erd;
	
	private String ppsName;
	
	private String userName;
	
	private String operatedDate;
	
	private String operatedTime;
	
	private String operatedDateTime;
	
	private String auditId;
	
	private String irregularKindName;
	
	private String auditStatus;

	private String reauditCount;
	
	private String [] auditNost;
	    
	private String [] orderIDs;
	
	private List<String> auditNoList;

	private List<String> slotList;
	
	private List<String> skuList;
	
	private String auditType;
	
	private String auditParamValue;
	
	private String createUser;
	
	private String createDate;
	
	private String createTime;
	
	private String updateUser;
	
	private String updateDate;
	
	private String updateTime;
	
	private String ppsId;
	
	private String ppsSeatName;
	
	private String userCode;
	
	private String timestamp;
	
	private String completedTimestamp;
	
	private String stationName;
	
	private String checkBoxFlag;
	
	
	public String getCheckBoxFlag() {
		return checkBoxFlag;
	}

	public void setCheckBoxFlag(String checkBoxFlag) {
		this.checkBoxFlag = checkBoxFlag;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getPpsId() {
		return ppsId;
	}

	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}

	public String getPpsSeatName() {
		return ppsSeatName;
	}

	public void setPpsSeatName(String ppsSeatName) {
		this.ppsSeatName = ppsSeatName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getCompletedTimestamp() {
		return completedTimestamp;
	}

	public void setCompletedTimestamp(String completedTimestamp) {
		this.completedTimestamp = completedTimestamp;
	}

	public String getAuditType() {
		return auditType;
	}

	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	public String getAuditParamValue() {
		return auditParamValue;
	}

	public void setAuditParamValue(String auditParamValue) {
		this.auditParamValue = auditParamValue;
	}

	public List<String> getAuditNoList() {
		return auditNoList;
	}

	public void setAuditNoList(List<String> auditNoList) {
		this.auditNoList = auditNoList;
	}

	public List<String> getSlotList() {
		return slotList;
	}

	public void setSlotList(List<String> slotList) {
		this.slotList = slotList;
	}

	public List<String> getSkuList() {
		return skuList;
	}

	public void setSkuList(List<String> skuList) {
		this.skuList = skuList;
	}

	public String[] getAuditNost() {
		return auditNost;
	}

	public void setAuditNost(String[] auditNost) {
		this.auditNost = auditNost;
	}

	public String[] getOrderIDs() {
		return orderIDs;
	}

	public void setOrderIDs(String[] orderIDs) {
		this.orderIDs = orderIDs;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getReauditCount() {
		return reauditCount;
	}

	public void setReauditCount(String reauditCount) {
		this.reauditCount = reauditCount;
	}

	public String getIrregularKindName() {
		return irregularKindName;
	}

	public void setIrregularKindName(String irregularKindName) {
		this.irregularKindName = irregularKindName;
	}

	public int getExpectedQty() {
		return expectedQty;
	}

	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}

	public int getResultQty() {
		return resultQty;
	}

	public void setResultQty(int resultQty) {
		this.resultQty = resultQty;
	}

	public int getDiffQty() {
		return diffQty;
	}

	public void setDiffQty(int diffQty) {
		this.diffQty = diffQty;
	}

	public int getExtraQty() {
		return extraQty;
	}

	public void setExtraQty(int extraQty) {
		this.extraQty = extraQty;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getOperatedDateTime() {
		return operatedDateTime;
	}

	public void setOperatedDateTime(String operatedDateTime) {
		this.operatedDateTime = operatedDateTime;
	}

	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getErd() {
		return erd;
	}

	public void setErd(String erd) {
		this.erd = erd;
	}

	public String getPpsName() {
		return ppsName;
	}

	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOperatedDate() {
		return operatedDate;
	}

	public void setOperatedDate(String operatedDate) {
		this.operatedDate = operatedDate;
	}

	public String getOperatedTime() {
		return operatedTime;
	}

	public void setOperatedTime(String operatedTime) {
		this.operatedTime = operatedTime;
	}
	
}

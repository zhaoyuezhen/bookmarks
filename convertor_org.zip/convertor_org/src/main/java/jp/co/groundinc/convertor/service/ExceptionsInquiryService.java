package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.ExceptionsInquiry;
import jp.co.groundinc.convertor.domain.ExceptionsInquiryDetail;
import jp.co.groundinc.convertor.mapper.ExceptionsInquiryMapper;

@Service
public class ExceptionsInquiryService {
	
	@Autowired
	ExceptionsInquiryMapper exceptionsInquiryMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<ExceptionsInquiry> selectExceptionsInquiry(ExceptionsInquiry exceptionsInquiry) {

		logger.info("--- ExceptionsInquiryService.selectExceptionsInquiry() start ---");
			String starDate = CommonUtility.dateFomat(exceptionsInquiry.getExceptionDateStart());
			String endDate = CommonUtility.dateFomat(exceptionsInquiry.getExceptionDateEnd());
			exceptionsInquiry.setExceptionDateStart(starDate);
			exceptionsInquiry.setExceptionDateEnd(endDate);
			List<ExceptionsInquiry> exceptionsInquiryList = exceptionsInquiryMapper.selectExceptionsInquiry(exceptionsInquiry);

			return exceptionsInquiryList;
	}
	
	public int selectCountt(ExceptionsInquiry exceptionsInquiry) {

		String starDate = CommonUtility.dateFomat(exceptionsInquiry.getExceptionDateStart());
		String endDate = CommonUtility.dateFomat(exceptionsInquiry.getExceptionDateEnd());
		exceptionsInquiry.setExceptionDateStart(starDate);
		exceptionsInquiry.setExceptionDateEnd(endDate);
		int count = exceptionsInquiryMapper.selectCountt(exceptionsInquiry);
		return count;

	}
	
	public List<ExceptionsInquiryDetail> selectExceptionsInquiryDetail(ExceptionsInquiryDetail exceptionsDetail) {
		logger.info("--- ExpressPickInstructionService.findExpressPickInstructionDetail() start ---");
		List<ExceptionsInquiryDetail> exceptionsInquiryDetailList = exceptionsInquiryMapper.selectExceptionsInquiryDetail(exceptionsDetail);
		return exceptionsInquiryDetailList;
	}

}
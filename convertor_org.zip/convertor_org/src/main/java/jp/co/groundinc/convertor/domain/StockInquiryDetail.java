package jp.co.groundinc.convertor.domain;

public class StockInquiryDetail {

	private String location;
	
	private String stockQty;
	
	private String latestShipmentDate;
	
	private String retentionDays;

	private String sku;
	private String totalCbm;
	private String cbm;
	
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getTotalCbm() {
		return totalCbm;
	}

	public void setTotalCbm(String totalCbm) {
		this.totalCbm = totalCbm;
	}

	public String getCbm() {
		return cbm;
	}

	public void setCbm(String cbm) {
		this.cbm = cbm;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStockQty() {
		return stockQty;
	}

	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}

	public String getLatestShipmentDate() {
		return latestShipmentDate;
	}

	public void setLatestShipmentDate(String latestShipmentDate) {
		this.latestShipmentDate = latestShipmentDate;
	}

	public String getRetentionDays() {
		return retentionDays;
	}

	public void setRetentionDays(String retentionDays) {
		this.retentionDays = retentionDays;
	}
	
	
}

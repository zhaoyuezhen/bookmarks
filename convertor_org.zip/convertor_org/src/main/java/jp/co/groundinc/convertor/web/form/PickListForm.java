package jp.co.groundinc.convertor.web.form;

public class PickListForm {

	//ピックリスト種別
	private String pickListGroup[];
	//AreaCode
	private String largeAreaCode9;
	private String largeAreaCode8;
	private String largeAreaCode7;
	private String largeAreaCode6;
	private String largeAreaCode5;
	private String largeAreaCode4;
	private String largeAreaCode3;
	private String largeAreaCode2;
	private String largeAreaCode1;
	private String largeAreaCode30;
	private String largeAreaCode20;
	private String largeAreaCode10;
private String incompleteOrderCount;
	
	private String incompleteOrderCount1;

	private String incompleteOrderCount2;
	
	private String incompleteOrderCount3;
	
	private String incompleteOrderCount4;
	
	private String incompleteOrderCount5;
	
	private String incompleteOrderCount6;
	
	private String incompleteOrderCount7;
	
	private String incompleteOrderCount8;
	
	private String incompleteOrderCount9;
	
	private String incompleteOrderCount10;
	
	private String incompleteOrderCount11;
	
	private String incompleteOrderCount12;
	
	
	private String allMissingCount;
	private String  allMissing1;
	private String allMissingPrint;
	

	public String getAllMissingPrint() {
		return allMissingPrint;
	}

	public void setAllMissingPrint(String allMissingPrint) {
		this.allMissingPrint = allMissingPrint;
	}

	public String getAllMissing1() {
		return allMissing1;
	}

	public void setAllMissing1(String allMissing1) {
		this.allMissing1 = allMissing1;
	}

	private String print1;
   
	private String print2;
   
	private String print3;
   
	private String print4;
   
	private String print5;
   
	private String print6;
   
	private String print7;
   
	private String print8;
   
	private String print9;
    
	private String print10;
    
	private String print20;
    
	private String print30;
    
	private String pickKind1;
    
	private String pickKind2;
    
	private String pickKind3;
    
	private String pickKind4;
    
	private String pickKind5;
    
	private String pickKind6;
    
	private String pickKind7;
    
	private String pickKind8;
    
	private String pickKind9;
    
	private String pickKind10;
    
	private String pickKind20;
	private String pickKind30;
    
	
	public String getAllMissingCount() {
		return allMissingCount;
	}

	public void setAllMissingCount(String allMissingCount) {
		this.allMissingCount = allMissingCount;
	}

	public String getLargeAreaCode30() {
		return largeAreaCode30;
	}

	public void setLargeAreaCode30(String largeAreaCode30) {
		this.largeAreaCode30 = largeAreaCode30;
	}

	public String getLargeAreaCode20() {
		return largeAreaCode20;
	}

	public void setLargeAreaCode20(String largeAreaCode20) {
		this.largeAreaCode20 = largeAreaCode20;
	}

	public String getLargeAreaCode10() {
		return largeAreaCode10;
	}

	public void setLargeAreaCode10(String largeAreaCode10) {
		this.largeAreaCode10 = largeAreaCode10;
	}

	public String getLargeAreaCode7() {
		return largeAreaCode7;
	}

	public void setLargeAreaCode7(String largeAreaCode7) {
		this.largeAreaCode7 = largeAreaCode7;
	}

	public String getLargeAreaCode6() {
		return largeAreaCode6;
	}

	public void setLargeAreaCode6(String largeAreaCode6) {
		this.largeAreaCode6 = largeAreaCode6;
	}

	public String getLargeAreaCode5() {
		return largeAreaCode5;
	}

	public void setLargeAreaCode5(String largeAreaCode5) {
		this.largeAreaCode5 = largeAreaCode5;
	}

	public String getLargeAreaCode4() {
		return largeAreaCode4;
	}

	public void setLargeAreaCode4(String largeAreaCode4) {
		this.largeAreaCode4 = largeAreaCode4;
	}

	public String getLargeAreaCode3() {
		return largeAreaCode3;
	}

	public void setLargeAreaCode3(String largeAreaCode3) {
		this.largeAreaCode3 = largeAreaCode3;
	}

	public String getLargeAreaCode2() {
		return largeAreaCode2;
	}

	public void setLargeAreaCode2(String largeAreaCode2) {
		this.largeAreaCode2 = largeAreaCode2;
	}

	public String getLargeAreaCode1() {
		return largeAreaCode1;
	}

	public void setLargeAreaCode1(String largeAreaCode1) {
		this.largeAreaCode1 = largeAreaCode1;
	}

	public String getLargeAreaCode9() {
		return largeAreaCode9;
	}

	public void setLargeAreaCode9(String largeAreaCode9) {
		this.largeAreaCode9 = largeAreaCode9;
	}

	public String getLargeAreaCode8() {
		return largeAreaCode8;
	}

	public void setLargeAreaCode8(String largeAreaCode8) {
		this.largeAreaCode8 = largeAreaCode8;
	}

	public String getPickKind1() {
		return pickKind1;
	}

	public void setPickKind1(String pickKind1) {
		this.pickKind1 = pickKind1;
	}

	public String getPickKind2() {
		return pickKind2;
	}

	public void setPickKind2(String pickKind2) {
		this.pickKind2 = pickKind2;
	}

	public String getPickKind3() {
		return pickKind3;
	}

	public void setPickKind3(String pickKind3) {
		this.pickKind3 = pickKind3;
	}

	public String getPickKind4() {
		return pickKind4;
	}

	public void setPickKind4(String pickKind4) {
		this.pickKind4 = pickKind4;
	}

	public String getPickKind5() {
		return pickKind5;
	}

	public void setPickKind5(String pickKind5) {
		this.pickKind5 = pickKind5;
	}

	public String getPickKind6() {
		return pickKind6;
	}

	public void setPickKind6(String pickKind6) {
		this.pickKind6 = pickKind6;
	}

	public String getPickKind7() {
		return pickKind7;
	}

	public void setPickKind7(String pickKind7) {
		this.pickKind7 = pickKind7;
	}

	public String getPickKind8() {
		return pickKind8;
	}

	public void setPickKind8(String pickKind8) {
		this.pickKind8 = pickKind8;
	}

	public String getPickKind9() {
		return pickKind9;
	}

	public void setPickKind9(String pickKind9) {
		this.pickKind9 = pickKind9;
	}

	public String getPickKind10() {
		return pickKind10;
	}

	public void setPickKind10(String pickKind10) {
		this.pickKind10 = pickKind10;
	}

	
	public String getPrint2() {
		return print2;
	}

	public void setPrint2(String print2) {
		this.print2 = print2;
	}

	public String getPrint3() {
		return print3;
	}

	public void setPrint3(String print3) {
		this.print3 = print3;
	}

	public String getPrint4() {
		return print4;
	}

	public void setPrint4(String print4) {
		this.print4 = print4;
	}

	public String getPrint5() {
		return print5;
	}

	public void setPrint5(String print5) {
		this.print5 = print5;
	}

	public String getPrint6() {
		return print6;
	}

	public void setPrint6(String print6) {
		this.print6 = print6;
	}

	public String getPrint7() {
		return print7;
	}

	public void setPrint7(String print7) {
		this.print7 = print7;
	}

	public String getPrint8() {
		return print8;
	}

	public void setPrint8(String print8) {
		this.print8 = print8;
	}

	public String getPrint9() {
		return print9;
	}

	public void setPrint9(String print9) {
		this.print9 = print9;
	}

	public String getPrint10() {
		return print10;
	}

	public void setPrint10(String print10) {
		this.print10 = print10;
	}

	

	public String getPrint1() {
		return print1;
	}

	public void setPrint1(String print1) {
		this.print1 = print1;
	}

	public String getPrint20() {
		return print20;
	}

	public void setPrint20(String print20) {
		this.print20 = print20;
	}

	public String getPrint30() {
		return print30;
	}

	public void setPrint30(String print30) {
		this.print30 = print30;
	}

	public String getPickKind20() {
		return pickKind20;
	}

	public void setPickKind20(String pickKind20) {
		this.pickKind20 = pickKind20;
	}

	public String getPickKind30() {
		return pickKind30;
	}

	public void setPickKind30(String pickKind30) {
		this.pickKind30 = pickKind30;
	}

	public String getIncompleteOrderCount2() {
		return incompleteOrderCount2;
	}

	public void setIncompleteOrderCount2(String incompleteOrderCount2) {
		this.incompleteOrderCount2 = incompleteOrderCount2;
	}

	public String getIncompleteOrderCount3() {
		return incompleteOrderCount3;
	}

	public void setIncompleteOrderCount3(String incompleteOrderCount3) {
		this.incompleteOrderCount3 = incompleteOrderCount3;
	}

	public String getIncompleteOrderCount4() {
		return incompleteOrderCount4;
	}

	public void setIncompleteOrderCount4(String incompleteOrderCount4) {
		this.incompleteOrderCount4 = incompleteOrderCount4;
	}

	public String getIncompleteOrderCount5() {
		return incompleteOrderCount5;
	}

	public void setIncompleteOrderCount5(String incompleteOrderCount5) {
		this.incompleteOrderCount5 = incompleteOrderCount5;
	}

	public String getIncompleteOrderCount6() {
		return incompleteOrderCount6;
	}

	public void setIncompleteOrderCount6(String incompleteOrderCount6) {
		this.incompleteOrderCount6 = incompleteOrderCount6;
	}

	public String getIncompleteOrderCount7() {
		return incompleteOrderCount7;
	}

	public void setIncompleteOrderCount7(String incompleteOrderCount7) {
		this.incompleteOrderCount7 = incompleteOrderCount7;
	}

	public String getIncompleteOrderCount8() {
		return incompleteOrderCount8;
	}

	public void setIncompleteOrderCount8(String incompleteOrderCount8) {
		this.incompleteOrderCount8 = incompleteOrderCount8;
	}

	public String getIncompleteOrderCount9() {
		return incompleteOrderCount9;
	}

	public void setIncompleteOrderCount9(String incompleteOrderCount9) {
		this.incompleteOrderCount9 = incompleteOrderCount9;
	}

	public String getIncompleteOrderCount10() {
		return incompleteOrderCount10;
	}

	public void setIncompleteOrderCount10(String incompleteOrderCount10) {
		this.incompleteOrderCount10 = incompleteOrderCount10;
	}

	public String getIncompleteOrderCount11() {
		return incompleteOrderCount11;
	}

	public void setIncompleteOrderCount11(String incompleteOrderCount11) {
		this.incompleteOrderCount11 = incompleteOrderCount11;
	}

	public String getIncompleteOrderCount12() {
		return incompleteOrderCount12;
	}

	public void setIncompleteOrderCount12(String incompleteOrderCount12) {
		this.incompleteOrderCount12 = incompleteOrderCount12;
	}
	
	public String getIncompleteOrderCount1() {
		return incompleteOrderCount1;
	}

	public void setIncompleteOrderCount1(String incompleteOrderCount1) {
		this.incompleteOrderCount1 = incompleteOrderCount1;
	}


	public String[] getPickListGroup() {
		return pickListGroup;
	}

	public void setPickListGroup(String[] pickListGroup) {
		this.pickListGroup = pickListGroup;
	}

	public String getIncompleteOrderCount() {
		return incompleteOrderCount;
	}

	public void setIncompleteOrderCount(String incompleteOrderCount) {
		this.incompleteOrderCount = incompleteOrderCount;
	}
	
}

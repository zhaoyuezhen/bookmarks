package jp.co.groundinc.convertor.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import jp.co.groundinc.convertor.domain.ExpressPickInstruction;
@Mapper
public interface ExpressPickInstructionMapper {

	
	List<ExpressPickInstruction> findExpressPickInstruction(ExpressPickInstruction expressPickInstruction);
	
	int selectCountt(ExpressPickInstruction expressPickInstruction);
	int insertOrderInterface(ExpressPickInstruction expressPickInstruction);
	int selectProductCount(ExpressPickInstruction expressPickInstruction);
	String getDefTranslateCode();
	List<ExpressPickInstruction> selectOrderId(String orderId);
	
}

package jp.co.groundinc.convertor.web;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.StockAdjustInquiry;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryDetailCsv;
import jp.co.groundinc.convertor.domain.StockAdjustInquiryReports;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.service.CommonService;
import jp.co.groundinc.convertor.service.StockAdjustInquiryService;
import jp.co.groundinc.convertor.web.form.StockAdjustInquiryForm;
import jp.co.groundinc.convertor.web.report.StockAdjustInquiryReport;
import jp.co.groundinc.convertor.web.report.StockAdjustInquiryReport1;

@Controller
@EnableWebSecurity
@EnableAutoConfiguration
@SessionAttributes(value = { "printerList", "stockAdjustInquiryForm","irregularKind" })
public class StockAdjustInquiryController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MessageSource messageSource;

	@Autowired
	CommonService commonService;

	@Autowired
	StockAdjustInquiryService stockAdjustInquiryService;

	@Autowired
	CommonUtility commonUtility;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
	}

	@ModelAttribute("printerList")
	public List<Translate> printerList() {
		logger.info("--- StockAdjustInquiryController.printerList() start ---");
		return commonService.getTranslateList("PrinterCode");
	}
	
	@ModelAttribute("stockAdjustInquiryForm")
	public StockAdjustInquiryForm stockAdjustInquiryForm() {
		logger.info("--- StockAdjustInquiryController.stockAdjustInquiryForm() start ---");
		return new StockAdjustInquiryForm();
	}

	@ModelAttribute("operationDateStart")
	public String startDateStart() throws ParseException {
		logger.info("--- stockAdjustInquiryController.startDateStart() start ---");
		return commonService.getOperationDate();
	}
	
	@ModelAttribute("operationDateEnd")
	public String startDateEnd() throws ParseException {
		logger.info("--- stockAdjustInquiryController.startDateEnd() start ---");
		return commonService.getOperationDate();
	}

	@ModelAttribute("maxReauditCount")
	public int maxReauditCount() throws ParseException {
		logger.info("--- stockAdjustInquiryController.maxReauditCount() start ---");
		return 1;
	}
	
	@ModelAttribute("irregularKind")
	public List<Translate> irregularKind() {
		logger.info("--- stockAdjustInquiryController.irregularKind() start ---");
		return commonService.getTranslateList("IrregularKind");
	}
	
	@RequestMapping(value = "/stock_adjust_inquiry", params = "action=back")
	public String StockAdjustInquiryBack(HttpServletRequest request, Model model, SessionStatus status) {
		logger.info("--- StockAdjustInquiryController.stockAdjustBack() start ---");
		status.setComplete();
		return "stock_menu";
	}

	@RequestMapping("/stock_adjust_inquiry")
	public String viewStockAdjustInquiry(Model model, HttpServletRequest request) throws ParseException {
		logger.info("--- StockAdjustInquiryController.stockAdjustInquiry() start ---");
		StockAdjustInquiryForm stockAdjustInquiryForm = (StockAdjustInquiryForm)request.getSession().getAttribute("stockAdjustInquiryForm");
		if(stockAdjustInquiryForm !=null){
			stockAdjustInquiryForm.setAuditNoStart(null);
			stockAdjustInquiryForm.setAuditNoEnd(null);
			stockAdjustInquiryForm.setStartDateStart(commonService.getOperationDate());
			stockAdjustInquiryForm.setStartDateEnd(commonService.getOperationDate());
		}
		return "stock_adjust_inquiry";
	}

	@RequestMapping(value = "/stock_adjust_inquiry", params = "action=search")
	public ModelAndView search(
			@Validated @ModelAttribute("stockAdjustInquiryForm") StockAdjustInquiryForm stockAdjustInquiryForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("---StockAdjustInquiryController.search() start ---");
		modelView.setViewName("/stock_adjust_inquiry");
		String startDateStart = stockAdjustInquiryForm.getStartDateStart();
		String startDateEnd = stockAdjustInquiryForm.getStartDateEnd();
		String maxReauditCount =stockAdjustInquiryForm.getMaxReauditCount();
		modelView.addObject("operationDateStart", startDateStart);
		modelView.addObject("operationDateEnd", startDateEnd);
		modelView.addObject("maxReauditCount", maxReauditCount);
		if (result.hasErrors()) {
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		String auditNoStart = stockAdjustInquiryForm.getAuditNoStart();
		String auditNoEnd = stockAdjustInquiryForm.getAuditNoEnd();
		String startTime = stockAdjustInquiryForm.getStartTime();
		String irregularKind = stockAdjustInquiryForm.getIrregularKind();
		String irregularKindName = stockAdjustInquiryForm.getIrregularKindName();
		String auditId = stockAdjustInquiryForm.getAuditId();
		String auditTypeName = stockAdjustInquiryForm.getAuditTypeName();
		String auditParamValueFrom = stockAdjustInquiryForm.getAuditParamValueFrom();
		String auditParamValueTo = stockAdjustInquiryForm.getAuditParamValueTo();
		String auditParamValue = stockAdjustInquiryForm.getAuditParamValue();
		String expectedCount = stockAdjustInquiryForm.getExpectedCount();
		String resultCount = stockAdjustInquiryForm.getResultCount();
		String targetCount = stockAdjustInquiryForm.getTargetCount();
		

		if (!StringUtils.isEmpty(auditNoStart) && StringUtils.isEmpty(auditNoEnd)) {
			auditNoEnd = auditNoStart;
		}
		if (StringUtils.isEmpty(auditNoStart) && !StringUtils.isEmpty(auditNoEnd)) {
			auditNoStart = auditNoEnd;
		}
		if (!StringUtils.isEmpty(startDateStart) && !StringUtils.isEmpty(startDateEnd)) {

			if (CommonUtility.comparedateStartafterEnd(startDateStart, startDateEnd)) {
				String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
				modelView.addObject("validationMessage", message);
				String startDate = messageSource.getMessage("stockAdjustInquiry.startDate.Datecomparison.message", null,
						Locale.JAPAN);
				modelView.addObject("startDate", startDate);
				return modelView;
			}
		}

		StockAdjustInquiry stockAdjustInquiry = new StockAdjustInquiry();
		stockAdjustInquiry.setAuditNoStart(auditNoStart);
		stockAdjustInquiry.setAuditNoEnd(auditNoEnd);
		stockAdjustInquiry.setStartDateStart(startDateStart);
		stockAdjustInquiry.setStartDateEnd(startDateEnd);
		stockAdjustInquiry.setStartTime(startTime);
		stockAdjustInquiry.setIrregularKind(irregularKind);
		stockAdjustInquiry.setIrregularKindName(irregularKindName);
		stockAdjustInquiry.setAuditId(auditId);
		stockAdjustInquiry.setAuditParamValue(auditParamValue);
		stockAdjustInquiry.setAuditParamValueFrom(auditParamValueFrom);
		stockAdjustInquiry.setAuditParamValueTo(auditParamValueTo);
		stockAdjustInquiry.setAuditTypeName(auditTypeName);
		stockAdjustInquiry.setExpectedCount(expectedCount);
		stockAdjustInquiry.setResultCount(resultCount);
		stockAdjustInquiry.setTargetCount(targetCount);
		stockAdjustInquiry.setMaxReauditCount(Integer.parseInt(maxReauditCount));

		if (!StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())
				&& StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {

			String startDateFrom = stockAdjustInquiry.getStartDateStart();

			stockAdjustInquiry.setStartDateEnd(startDateFrom);
		}
		if (StringUtils.isEmpty(stockAdjustInquiry.getStartDateStart())
				&& !StringUtils.isEmpty(stockAdjustInquiry.getStartDateEnd())) {

			String startDateTo = stockAdjustInquiry.getStartDateEnd();

			stockAdjustInquiry.setStartDateStart(startDateTo);
		}
		int count = commonService.selectTableUpperLimitCount();
		int countManual = stockAdjustInquiryService.selectCountt(stockAdjustInquiry);
		if (count <= countManual) {
			String message = messageSource.getMessage("Common.Search.Message.E004", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		List<StockAdjustInquiry> stockAdjustList = stockAdjustInquiryService.findStockAdjustInquiry(stockAdjustInquiry);

		if (CollectionUtils.isEmpty(stockAdjustList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}

		for (int i = 0; i < stockAdjustList.size(); i++) {
			
			if (StringUtils.isEmpty(stockAdjustList.get(i).getExpectedCount())) {
				stockAdjustList.get(i).setExpectedCount("");
			}
			if (StringUtils.isEmpty(stockAdjustList.get(i).getResultCount())) {
				stockAdjustList.get(i).setResultCount("");
			}
			if (!StringUtils.isEmpty(stockAdjustList.get(i).getStartDate())
					&& !StringUtils.isEmpty(stockAdjustList.get(i).getStartTime())) {
				String str = stockAdjustList.get(i).getStartDate() + stockAdjustList.get(i).getStartTime();
				String newstr = CommonUtility.getDateTime(str);
				stockAdjustList.get(i).setStartDateTime(newstr);
				
			}
		}
		boolean flag =true;
		modelView.addObject("flag", flag);
		modelView.addObject("stockAdjustList", stockAdjustList);
		return modelView;
	}

	@RequestMapping(value = "/stock_adjust_inquiry", params = "action=download")
	public ModelAndView download(
			@Validated @ModelAttribute("stockAdjustInquiryForm") StockAdjustInquiryForm stockAdjustInquiryForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) {
		logger.info("--- StockAdjustInquiryController.download() start ---");

        String [] orderIds = stockAdjustInquiryForm.getOrderIDs();
		
		if(orderIds == null||orderIds.length == 0){
			String message = messageSource.getMessage("Common.Search.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/stock_adjust_inquiry");
			return modelView;
		}
		
		List<String> orderIdList = new ArrayList<String>(); 
		for (String orderId : orderIds) {
			orderIdList.add(orderId);
		}

		List<StockAdjustInquiryDetailCsv> stockAdjustInquiryDetailCsvList = stockAdjustInquiryService.findStockAdjustInquiryDetailCsv(orderIdList);

		if (CollectionUtils.isEmpty(stockAdjustInquiryDetailCsvList)) {
			String message = messageSource.getMessage("Common.Search.Message.E003", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			modelView.setViewName("/stock_adjust_inquiry");
			return modelView;
		}

		modelView.addObject("stockAdjustInquiryDetailCsvList", stockAdjustInquiryDetailCsvList);
		modelView.setViewName("StockAdjustInquiryCsvView");

		return modelView;
	}

	@RequestMapping(value = "/stock_adjust_inquiry", params = "action=print")
	public ModelAndView print(
			@Validated @ModelAttribute("stockAdjustInquiryForm") StockAdjustInquiryForm stockAdjustInquiryForm,
			BindingResult result, ModelAndView modelView, HttpServletRequest request) throws Exception {
		logger.info("--- StockAdjustInquiryController.download() start ---");
		modelView.setViewName("/stock_adjust_inquiry");
		// 検索条件未指定の場合
		String auditNos[] = stockAdjustInquiryForm.getAuditNost();

		if (auditNos == null || auditNos.length == 0) {
			String message = messageSource.getMessage("stockAdjustInquiry.print.message", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		String printerCode = stockAdjustInquiryForm.getPrinterCode();
		if (StringUtils.isEmpty(printerCode)) {
			String message = messageSource.getMessage("Common.print.Message.E001", null, Locale.JAPAN);
			modelView.addObject("validationMessage", message);
			return modelView;
		}
		
		List<String> auditNosList = new ArrayList<String>();
		for (String a : auditNos) {
			if (!auditNosList.contains(a)) {
				auditNosList.add(a);
			}
		}
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Date dt = new Date();
		DateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
		String sysDate = dfDate.format(dt);
		DateFormat dfTime = new SimpleDateFormat("HHmmss");
		String sysTime = dfTime.format(dt);
		for (int i = 0; i < auditNosList.size(); i++) {
			List<StockAdjustInquiryReports> stockAdjustInquiryReportList = stockAdjustInquiryService
					.findStockAdjustInquiryReport(auditNosList.get(i));
			if (CollectionUtils.isEmpty(stockAdjustInquiryReportList)) {
				continue;
			}
			StockAdjustInquiryReport reprot = new StockAdjustInquiryReport("StockAdjustInquiryReport");
			StockAdjustInquiryReport1 reprot1 = new StockAdjustInquiryReport1("StockAdjustInquiryReport1");
			reprot.buildDocument(stockAdjustInquiryReportList, request);
			reprot1.buildDocument(stockAdjustInquiryReportList, request);
			reprot.exportReport(printerCode);
			reprot1.exportReport(printerCode);
			StockAdjustInquiry stockAdjustInquiry = this.getPrintLogInfo(userDetails,sysDate,sysTime);
			stockAdjustInquiry.setPrinter(stockAdjustInquiryForm.getPrinterCode());
			stockAdjustInquiry.setFormId(reprot1.getReportFileName());
			stockAdjustInquiry.setFormName(reprot1.getReportFileNameLog()+".pdf");
			stockAdjustInquiry.setFilePath(commonService.getReprintOutputPdfPath("OutputPdfPath", "Reprint"));
			stockAdjustInquiryService.insertPrintLog(stockAdjustInquiry);
		}
		
		String message = messageSource.getMessage("Common.Edit.Message.I001", null, Locale.JAPAN);
		modelView.addObject("validationMessage", message);
		return modelView;
	}
	
	private StockAdjustInquiry getPrintLogInfo(UserDetails userDetails,String sysDate, String sysTime) throws ParseException{
		String Seqence = stockAdjustInquiryService.selectPrintLogSeqence().trim();
		StockAdjustInquiry stockAdjustInquiry = new StockAdjustInquiry();
		stockAdjustInquiry.setPrintId(Seqence);
		stockAdjustInquiry.setPrintDate(commonService.getPrintdate());
		stockAdjustInquiry.setPrintTime(sysTime);
		stockAdjustInquiry.setUserCode(userDetails.getUsername());
		stockAdjustInquiry.setCreateUser(userDetails.getUsername());
		stockAdjustInquiry.setCreateDate(sysDate);
		stockAdjustInquiry.setCreateTime(sysTime);
		stockAdjustInquiry.setUpdateUser(userDetails.getUsername());
		stockAdjustInquiry.setUpdateDate(sysDate);
		stockAdjustInquiry.setUpdateTime(sysTime);
		return stockAdjustInquiry;
		
	}
}

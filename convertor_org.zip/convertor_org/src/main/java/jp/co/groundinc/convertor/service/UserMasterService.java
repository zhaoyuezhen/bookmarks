package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import jp.co.groundinc.convertor.CommonUtility;
import jp.co.groundinc.convertor.domain.UserMaster;
import jp.co.groundinc.convertor.domain.UserMasterCsv;
import jp.co.groundinc.convertor.mapper.UserMasterMapper;

@Service
public class UserMasterService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	UserMasterMapper userMasterMapper;
	
	public boolean exists(String userCd) {
		logger.info("--- UserMasterService.exists() start ---");
		boolean bRtn = true;
		UserMaster user = userMasterMapper.findByUserCd(userCd);
		if (user == null) {
			bRtn = false;
		}
		
		return bRtn;
	}
	
	public UserMaster findByUserCd(String userCd) {
		logger.info("--- UserMasterService.findByUserCd() start ---");
		
		UserMaster user = userMasterMapper.findByUserCd(userCd);
		
		return user;
	}
	
	public List<UserMaster> findUsers(UserMaster user) {
		logger.info("--- UserMasterService.findUsers() start ---");
		if(!StringUtils.isEmpty(user.getPasswordChangeDate())){
		String passwordChangeDate = CommonUtility.dateFomat(user.getPasswordChangeDate());
		user.setPasswordChangeDate(passwordChangeDate);
		}
		
		return userMasterMapper.findAll(user);
	}
	
	public void addUser(UserMaster user) {
		logger.info("--- UserMasterService.addUser() start ---");
		userMasterMapper.insert(user);
	}
	
	public void updateUser(UserMaster user) {
		logger.info("--- UserMasterService.updateUser() start ---");
		userMasterMapper.update(user);
	}
	
	public void resetUserPassword(UserMaster user) {
		logger.info("--- UserMasterService.resetUserPassword() start ---");
		userMasterMapper.resetPwd(user);
	}
	
	
	public void deleteUser(UserMaster user) {
		logger.info("--- UserMasterService.deleteUser() start ---");
		userMasterMapper.delete(user);
	}
	
	public int selectCountt(UserMaster user) {

		int count = userMasterMapper.selectCountt(user);
		return count;

	}
	
	public List<UserMasterCsv> findUserMasterCsv(
			String userCode, String userName, 
			String authorityKind) {
		logger.info("--- UserMasterService.findUserMasterCsv() start ---");
		
		List<UserMasterCsv> userMasterCsvList = 
				userMasterMapper.selectUserMasterCsv(
						userCode, userName, authorityKind);
		return userMasterCsvList;
	}
}

package jp.co.groundinc.convertor.domain;

public class ManualPickInstructionReports {
	private String largeAreaCode;
	private String pageTitle;
	private String picklistKind;
	private String picklistKindName;
	private String pickBarcode;
	private String packingBarcode;
	private String flightName;
	private String homeNo;
	private String shippingAddress;
	private String shippingAddressName;
	private String area;
	private String location;
	private String unitPrice;
	private String totalAmount;
	private String packingSize;
	private String cbm;
	private String loadingSourceCode;
	private String pickinglistPageNo;
	private String totalPickSequence;
	private String ordererName;
	private String orderDate;
	private String orderKind;
	private String deliveryDate;
	private String shippingSourceName;
	private String orderlargeAreaLine;
	private String checkMark;
	private String priority;
	private String orderAreaKind;
	private String fragileFlag;
	private String orderFragileFlag;
	private String printFlg;
	private String sendStatus;
	private String printOrder;
	private String orderLineCount;
	private String sortLocation;
	private String orderId;
	private String orderLineId;
	private String sku;
	private String skuName;
	private String skuKind;
	private int expectedQty;
	private String processSequenceNo;
	private String expectedDate;
	private String csvExportDate;
	private String csvExportTime;
	
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	
	public String getLargeAreaCode() {
		return largeAreaCode;
	}
	public void setLargeAreaCode(String largeAreaCode) {
		this.largeAreaCode = largeAreaCode;
	}
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getPicklistKind() {
		return picklistKind;
	}
	public void setPicklistKind(String picklistKind) {
		this.picklistKind = picklistKind;
	}
	public String getPicklistKindName() {
		return picklistKindName;
	}
	public void setPicklistKindName(String picklistKindName) {
		this.picklistKindName = picklistKindName;
	}
	public String getPickBarcode() {
		return pickBarcode;
	}
	public void setPickBarcode(String pickBarcode) {
		this.pickBarcode = pickBarcode;
	}
	public String getPackingBarcode() {
		return packingBarcode;
	}
	public void setPackingBarcode(String packingBarcode) {
		this.packingBarcode = packingBarcode;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getHomeNo() {
		return homeNo;
	}
	public void setHomeNo(String homeNo) {
		this.homeNo = homeNo;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getPackingSize() {
		return packingSize;
	}
	public void setPackingSize(String packingSize) {
		this.packingSize = packingSize;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public String getLoadingSourceCode() {
		return loadingSourceCode;
	}
	public void setLoadingSourceCode(String loadingSourceCode) {
		this.loadingSourceCode = loadingSourceCode;
	}
	public String getPickinglistPageNo() {
		return pickinglistPageNo;
	}
	public void setPickinglistPageNo(String pickinglistPageNo) {
		this.pickinglistPageNo = pickinglistPageNo;
	}
	public String getTotalPickSequence() {
		return totalPickSequence;
	}
	public void setTotalPickSequence(String totalPickSequence) {
		this.totalPickSequence = totalPickSequence;
	}
	public String getShippingAddressName() {
		return shippingAddressName;
	}
	public void setShippingAddressName(String shippingAddressName) {
		this.shippingAddressName = shippingAddressName;
	}
	public String getOrdererName() {
		return ordererName;
	}
	public void setOrdererName(String ordererName) {
		this.ordererName = ordererName;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getShippingSourceName() {
		return shippingSourceName;
	}
	public void setShippingSourceName(String shippingSourceName) {
		this.shippingSourceName = shippingSourceName;
	}
	public String getOrderlargeAreaLine() {
		return orderlargeAreaLine;
	}
	public void setOrderlargeAreaLine(String orderlargeAreaLine) {
		this.orderlargeAreaLine = orderlargeAreaLine;
	}
	public String getCheckMark() {
		return checkMark;
	}
	public void setCheckMark(String checkMark) {
		this.checkMark = checkMark;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getOrderAreaKind() {
		return orderAreaKind;
	}
	public void setOrderAreaKind(String orderAreaKind) {
		this.orderAreaKind = orderAreaKind;
	}
	public String getFragileFlag() {
		return fragileFlag;
	}
	public void setFragileFlag(String fragileFlag) {
		this.fragileFlag = fragileFlag;
	}
	public String getOrderFragileFlag() {
		return orderFragileFlag;
	}
	public void setOrderFragileFlag(String orderFragileFlag) {
		this.orderFragileFlag = orderFragileFlag;
	}
	public String getPrintFlg() {
		return printFlg;
	}
	public void setPrintFlg(String printFlg) {
		this.printFlg = printFlg;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public String getPrintOrder() {
		return printOrder;
	}
	public void setPrintOrder(String printOrder) {
		this.printOrder = printOrder;
	}
	public String getOrderLineCount() {
		return orderLineCount;
	}
	public void setOrderLineCount(String orderLineCount) {
		this.orderLineCount = orderLineCount;
	}
	public String getSortLocation() {
		return sortLocation;
	}
	public void setSortLocation(String sortLocation) {
		this.sortLocation = sortLocation;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getExpectedDate() {
		return expectedDate;
	}
	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}
	public String getOrderKind() {
		return orderKind;
	}
	public void setOrderKind(String orderKind) {
		this.orderKind = orderKind;
	}
	public String getProcessSequenceNo() {
		return processSequenceNo;
	}
	public void setProcessSequenceNo(String processSequenceNo) {
		this.processSequenceNo = processSequenceNo;
	}
	public int getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(int expectedQty) {
		this.expectedQty = expectedQty;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	
}

package jp.co.groundinc.convertor.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import jp.co.groundinc.convertor.domain.Translate;
import jp.co.groundinc.convertor.mapper.CommonMapper;

@Service
public class CommonService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CommonMapper commonMapper;
	
	@Autowired
	MessageSource messageSource;
	
	public List<Translate> getTranslateList(String translateKind) {
		logger.info("--- CommonService.getTranslateList() start ---");
		return commonMapper.selectTranslateByTranslateKind(translateKind);
	}
	
	public List<Translate> getTranslateListDetail(String translateKind) {
		logger.info("--- CommonService.getTranslateListDetail() start ---");
		return commonMapper.selectTranslateByTranslateKindDetail(translateKind);
	}
	
	public String getReprintOutputPdfPath(String translateKind,String translateCode) {
		logger.info("--- CommonService.getTranslateListDetail() start ---");
		Translate translate = new Translate();
		translate.setTranslateKind(translateKind);
		translate.setTranslate_code(translateCode);
		return commonMapper.getReprintOutputPdfPath(translate);
	}
	public String getOperationDate() throws ParseException {
		logger.info("--- CommonService.getOperationDate() start ---");
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date operation_date = format.parse(commonMapper.selectOperationDate());
		format = new SimpleDateFormat("yyyy-MM-dd");
		String newoperation_date = format.format(operation_date);
		return newoperation_date;
	}

	public String getPrintdate() throws ParseException {
		logger.info("--- CommonService.getPrintdate() start ---");
		String printdate =commonMapper.selectOperationDate();
		return printdate;
	}
	
	public String getStockSendDate() throws ParseException {
		logger.info("--- CommonService.getOperationDate() start ---");
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date operation_date = format.parse(commonMapper.selectStockSendDate());
		format = new SimpleDateFormat("yyyy/MM/dd");
		String newoperation_date = format.format(operation_date);
		return newoperation_date;
	}
	public String getStockSendTime() throws ParseException {
		logger.info("--- CommonService.getOperationDate() start ---");
		SimpleDateFormat format = new SimpleDateFormat("HHmmss");
		Date stockSendTime = format.parse(commonMapper.selectStockSendTime());
		format = new SimpleDateFormat("HH:mm:ss");
		String newstockSendTime = format.format(stockSendTime);
		return newstockSendTime;
	}
	
	public String getPrintTimeStart() throws ParseException {
		logger.info("--- CommonService.getPrintTimeStart() start ---");
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(new Date());
		int minute = calendar.get(Calendar.MINUTE); 
		if(minute<=30){
			calendar.set(Calendar.MINUTE, 30);
		}else{
			calendar.set(Calendar.MINUTE, 00);
			calendar.add(Calendar.HOUR_OF_DAY, +1);
		}
		calendar.add(Calendar.HOUR_OF_DAY, -1);
		Date sysTime= calendar.getTime();
		String printTimeStart = dateFormat.format(sysTime);
		return printTimeStart;
	}
	
	public String getPrintTimeEnd() throws ParseException {
		logger.info("--- CommonService.getPrintTimeEnd() start ---");
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(new Date());
		int minute = calendar.get(Calendar.MINUTE); 
		if(minute<=30){
			calendar.set(Calendar.MINUTE, 30);
		}else{
			calendar.set(Calendar.MINUTE, 00);
			calendar.add(Calendar.HOUR_OF_DAY, +1);
		}
		Date sysTime= calendar.getTime();
		String printTimeEnd = dateFormat.format(sysTime);
		return printTimeEnd; 
	}
	public int selectTableUpperLimitCount(){
		String limit  = commonMapper.selectTableUpperlimit();
		int limitt  = Integer.parseInt(limit);
		return limitt;
	}
	
	public int selectTableUpperCSVLimitCount(){
		String limit  = commonMapper.selectTableUpperCSVlimit();
		int limitt  = Integer.parseInt(limit);
		return limitt;
	}
	
	public String getSkuName(String skuCode) {
		String skuName = commonMapper.selectSkuNameByCode(skuCode);
		return skuName;
	}
	
	public String getUserName(String userCode) {
		String userName = commonMapper.selectUserNameByCode(userCode);
		return userName;
	}
	public String getSpecifiedDayAfter(String dateTime ) throws ParseException{
		
		SimpleDateFormat  sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date date = sdf.parse(dateTime);
		 Calendar calendar = Calendar.getInstance();  
		 calendar.setTime(date);  
		 calendar.add(Calendar.DAY_OF_MONTH, 1);
		 Date tomrow = calendar.getTime();
		 sdf.format(tomrow);
		 String newDateTime = sdf.format(tomrow);
		return newDateTime;
	}
}

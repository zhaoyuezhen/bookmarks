package jp.co.groundinc.convertor.domain;

public class StockAdjustInquiryReports {
	private String auditNo;
	private String completedTimestamp;
	private String auditParamValueFrom;
	private String auditParamValueTo;
	private String auditStartTimestamp;
	private String auditOperationTimestamp;
	private String targetSlotCount;
	private String sku;
	private String skuName;
	private String skuKind;
	private String expectedQty;
	private String resultQty;
	private String diffQty;
	private String location;
	private String ppsId;
	private String ppsName;
	private String userCode;
	private String userName;
	private String startDate;
	private String startTime;
	private String csvExportDate;
	private String csvExportTime;

	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getAuditNo() {
		return auditNo;
	}
	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}
	public String getCompletedTimestamp() {
		return completedTimestamp;
	}
	public void setCompletedTimestamp(String completedTimestamp) {
		this.completedTimestamp = completedTimestamp;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getExpectedQty() {
		return expectedQty;
	}
	public void setExpectedQty(String expectedQty) {
		this.expectedQty = expectedQty;
	}
	public String getResultQty() {
		return resultQty;
	}
	public void setResultQty(String resultQty) {
		this.resultQty = resultQty;
	}
	public String getDiffQty() {
		return diffQty;
	}
	public void setDiffQty(String diffQty) {
		this.diffQty = diffQty;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPpsId() {
		return ppsId;
	}
	public void setPpsId(String ppsId) {
		this.ppsId = ppsId;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}
	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}
	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}
	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}
	public String getAuditStartTimestamp() {
		return auditStartTimestamp;
	}
	public void setAuditStartTimestamp(String auditStartTimestamp) {
		this.auditStartTimestamp = auditStartTimestamp;
	}
	public String getAuditOperationTimestamp() {
		return auditOperationTimestamp;
	}
	public void setAuditOperationTimestamp(String auditOperationTimestamp) {
		this.auditOperationTimestamp = auditOperationTimestamp;
	}
	public String getTargetSlotCount() {
		return targetSlotCount;
	}
	public void setTargetSlotCount(String targetSlotCount) {
		this.targetSlotCount = targetSlotCount;
	}
	public String getPpsName() {
		return ppsName;
	}
	public void setPpsName(String ppsName) {
		this.ppsName = ppsName;
	}
	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}


}

package jp.co.groundinc.convertor.domain;

import java.math.BigDecimal;

public class StockInquiry {
	private String skuStart ;
	private String skuEnd;
	private String sku;
	private String skuName;
	private BigDecimal totalCbmAbove;
	private BigDecimal totalCbmUnder;
	private String totalCbm;
	private String retentionDays;
	private String stockQty;
	private String cbm;
	public String getSkuStart() {
		return skuStart;
	}
	public void setSkuStart(String skuStart) {
		this.skuStart = skuStart;
	}
	public String getSkuEnd() {
		return skuEnd;
	}
	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public BigDecimal getTotalCbmAbove() {
		return totalCbmAbove;
	}
	public void setTotalCbmAbove(BigDecimal totalCbmAbove) {
		this.totalCbmAbove = totalCbmAbove;
	}
	public BigDecimal getTotalCbmUnder() {
		return totalCbmUnder;
	}
	public void setTotalCbmUnder(BigDecimal totalCbmUnder) {
		this.totalCbmUnder = totalCbmUnder;
	}
	public String getTotalCbm() {
		return totalCbm;
	}
	public void setTotalCbm(String totalCbm) {
		this.totalCbm = totalCbm;
	}
	public String getRetentionDays() {
		return retentionDays;
	}
	public void setRetentionDays(String retentionDays) {
		this.retentionDays = retentionDays;
	}
	public String getStockQty() {
		return stockQty;
	}
	public void setStockQty(String stockQty) {
		this.stockQty = stockQty;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	
	
}

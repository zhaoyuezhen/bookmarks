package jp.co.groundinc.convertor.domain;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class AuditProgress implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@NotNull(message = "{AuditProgress.search.startDate.empty.message}")
	private String startDate;
	
	private String nextStartDate;

	private String auditProgressKeyName;

	private String totalExpectedCount;

	private String totalCompletedCount;

	private String totalIncompletedCount;

	private String completedRate;
	
	private String auditNo;
	
	private String auditParamValueFrom;
	
	private String auditParamValueTo;
	
	private String auditType;
	
	private String auditTypeName;
	
	
	public String getAuditTypeName() {
		return auditTypeName;
	}

	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}

	public String getAuditNo() {
		return auditNo;
	}

	public void setAuditNo(String auditNo) {
		this.auditNo = auditNo;
	}

	public String getAuditParamValueFrom() {
		return auditParamValueFrom;
	}

	public void setAuditParamValueFrom(String auditParamValueFrom) {
		this.auditParamValueFrom = auditParamValueFrom;
	}

	public String getAuditParamValueTo() {
		return auditParamValueTo;
	}

	public void setAuditParamValueTo(String auditParamValueTo) {
		this.auditParamValueTo = auditParamValueTo;
	}

	public String getAuditType() {
		return auditType;
	}

	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getNextStartDate() {
		return nextStartDate;
	}

	public void setNextStartDate(String nextStartDate) {
		this.nextStartDate = nextStartDate;
	}

	public String getAuditProgressKeyName() {
		return auditProgressKeyName;
	}

	public void setAuditProgressKeyName(String auditProgressKeyName) {
		this.auditProgressKeyName = auditProgressKeyName;
	}

	public String getTotalIncompletedCount() {
		return totalIncompletedCount;
	}

	public void setTotalIncompletedCount(String totalIncompletedCount) {
		this.totalIncompletedCount = totalIncompletedCount;
	}


	public String getTotalExpectedCount() {
		return totalExpectedCount;
	}

	public void setTotalExpectedCount(String totalExpectedCount) {
		this.totalExpectedCount = totalExpectedCount;
	}

	public String getTotalCompletedCount() {
		return totalCompletedCount;
	}

	public void setTotalCompletedCount(String totalCompletedCount) {
		this.totalCompletedCount = totalCompletedCount;
	}

	public String getCompletedRate() {
		return completedRate;
	}

	public void setCompletedRate(String completedRate) {
		this.completedRate = completedRate;
	}

}

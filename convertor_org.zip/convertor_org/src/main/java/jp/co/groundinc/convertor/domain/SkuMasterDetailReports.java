package jp.co.groundinc.convertor.domain;

public class SkuMasterDetailReports {

	private String sku;
	
	private String skuName;
	
	private String skuKind;
	
	private String cbm;
	
	/** 梱包幅*/
	private int skuWidth;
	
	/** 梱包奥行*/
	private int skuDepth;
	
	/** 梱包高さ*/
	private int skuHeight;
	
	/** 重量*/
	private int skuWeight;
	
	/** スキャニングコード*/
	private String scanningCode;
	
	/** 小分類コード*/
	private String categoryCode;
	
	/** 小分類コード名称*/
	private String categoryName;
	
	private String csvExportDate;
	
	private String csvExportTime;

	public String getCsvExportDate() {
		return csvExportDate;
	}
	public void setCsvExportDate(String csvExportDate) {
		this.csvExportDate = csvExportDate;
	}
	public String getCsvExportTime() {
		return csvExportTime;
	}
	public void setCsvExportTime(String csvExportTime) {
		this.csvExportTime = csvExportTime;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getSkuKind() {
		return skuKind;
	}
	public void setSkuKind(String skuKind) {
		this.skuKind = skuKind;
	}
	public String getScanningCode() {
		return scanningCode;
	}
	public void setScanningCode(String scanningCode) {
		this.scanningCode = scanningCode;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getCbm() {
		return cbm;
	}
	public void setCbm(String cbm) {
		this.cbm = cbm;
	}
	public int getSkuWidth() {
		return skuWidth;
	}
	public void setSkuWidth(int skuWidth) {
		this.skuWidth = skuWidth;
	}
	public int getSkuDepth() {
		return skuDepth;
	}
	public void setSkuDepth(int skuDepth) {
		this.skuDepth = skuDepth;
	}
	public int getSkuHeight() {
		return skuHeight;
	}
	public void setSkuHeight(int skuHeight) {
		this.skuHeight = skuHeight;
	}
	public int getSkuWeight() {
		return skuWeight;
	}
	public void setSkuWeight(int skuWeight) {
		this.skuWeight = skuWeight;
	}
}

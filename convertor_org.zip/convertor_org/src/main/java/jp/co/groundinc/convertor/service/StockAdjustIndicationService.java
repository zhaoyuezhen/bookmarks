package jp.co.groundinc.convertor.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;

import jp.co.groundinc.convertor.domain.StockAdjustIndication;
import jp.co.groundinc.convertor.domain.StockAdjustIndicationReports;
import jp.co.groundinc.convertor.mapper.StockAdjustIndicationMapper;
@Service
@EnableAutoConfiguration
public class StockAdjustIndicationService {
	@Autowired
	StockAdjustIndicationMapper stockAdjustIndicationMapper;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<StockAdjustIndication> findProductInfo(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- InventoriesInstructionService.findProductInfo() start ---");
		List<StockAdjustIndication> selectProductInfoList = stockAdjustIndicationMapper.selectProductInfo(stockAdjustIndication);
		return selectProductInfoList;
	}
	
	public void selectAuditSeqenceNext() {
		logger.info("--- StockAdjustIndicationService.selectAuditSeqenceNext() start ---");
		stockAdjustIndicationMapper.selectAuditSeqenceNext();
		
	}
	
	public String selectAuditSeqence() {
		logger.info("--- StockAdjustIndicationService.selectAuditSeqence() start ---");
		String AuditNo  = stockAdjustIndicationMapper.selectAuditSeqence();
		return AuditNo;
	}
	
	public void insertauditException(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.insertauditException() start ---");
		stockAdjustIndicationMapper.insertAuditExpectation(stockAdjustIndication);
		
	}
	
	public String selectSlotCount(String sku) {
		logger.info("--- StockAdjustIndicationService.findProductInfo() start ---");
		String selectProductSlotCount = stockAdjustIndicationMapper.selectSlotCount(sku);
		return selectProductSlotCount;
	}
	
	public List<StockAdjustIndication> selectViewStockDetail(String sku) {
		logger.info("--- StockAdjustIndicationService.selectViewStockDetail() start ---");
		List<StockAdjustIndication> selectViewStockDetaillList = stockAdjustIndicationMapper.selectViewStockDetail(sku);
		return selectViewStockDetaillList;
	}
	public List<StockAdjustIndication> selectViewStockDetailLocation(String location) {
		logger.info("--- StockAdjustIndicationService.selectViewStockDetailLocation() start ---");
		List<StockAdjustIndication> selectViewStockDetaillLocation = stockAdjustIndicationMapper.selectViewStockDetailLocation(location);
		return selectViewStockDetaillLocation;
	}
	
	public void insertAuditExceptionDetail(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.insertAuditExceptionDetail() start ---");
		stockAdjustIndicationMapper.insertAuditExceptionDetail(stockAdjustIndication);
		
	}
	
	public void insertAuditStock(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.insertAuditExceptionDetail() start ---");
		stockAdjustIndicationMapper.insertAuditStock(stockAdjustIndication);
		
	}
	
	public List<StockAdjustIndication> findLocationInfo(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.findProductInfo() start ---");
		List<StockAdjustIndication> LocationList = stockAdjustIndicationMapper.findLocationInfo(stockAdjustIndication);
		return LocationList;
	}
	
	public int selectProductCount(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.selectProductCount() start ---");
		int count = stockAdjustIndicationMapper.selectProductCount(stockAdjustIndication);
		return count;
	}
	
public int selectSlotCountp(StockAdjustIndication stockAdjustIndication) {
		logger.info("--- StockAdjustIndicationService.selectSlotCount() start ---");
		int count = stockAdjustIndicationMapper.selectSlotCountp(stockAdjustIndication);
		return count;
	}

public List<StockAdjustIndicationReports> findStockAdjustIndicationReports(String Seqence) {
	logger.info("--- StockAdjustIndicationService.findStockAdjustIndicationReports() start ---");
	List<StockAdjustIndicationReports> stockAdjustIndicationReportsList = 
			stockAdjustIndicationMapper.selectStockAdjustIndicationReports(Seqence);
	
	return stockAdjustIndicationReportsList;
}

}

function initClock(){
	moment.locale('ja');

	$("#clockPanel").html("<span class='nobr' style='font-size:large; margin:0;'>" + moment().format('YY/MM/DD HH:mm:ss') + "</span>");
	function repaintClock(){
		$("#clockPanel").html("<span class='text-nowrap' style='font-size:large; margin:0;'>" + moment().format('YY/MM/DD HH:mm:ss') + "</span>");
	}
	setInterval(repaintClock, 1000);
}